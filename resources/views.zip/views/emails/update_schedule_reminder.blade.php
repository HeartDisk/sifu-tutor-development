<!DOCTYPE html>
<html>
<head>
    <title>Class Schedule Reminder</title>
</head>
<body>
{!! $emailContent !!}
</body>
</html>
