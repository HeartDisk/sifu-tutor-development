<!DOCTYPE html>
<html>
<head>
    <title>Verification Code</title>
</head>
<body>
<p>Verification Code from Sifututor</p>
<p>YourID: <strong>{{ $tutorDetail->uid }}</strong></p>
<table>
    <tr>
        <td style="font-size:31px; font-weight:bold;">{{ $verificationCode }}</td>
    </tr>
</table>
</body>
</html>
