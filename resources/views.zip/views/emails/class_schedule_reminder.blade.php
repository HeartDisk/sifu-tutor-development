<!DOCTYPE html>
<html>
<head>
    <title>Create Class Schedule Reminder</title>
</head>
<body>
{!! $emailContent !!}
</body>
</html>
