<!DOCTYPE html>
<html>
<head>
    <title>Class Dispute Status Update</title>
</head>
<body>
<div class="card">
    <div class="nk-invoice">
        <table class="table table-responsive no-border">
            <tbody>
            <tr>
                <td>
                    Dear Parent, your dispute for ticket ID: {{ $jobTicketData->uid }} has been approved.
                </td>
            </tr>
            </tbody>
        </table>
    </div>
</div>
</body>
</html>
