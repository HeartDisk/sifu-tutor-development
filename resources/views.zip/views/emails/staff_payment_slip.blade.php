<!DOCTYPE html>
<html>
<head>
    <title>Staff Payment Slip</title>
</head>
<body>
<p>Please find attached the invoice.</p>
{!! $emailBody !!}
</body>
</html>
