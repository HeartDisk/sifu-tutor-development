<!DOCTYPE html>
<html>
<head>
    <title>Class Dispute Status Update</title>
</head>
<body>
<table class="table table-responsive no-border">
    <tbody>
    <tr>
        <td>
            Dear Parent, your dispute for ticket ID: {{ $jobTicketData->uid }} has been rejected.
        </td>
    </tr>
    </tbody>
</table>
</body>
</html>
