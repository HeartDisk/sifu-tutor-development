<!DOCTYPE html>
<html>
<head>
    <title>Student Payment Slip Invoice</title>
</head>
<body>
<table class="table table-responsive no-border">
    <tbody>
    <tr>
        <td>
            Please find attached Invoice
        </td>
    </tr>
    </tbody>
</table>
</body>
</html>
