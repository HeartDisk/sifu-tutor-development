<!DOCTYPE html>
<html>
<head>
    <title>Tutor Payment Slip</title>
</head>
<body>
<table class="table table-responsive no-border">
    <tbody>
    <tr>
        <td>
            Please find attached Payment Slip.
        </td>
    </tr>
    </tbody>
</table>
</body>
</html>
