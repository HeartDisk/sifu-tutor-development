@extends('layouts.main')

@section('content')
    <link href="{{asset('library/dataTables.bootstrap5.min.css')}}" rel="stylesheet"/>
    <link href="{{asset('library/daterangepicker.css')}}" rel="stylesheet"/>

    <style>

        /* Badges */
        .label,
        .badge {
            box-shadow: none;
            padding: .35rem .5rem;
        }

        .label-secondary,
        .label-default,
        .badge-secondary,
        .badge-default {
            background-color: #66767c;
        }

        .label-primary,
        .badge-primary {
            background-color: #07a7e3;
        }

        .label-success,
        .badge-success {
            background-color: #0ad251;
        }

        .label-info,
        .badge-info {
            background-color: #85dff8;
        }

        .label-warning,
        .badge-warning {
            color: #384044 !important;
            background-color: #fce418;
        }

        .label-danger,
        .badge-danger {
            background-color: #f43a59;
        }

        .label-light,
        .badge-light {
            color: #384044 !important;
        }

        /* Backgrounds */
        .bg-primary {
            color: #FFFFFF;
            background-color: #07a7e3 !important;
        }

        .bg-secondary {
            color: #FFFFFF;
            background-color: #4f5b60 !important;
        }

        .bg-success {
            color: #FFFFFF;
            background-color: #0ad251 !important;
        }

        .bg-info {
            color: #FFFFFF;
            background-color: #55d3f5 !important;
        }

        .bg-warning {
            color: #ac9a02 !important;
            background-color: #fce418 !important;
        }

        .bg-danger {
            color: #FFFFFF;
            background-color: #f43a59 !important;
        }

        .bg-dark {
            background-color: #122f3b !important;
        }

        .bg-light {
            background-color: #F7F7FA !important;
        }

        .bg-tranparent {
            background-color: transparent !important;
        }

        .bg-dark *,
        .bg-danger *,
        .bg-warning *,
        .bg-info *,
        .bg-success *,
        .bg-secondary *,
        .bg-primary *,
        .bg-dark .batch-icon,
        .bg-danger .batch-icon,
        .bg-warning .batch-icon,
        .bg-info .batch-icon,
        .bg-success .batch-icon,
        .bg-secondary .batch-icon,
        .bg-primary .batch-icon {
            color: #FFFFFF;
        }

        .bg-gradient [class^="card-"],
        .bg-gradient [class^="card-"] * {
            color: #FFFFFF !important;
        }

        /* Highlight Colors - Bottom Border */
        .highlight-color-blue {
            color: #FFFFFF !important;
            background-color: #07a7e3 !important;
        }

        .highlight-color-green {
            color: #FFFFFF !important;
            background-color: #0ad251 !important;
        }

        .highlight-color-orange {
            color: #FFFFFF !important;
            background-color: #FC9131 !important;
        }

        .highlight-color-yellow {
            color: #FFFFFF !important;
            background-color: #F8D800 !important;
        }

        .highlight-color-red {
            color: #FFFFFF !important;
            background-color: #EA5455 !important;
        }

        .highlight-color-purple {
            color: #FFFFFF !important;
            background-color: #973999 !important;
        }

        .bg-gradient {
            color: #FFFFFF !important;
            background: #07a7e3;
            /* Old browsers */
            background: -moz-linear-gradient(-45deg, #07a7e3 0%, #32dac3 100%);
            /* FF3.6-15 */
            background: -webkit-linear-gradient(-45deg, #07a7e3 0%, #32dac3 100%);
            /* Chrome10-25,Safari5.1-6 */
            background: linear-gradient(135deg, #07a7e3 0%, #32dac3 100%);
            /* W3C, IE10+, FF16+, Chrome26+, Opera12+, Safari7+ */
            filter: progid:DXImageTransform.Microsoft.gradient(startColorstr=$ qp-color-1, endColorstr=$ qp-color-2, GradientType=1);
            /* IE6-9 fallback on horizontal gradient */
            -webkit-transition: opacity 0.2s ease-out;
            -moz-transition: opacity 0.2s ease-out;
            -o-transition: opacity 0.2s ease-out;
            transition: opacity 0.2s ease-out;
        }

        .bg-gradient [class^="card-"],
        .bg-gradient [class^="card-"] * {
            color: #FFFFFF !important;
        }

        .bg-secondary.bg-gradient {
            color: #FFFFFF !important;
            background: #4f5b60;
            /* Old browsers */
            background: -moz-linear-gradient(-45deg, #4f5b60 0%, #97a9b2 100%);
            /* FF3.6-15 */
            background: -webkit-linear-gradient(-45deg, #4f5b60 0%, #97a9b2 100%);
            /* Chrome10-25,Safari5.1-6 */
            background: linear-gradient(135deg, #4f5b60 0%, #97a9b2 100%);
            /* W3C, IE10+, FF16+, Chrome26+, Opera12+, Safari7+ */
            filter: progid:DXImageTransform.Microsoft.gradient(startColorstr=$ qp-color-1, endColorstr=$ qp-color-2, GradientType=1);
            /* IE6-9 fallback on horizontal gradient */
            -webkit-transition: opacity 0.2s ease-out;
            -moz-transition: opacity 0.2s ease-out;
            -o-transition: opacity 0.2s ease-out;
            transition: opacity 0.2s ease-out;
            -webkit-transition: width 0.3s ease-in-out;
            -moz-transition: width 0.3s ease-in-out;
            -o-transition: width 0.3s ease-in-out;
            transition: width 0.3s ease-in-out;
        }

        .bg-success.bg-gradient {
            color: #FFFFFF !important;
            background: #28C76F;
            /* Old browsers */
            background: -moz-linear-gradient(-45deg, #28C76F 0%, #81FBB8 100%);
            /* FF3.6-15 */
            background: -webkit-linear-gradient(-45deg, #28C76F 0%, #81FBB8 100%);
            /* Chrome10-25,Safari5.1-6 */
            background: linear-gradient(135deg, #28C76F 0%, #81FBB8 100%);
            /* W3C, IE10+, FF16+, Chrome26+, Opera12+, Safari7+ */
            filter: progid:DXImageTransform.Microsoft.gradient(startColorstr=$ qp-color-1, endColorstr=$ qp-color-2, GradientType=1);
            /* IE6-9 fallback on horizontal gradient */
            -webkit-transition: opacity 0.2s ease-out;
            -moz-transition: opacity 0.2s ease-out;
            -o-transition: opacity 0.2s ease-out;
            transition: opacity 0.2s ease-out;
            -webkit-transition: width 0.3s ease-in-out;
            -moz-transition: width 0.3s ease-in-out;
            -o-transition: width 0.3s ease-in-out;
            transition: width 0.3s ease-in-out;
        }

        .bg-info.bg-gradient {
            color: #FFFFFF !important;
            background: #3677FF;
            /* Old browsers */
            background: -moz-linear-gradient(-45deg, #3677FF 0%, #FFD26F 100%);
            /* FF3.6-15 */
            background: -webkit-linear-gradient(-45deg, #3677FF 0%, #FFD26F 100%);
            /* Chrome10-25,Safari5.1-6 */
            background: linear-gradient(135deg, #3677FF 0%, #FFD26F 100%);
            /* W3C, IE10+, FF16+, Chrome26+, Opera12+, Safari7+ */
            filter: progid:DXImageTransform.Microsoft.gradient(startColorstr=$ qp-color-1, endColorstr=$ qp-color-2, GradientType=1);
            /* IE6-9 fallback on horizontal gradient */
            -webkit-transition: opacity 0.2s ease-out;
            -moz-transition: opacity 0.2s ease-out;
            -o-transition: opacity 0.2s ease-out;
            transition: opacity 0.2s ease-out;
            -webkit-transition: width 0.3s ease-in-out;
            -moz-transition: width 0.3s ease-in-out;
            -o-transition: width 0.3s ease-in-out;
            transition: width 0.3s ease-in-out;
        }

        .bg-warning.bg-gradient {
            color: #4f5b60 !important;
            background: #FC9131;
            /* Old browsers */
            background: -moz-linear-gradient(-45deg, #FC9131 0%, #FCCF31 100%);
            /* FF3.6-15 */
            background: -webkit-linear-gradient(-45deg, #FC9131 0%, #FCCF31 100%);
            /* Chrome10-25,Safari5.1-6 */
            background: linear-gradient(135deg, #FC9131 0%, #FCCF31 100%);
            /* W3C, IE10+, FF16+, Chrome26+, Opera12+, Safari7+ */
            filter: progid:DXImageTransform.Microsoft.gradient(startColorstr=$ qp-color-1, endColorstr=$ qp-color-2, GradientType=1);
            /* IE6-9 fallback on horizontal gradient */
            -webkit-transition: opacity 0.2s ease-out;
            -moz-transition: opacity 0.2s ease-out;
            -o-transition: opacity 0.2s ease-out;
            transition: opacity 0.2s ease-out;
            -webkit-transition: width 0.3s ease-in-out;
            -moz-transition: width 0.3s ease-in-out;
            -o-transition: width 0.3s ease-in-out;
            transition: width 0.3s ease-in-out;
        }

        .bg-danger.bg-gradient {
            color: #FFFFFF !important;
            background: #EA5455;
            /* Old browsers */
            background: -moz-linear-gradient(-45deg, #EA5455 0%, #FC9131 100%);
            /* FF3.6-15 */
            background: -webkit-linear-gradient(-45deg, #EA5455 0%, #FC9131 100%);
            /* Chrome10-25,Safari5.1-6 */
            background: linear-gradient(135deg, #EA5455 0%, #FC9131 100%);
            /* W3C, IE10+, FF16+, Chrome26+, Opera12+, Safari7+ */
            filter: progid:DXImageTransform.Microsoft.gradient(startColorstr=$ qp-color-1, endColorstr=$ qp-color-2, GradientType=1);
            /* IE6-9 fallback on horizontal gradient */
            -webkit-transition: opacity 0.2s ease-out;
            -moz-transition: opacity 0.2s ease-out;
            -o-transition: opacity 0.2s ease-out;
            transition: opacity 0.2s ease-out;
            -webkit-transition: width 0.3s ease-in-out;
            -moz-transition: width 0.3s ease-in-out;
            -o-transition: width 0.3s ease-in-out;
            transition: width 0.3s ease-in-out;
        }

        .bg-primary p,
        .bg-secondary p,
        .bg-success p,
        .bg-info p,
        .bg-danger p,
        .bg-dark p {
            color: #FFFFFF;
        }

        .bg-secondary h1,
        .bg-secondary h2,
        .bg-secondary h3,
        .bg-secondary h4,
        .bg-secondary h5,
        .bg-secondary h6,
        .bg-dark h1,
        .bg-dark h2,
        .bg-dark h3,
        .bg-dark h4,
        .bg-dark h5,
        .bg-dark h6 {
            color: #FFFFFF;
        }

        .bg-warning p {
            color: #ac9a02 !important;
        }

        /* Borders */
        .border-priamry {
            border-color: #07a7e3 !important;
        }

        .border-secondary {
            border-color: #4f5b60 !important;
        }

        .border-success {
            border-color: #0ad251 !important;
        }

        .border-danger {
            border-color: #f43a59 !important;
        }

        .border-warning {
            border-color: #fce418 !important;
        }

        .border-info {
            border-color: #55d3f5 !important;
        }

        /* Text Colors */
        .text-priamry {
            color: #07a7e3 !important;
        }

        .text-priamry .batch-icon {
            color: #07a7e3 !important;
        }

        .text-secondary {
            color: #4f5b60 !important;
        }

        .text-secondary .batch-icon {
            color: #4f5b60 !important;
        }

        .text-success {
            color: #0ad251 !important;
        }

        .text-success .batch-icon {
            color: #0ad251 !important;
        }

        .text-danger {
            color: #f43a59 !important;
        }

        .text-danger .batch-icon {
            color: #f43a59 !important;
        }

        .text-warning {
            color: #fce418 !important;
        }

        .text-warning .batch-icon {
            color: #fce418 !important;
        }

        .text-info {
            color: #55d3f5 !important;
        }

        .text-info .batch-icon {
            color: #55d3f5 !important;
        }

        /* Buttons */
        .btn {
            margin: 6px 0;
            font-size: 1rem;
            -webkit-border-radius: 0.4167rem;
            -moz-border-radius: 0.4167rem;
            -ms-border-radius: 0.4167rem;
            -o-border-radius: 0.4167rem;
            border-radius: 0.4167rem;
            font-weight: 500;
            padding: .95rem 2.13rem .85rem;
            -webkit-transition: all 0.225s ease-in-out;
            -moz-transition: all 0.225s ease-in-out;
            -o-transition: all 0.225s ease-in-out;
            transition: all 0.225s ease-in-out;
            box-shadow: none !important;
        }

        .btn.disabled,
        .btn:disabled {
            text-decoration: line-through;
            cursor: not-allowed;
        }

        .btn-group-lg > .btn,
        .btn.btn-lg {
            font-size: 1.25rem;
            font-weight: 500;
            -webkit-border-radius: 0.4167rem;
            -moz-border-radius: 0.4167rem;
            -ms-border-radius: 0.4167rem;
            -o-border-radius: 0.4167rem;
            border-radius: 0.4167rem;
        }

        .btn-group-lg > .btn .batch-icon,
        .btn.btn-lg .batch-icon {
            font-size: 1.25rem;
        }

        .btn-group-sm > .btn,
        .btn.btn-sm {
            padding: .5rem 1.6rem;
            font-size: 0.8rem;
            -webkit-border-radius: 0.4167rem;
            -moz-border-radius: 0.4167rem;
            -ms-border-radius: 0.4167rem;
            -o-border-radius: 0.4167rem;
            border-radius: 0.4167rem;
            font-weight: 500;
        }

        .btn-group-sm > .btn .batch-icon,
        .btn.btn-sm .batch-icon {
            font-size: 0.8rem;
        }

        .btn-link,
        .btn-link.dropdown-toggle {
            color: #4f5b60 !important;
        }

        .btn-link .batch-icon,
        .btn-link.dropdown-toggle .batch-icon {
            color: #4f5b60 !important;
        }

        .btn-link:focus,
        .btn-link.focus,
        .btn-link:hover,
        .btn-link.dropdown-toggle:hover,
        .btn-link.dropdown-toggle:focus {
            color: #4f5b60 !important;
            background-color: #EAEAEA !important;
        }

        .btn-link.disabled,
        .btn-link:disabled {
            color: #4f5b60 !important;
        }

        .btn-link:active,
        .btn-link.active,
        .show > .btn-primary.dropdown-toggle {
            color: #4f5b60 !important;
        }

        .btn-link:active:hover,
        .btn-link:active:focus {
            color: #4f5b60 !important;
        }

        .btn-primary,
        .btn-primary.dropdown-toggle {
            background-color: #07a7e3 !important;
        }

        .btn-primary:focus,
        .btn-primary.focus,
        .btn-primary:hover,
        .btn-primary.dropdown-toggle:hover,
        .btn-primary.dropdown-toggle:focus {
            background-color: #25bff8 !important;
        }

        .btn-primary.disabled,
        .btn-primary:disabled {
            background-color: #30b9ed !important;
        }

        .btn-primary:not([disabled]):not(.disabled).active,
        .btn-primary:not([disabled]):not(.disabled):active,
        .show > .btn-primary.dropdown-toggle {
            background-color: #0583b2 !important;
        }

        .btn-primary:active:hover,
        .btn-primary:active:focus {
            background-color: #0583b2 !important;
        }

        .btn-secondary,
        .btn-secondary.dropdown-toggle {
            background-color: #4f5b60 !important;
        }

        .btn-secondary:focus,
        .btn-secondary.focus,
        .btn-secondary:hover,
        .btn-secondary.dropdown-toggle:hover,
        .btn-secondary.dropdown-toggle:focus {
            background-color: #66767c !important;
        }

        .btn-secondary.disabled,
        .btn-secondary:disabled {
            background-color: #717171 !important;
        }

        .btn-secondary:not([disabled]):not(.disabled).active,
        .btn-secondary:not([disabled]):not(.disabled):active,
        .show > .btn-secondary.dropdown-toggle {
            background-color: #384044 !important;
        }

        .btn-secondary:active:hover,
        .btn-secondary:active:focus {
            background-color: #7e7e7e !important;
        }

        .btn-success,
        .btn-success.dropdown-toggle {
            background-color: #0ad251 !important;
        }

        .btn-success:focus,
        .btn-success.focus,
        .btn-success:hover,
        .btn-success.dropdown-toggle:hover,
        .btn-success.dropdown-toggle:focus {
            background-color: #0adc55 !important;
        }

        .btn-success.disabled,
        .btn-success:disabled {
            background-color: #27e86b !important;
        }

        .btn-success:not([disabled]):not(.disabled).active,
        .btn-success:not([disabled]):not(.disabled):active,
        .show > .btn-success.dropdown-toggle {
            background-color: #08a13e !important;
        }

        .btn-info,
        .btn-info.dropdown-toggle {
            background-color: #55d3f5 !important;
        }

        .btn-info:focus,
        .btn-info.focus,
        .btn-info:hover,
        .btn-info.dropdown-toggle:focus,
        .btn-info.dropdown-toggle:hover {
            background-color: #8cdcf1 !important;
        }

        .btn-info.disabled,
        .btn-info:disabled {
            background-color: #8cdcf1 !important;
        }

        .btn-info:not([disabled]):not(.disabled).active,
        .btn-info:not([disabled]):not(.disabled):active,
        .show > .btn-info.dropdown-toggle {
            background-color: #25c7f2 !important;
        }

        .btn-info:active:hover {
            background-color: #0dacd7 !important;
        }

        .btn-warning,
        .btn-warning.dropdown-toggle {
            color: #ac9a02 !important;
            background-color: #fce418 !important;
        }

        .btn-warning:focus,
        .btn-warning.focus,
        .btn-warning:hover,
        .btn-warning.dropdown-toggle:hover,
        .btn-warning.dropdown-toggle:focus {
            background-color: #fdea4a !important;
        }

        .btn-warning.disabled,
        .btn-warning:disabled {
            background-color: #f4e353 !important;
        }

        .btn-warning:not([disabled]):not(.disabled).active,
        .btn-warning:not([disabled]):not(.disabled):active,
        .show > .btn-warning.dropdown-toggle {
            background-color: #dec703 !important;
        }

        .btn-danger,
        .btn-danger.dropdown-toggle {
            background-color: #f43a59 !important;
        }

        .btn-danger:focus,
        .btn-danger.focus,
        .btn-danger:hover,
        .btn-danger.dropdown-toggle:hover,
        .btn-danger.dropdown-toggle:focus {
            background-color: #f76a82 !important;
        }

        .btn-danger.disabled,
        .btn-danger:disabled {
            background-color: #ef7287 !important;
        }

        .btn-danger:not([disabled]):not(.disabled).active,
        .btn-danger:not([disabled]):not(.disabled):active,
        .show > .btn-danger.dropdown-toggle {
            background-color: #ee0d33 !important;
        }

        .btn-danger:active:hover,
        .btn-danger:active:focus {
            background-color: #f99baa !important;
        }

        .btn-outline-primary {
            border-color: #07a7e3 !important;
            color: #0583b2 !important;
        }

        .btn-outline-primary .batch-icon {
            color: #0583b2 !important;
        }

        .btn-outline-primary:hover,
        .btn-outline-primary:focus {
            border-color: #07a7e3 !important;
            color: #07a7e3 !important;
        }

        .btn-outline-primary:not([disabled]):not(.disabled).active,
        .btn-outline-primary:not([disabled]):not(.disabled):active,
        .show > .btn-outline-primary.dropdown-toggle {
            background-color: #07a7e3 !important;
            color: #FFFFFF !important;
        }

        .btn-outline-secondary {
            border-color: #4f5b60 !important;
            color: #384044 !important;
        }

        .btn-outline-secondary .batch-icon {
            color: #384044 !important;
        }

        .btn-outline-secondary:hover,
        .btn-outline-secondary:focus {
            border-color: #4f5b60 !important;
            color: #4f5b60 !important;
        }

        .btn-outline-secondary:not([disabled]):not(.disabled).active,
        .btn-outline-secondary:not([disabled]):not(.disabled):active,
        .show > .btn-outline-secondary.dropdown-toggle {
            background-color: #4f5b60 !important;
            color: #FFFFFF !important;
        }

        .btn-outline-success {
            border-color: #0ad251 !important;
            color: #08a13e !important;
        }

        .btn-outline-success .batch-icon {
            color: #08a13e !important;
        }

        .btn-outline-success:hover,
        .btn-outline-success:focus {
            border-color: #0ad251 !important;
            color: #0ad251 !important;
        }

        .btn-outline-success:not([disabled]):not(.disabled).active,
        .btn-outline-success:not([disabled]):not(.disabled):active,
        .show > .btn-outline-success.dropdown-toggle {
            background-color: #0ad251 !important;
            color: #FFFFFF !important;
        }

        .btn-outline-info {
            border-color: #55d3f5 !important;
            color: #25c7f2 !important;
        }

        .btn-outline-info .batch-icon {
            color: #25c7f2 !important;
        }

        .btn-outline-info:hover,
        .btn-outline-info:focus {
            border-color: #55d3f5 !important;
            color: #55d3f5 !important;
        }

        .btn-outline-info:not([disabled]):not(.disabled).active,
        .btn-outline-info:not([disabled]):not(.disabled):active,
        .show > .btn-outline-info.dropdown-toggle {
            background-color: #55d3f5 !important;
            color: #FFFFFF !important;
        }

        .btn-outline-warning {
            border-color: #fce418 !important;
            color: #dec703 !important;
        }

        .btn-outline-warning .batch-icon {
            color: #dec703 !important;
        }

        .btn-outline-warning:hover,
        .btn-outline-warning:focus {
            border-color: #fce418 !important;
            color: #fce418 !important;
        }

        .btn-outline-warning:not([disabled]):not(.disabled).active,
        .btn-outline-warning:not([disabled]):not(.disabled):active,
        .show > .btn-outline-warning.dropdown-toggle {
            background-color: #fce418 !important;
            color: #FFFFFF !important;
        }

        .btn-outline-danger {
            border-color: #f43a59 !important;
            color: #ee0d33 !important;
        }

        .btn-outline-danger .batch-icon {
            color: #ee0d33 !important;
        }

        .btn-outline-danger:hover,
        .btn-outline-danger:focus {
            border-color: #f43a59 !important;
            color: #f43a59 !important;
        }

        .btn-outline-danger:not([disabled]):not(.disabled).active,
        .btn-outline-danger:not([disabled]):not(.disabled):active,
        .show > .btn-outline-danger.dropdown-toggle {
            background-color: #f43a59 !important;
            color: #FFFFFF !important;
        }

        .btn-outline-light:hover,
        .btn-outline-light:focus {
            border: 1px solid #212628;
            color: #212628 !important;
        }

        .btn-outline-light:not([disabled]):not(.disabled).active,
        .btn-outline-light:not([disabled]):not(.disabled):active,
        .show > .btn-outline-light.dropdown-toggle {
            background-color: #212628 !important;
            color: #FFFFFF !important;
        }

        .btn[class*=btn-outline-] {
            padding: calc(.95rem + -1px) calc(2.13rem + -1px) calc(.85rem + -1px) !important;
            border-width: 1px !important;
            -webkit-transition: opacity 0.225s ease-in-out;
            -moz-transition: opacity 0.225s ease-in-out;
            -o-transition: opacity 0.225s ease-in-out;
            transition: opacity 0.225s ease-in-out;
        }

        .btn[class*=btn-outline-]:hover,
        .btn[class*=btn-outline-]:focus {
            opacity: 0.7;
        }

        .btn[class*=btn-outline-][class*=btn-sm] {
            padding: calc(.5rem + -1px) calc(1.6rem + -1px) !important;
            border-width: 1px !important;
            -webkit-transition: opacity 0.225s ease-in-out;
            -moz-transition: opacity 0.225s ease-in-out;
            -o-transition: opacity 0.225s ease-in-out;
            transition: opacity 0.225s ease-in-out;
        }

        .btn[class*=btn-outline-][class*=btn-lg] {
            padding: calc(1rem + -1px) calc(2.4rem + -1px) !important;
            border-width: 1px !important;
            -webkit-transition: opacity 0.225s ease-in-out;
            -moz-transition: opacity 0.225s ease-in-out;
            -o-transition: opacity 0.225s ease-in-out;
            transition: opacity 0.225s ease-in-out;
        }

        .btn-group-lg > .btn {
            padding: 1rem 2.4rem;
        }

        .btn-group > .btn-group:not(:last-child) > .btn,
        .btn-group > .btn:not(:last-child):not(.dropdown-toggle) {
            margin-right: 2px;
        }

        .btn-gradient:after {
            position: absolute;
            content: ' ';
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            z-index: 2;
            opacity: 0;
        }

        .btn-gradient:after {
            position: absolute;
            content: ' ';
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            z-index: 2;
            opacity: 0;
        }

        .btn-primary.btn-gradient {
            background: #07a7e3;
            /* Old browsers */
            background: -moz-linear-gradient(-45deg, #07a7e3 0%, #32dac3 100%);
            /* FF3.6-15 */
            background: -webkit-linear-gradient(-45deg, #07a7e3 0%, #32dac3 100%);
            /* Chrome10-25,Safari5.1-6 */
            background: linear-gradient(135deg, #07a7e3 0%, #32dac3 100%);
            /* W3C, IE10+, FF16+, Chrome26+, Opera12+, Safari7+ */
            filter: progid:DXImageTransform.Microsoft.gradient(startColorstr=$ qp-color-1, endColorstr=$ qp-color-2, GradientType=1);
            /* IE6-9 fallback on horizontal gradient */
            -webkit-transition: opacity 0.2s ease-out;
            -moz-transition: opacity 0.2s ease-out;
            -o-transition: opacity 0.2s ease-out;
            transition: opacity 0.2s ease-out;
        }

        .btn-primary.btn-gradient:focus,
        .btn-primary.btn-gradient.focus,
        .btn-primary.btn-gradient:hover,
        .btn-primary.btn-gradient.dropdown-toggle:hover {
            background-color: #32dac3 !important;
        }

        .btn-primary.btn-gradient:after {
            background: #32dac3;
            /* Old browsers */
            background: -moz-linear-gradient(-45deg, #32dac3 0%, #32dac3 100%);
            /* FF3.6-15 */
            background: -webkit-linear-gradient(-45deg, #32dac3 0%, #32dac3 100%);
            /* Chrome10-25,Safari5.1-6 */
            background: linear-gradient(135deg, #32dac3 0%, #32dac3 100%);
            /* W3C, IE10+, FF16+, Chrome26+, Opera12+, Safari7+ */
            filter: progid:DXImageTransform.Microsoft.gradient(startColorstr=$ qp-color-1, endColorstr=$ qp-color-2, GradientType=1);
            /* IE6-9 fallback on horizontal gradient */
            -webkit-transition: opacity 0.2s ease-out;
            -moz-transition: opacity 0.2s ease-out;
            -o-transition: opacity 0.2s ease-out;
            transition: opacity 0.2s ease-out;
        }

        .btn-primary.btn-gradient:hover:after {
            opacity: 1;
        }

        .btn-primary.btn-gradient span.gradient {
            position: relative;
            z-index: 3;
        }

        .btn-primary.btn-gradient:not([disabled]):not(.disabled).active,
        .btn-primary.btn-gradient:not([disabled]):not(.disabled):active,
        .show > .btn-primary.btn-gradient.dropdown-toggle {
            background: #32dac3;
            /* Old browsers */
            background: -moz-linear-gradient(-45deg, #32dac3 0%, #32dac3 100%);
            /* FF3.6-15 */
            background: -webkit-linear-gradient(-45deg, #32dac3 0%, #32dac3 100%);
            /* Chrome10-25,Safari5.1-6 */
            background: linear-gradient(135deg, #32dac3 0%, #32dac3 100%);
            /* W3C, IE10+, FF16+, Chrome26+, Opera12+, Safari7+ */
            filter: progid:DXImageTransform.Microsoft.gradient(startColorstr=$ qp-color-1, endColorstr=$ qp-color-2, GradientType=1);
            /* IE6-9 fallback on horizontal gradient */
            -webkit-transition: opacity 0.2s ease-out;
            -moz-transition: opacity 0.2s ease-out;
            -o-transition: opacity 0.2s ease-out;
            transition: opacity 0.2s ease-out;
        }

        .btn-primary.btn-gradient:active:hover:after {
            background: 0;
            /* Old browsers */
            background: -moz-linear-gradient(-45deg, 0 0%, 0 100%);
            /* FF3.6-15 */
            background: -webkit-linear-gradient(-45deg, 0 0%, 0 100%);
            /* Chrome10-25,Safari5.1-6 */
            background: linear-gradient(135deg, 0 0%, 0 100%);
            /* W3C, IE10+, FF16+, Chrome26+, Opera12+, Safari7+ */
            filter: progid:DXImageTransform.Microsoft.gradient(startColorstr=$ qp-color-1, endColorstr=$ qp-color-2, GradientType=1);
            /* IE6-9 fallback on horizontal gradient */
            -webkit-transition: opacity 0.2s ease-out;
            -moz-transition: opacity 0.2s ease-out;
            -o-transition: opacity 0.2s ease-out;
            transition: opacity 0.2s ease-out;
        }

        .btn-primary.btn-gradient.disabled:hover,
        .btn-primary.btn-gradient:disabled:hover {
            background-color: #000;
            background: #07a7e3;
            /* Old browsers */
            background: -moz-linear-gradient(-45deg, #07a7e3 0%, #32dac3 100%);
            /* FF3.6-15 */
            background: -webkit-linear-gradient(-45deg, #07a7e3 0%, #32dac3 100%);
            /* Chrome10-25,Safari5.1-6 */
            background: linear-gradient(135deg, #07a7e3 0%, #32dac3 100%);
            /* W3C, IE10+, FF16+, Chrome26+, Opera12+, Safari7+ */
            filter: progid:DXImageTransform.Microsoft.gradient(startColorstr=$ qp-color-1, endColorstr=$ qp-color-2, GradientType=1);
            /* IE6-9 fallback on horizontal gradient */
            -webkit-transition: opacity 0.2s ease-out;
            -moz-transition: opacity 0.2s ease-out;
            -o-transition: opacity 0.2s ease-out;
            transition: opacity 0.2s ease-out;
        }

        .btn-primary.btn-gradient.disabled:hover:after,
        .btn-primary.btn-gradient:disabled:hover:after {
            display: none;
        }

        .btn-secondary.btn-gradient {
            background: #4f5b60;
            /* Old browsers */
            background: -moz-linear-gradient(-45deg, #4f5b60 0%, #97a9b2 100%);
            /* FF3.6-15 */
            background: -webkit-linear-gradient(-45deg, #4f5b60 0%, #97a9b2 100%);
            /* Chrome10-25,Safari5.1-6 */
            background: linear-gradient(135deg, #4f5b60 0%, #97a9b2 100%);
            /* W3C, IE10+, FF16+, Chrome26+, Opera12+, Safari7+ */
            filter: progid:DXImageTransform.Microsoft.gradient(startColorstr=$ qp-color-1, endColorstr=$ qp-color-2, GradientType=1);
            /* IE6-9 fallback on horizontal gradient */
            -webkit-transition: opacity 0.2s ease-out;
            -moz-transition: opacity 0.2s ease-out;
            -o-transition: opacity 0.2s ease-out;
            transition: opacity 0.2s ease-out;
        }

        .btn-secondary.btn-gradient:focus,
        .btn-secondary.btn-gradient.focus,
        .btn-secondary.btn-gradient:hover,
        .btn-secondary.btn-gradient.dropdown-toggle:hover {
            background-color: #97a9b2 !important;
        }

        .btn-secondary.btn-gradient:after {
            background: #97a9b2;
            /* Old browsers */
            background: -moz-linear-gradient(-45deg, #97a9b2 0%, #97a9b2 100%);
            /* FF3.6-15 */
            background: -webkit-linear-gradient(-45deg, #97a9b2 0%, #97a9b2 100%);
            /* Chrome10-25,Safari5.1-6 */
            background: linear-gradient(135deg, #97a9b2 0%, #97a9b2 100%);
            /* W3C, IE10+, FF16+, Chrome26+, Opera12+, Safari7+ */
            filter: progid:DXImageTransform.Microsoft.gradient(startColorstr=$ qp-color-1, endColorstr=$ qp-color-2, GradientType=1);
            /* IE6-9 fallback on horizontal gradient */
            -webkit-transition: opacity 0.2s ease-out;
            -moz-transition: opacity 0.2s ease-out;
            -o-transition: opacity 0.2s ease-out;
            transition: opacity 0.2s ease-out;
        }

        .btn-secondary.btn-gradient:hover:after {
            opacity: 1;
        }

        .btn-secondary.btn-gradient span.gradient {
            position: relative;
            z-index: 3;
        }

        .btn-secondary.btn-gradient:not([disabled]):not(.disabled).active,
        .btn-secondary.btn-gradient:not([disabled]):not(.disabled):active,
        .show > .btn-secondary.btn-gradient.dropdown-toggle {
            background: #97a9b2;
            /* Old browsers */
            background: -moz-linear-gradient(-45deg, #97a9b2 0%, #97a9b2 100%);
            /* FF3.6-15 */
            background: -webkit-linear-gradient(-45deg, #97a9b2 0%, #97a9b2 100%);
            /* Chrome10-25,Safari5.1-6 */
            background: linear-gradient(135deg, #97a9b2 0%, #97a9b2 100%);
            /* W3C, IE10+, FF16+, Chrome26+, Opera12+, Safari7+ */
            filter: progid:DXImageTransform.Microsoft.gradient(startColorstr=$ qp-color-1, endColorstr=$ qp-color-2, GradientType=1);
            /* IE6-9 fallback on horizontal gradient */
            -webkit-transition: opacity 0.2s ease-out;
            -moz-transition: opacity 0.2s ease-out;
            -o-transition: opacity 0.2s ease-out;
            transition: opacity 0.2s ease-out;
        }

        .btn-secondary.btn-gradient:active:hover:after {
            background: 0;
            /* Old browsers */
            background: -moz-linear-gradient(-45deg, 0 0%, 0 100%);
            /* FF3.6-15 */
            background: -webkit-linear-gradient(-45deg, 0 0%, 0 100%);
            /* Chrome10-25,Safari5.1-6 */
            background: linear-gradient(135deg, 0 0%, 0 100%);
            /* W3C, IE10+, FF16+, Chrome26+, Opera12+, Safari7+ */
            filter: progid:DXImageTransform.Microsoft.gradient(startColorstr=$ qp-color-1, endColorstr=$ qp-color-2, GradientType=1);
            /* IE6-9 fallback on horizontal gradient */
            -webkit-transition: opacity 0.2s ease-out;
            -moz-transition: opacity 0.2s ease-out;
            -o-transition: opacity 0.2s ease-out;
            transition: opacity 0.2s ease-out;
        }

        .btn-secondary.btn-gradient.disabled:hover,
        .btn-secondary.btn-gradient:disabled:hover {
            background-color: #000;
            background: #4f5b60;
            /* Old browsers */
            background: -moz-linear-gradient(-45deg, #4f5b60 0%, #97a9b2 100%);
            /* FF3.6-15 */
            background: -webkit-linear-gradient(-45deg, #4f5b60 0%, #97a9b2 100%);
            /* Chrome10-25,Safari5.1-6 */
            background: linear-gradient(135deg, #4f5b60 0%, #97a9b2 100%);
            /* W3C, IE10+, FF16+, Chrome26+, Opera12+, Safari7+ */
            filter: progid:DXImageTransform.Microsoft.gradient(startColorstr=$ qp-color-1, endColorstr=$ qp-color-2, GradientType=1);
            /* IE6-9 fallback on horizontal gradient */
            -webkit-transition: opacity 0.2s ease-out;
            -moz-transition: opacity 0.2s ease-out;
            -o-transition: opacity 0.2s ease-out;
            transition: opacity 0.2s ease-out;
        }

        .btn-secondary.btn-gradient.disabled:hover:after,
        .btn-secondary.btn-gradient:disabled:hover:after {
            display: none;
        }

        .btn-yellow.btn-gradient {
            color: #927f00 !important;
            background: #F8D800;
            /* Old browsers */
            background: -moz-linear-gradient(-45deg, #F8D800 0%, #FDEB71 100%);
            /* FF3.6-15 */
            background: -webkit-linear-gradient(-45deg, #F8D800 0%, #FDEB71 100%);
            /* Chrome10-25,Safari5.1-6 */
            background: linear-gradient(135deg, #F8D800 0%, #FDEB71 100%);
            /* W3C, IE10+, FF16+, Chrome26+, Opera12+, Safari7+ */
            filter: progid:DXImageTransform.Microsoft.gradient(startColorstr=$ qp-color-1, endColorstr=$ qp-color-2, GradientType=1);
            /* IE6-9 fallback on horizontal gradient */
            -webkit-transition: opacity 0.2s ease-out;
            -moz-transition: opacity 0.2s ease-out;
            -o-transition: opacity 0.2s ease-out;
            transition: opacity 0.2s ease-out;
        }

        .btn-yellow.btn-gradient:focus,
        .btn-yellow.btn-gradient.focus,
        .btn-yellow.btn-gradient:hover,
        .btn-yellow.btn-gradient.dropdown-toggle:hover {
            background-color: #FDEB71 !important;
        }

        .btn-yellow.btn-gradient:after {
            background: #FDEB71;
            /* Old browsers */
            background: -moz-linear-gradient(-45deg, #FDEB71 0%, #FDEB71 100%);
            /* FF3.6-15 */
            background: -webkit-linear-gradient(-45deg, #FDEB71 0%, #FDEB71 100%);
            /* Chrome10-25,Safari5.1-6 */
            background: linear-gradient(135deg, #FDEB71 0%, #FDEB71 100%);
            /* W3C, IE10+, FF16+, Chrome26+, Opera12+, Safari7+ */
            filter: progid:DXImageTransform.Microsoft.gradient(startColorstr=$ qp-color-1, endColorstr=$ qp-color-2, GradientType=1);
            /* IE6-9 fallback on horizontal gradient */
            -webkit-transition: opacity 0.2s ease-out;
            -moz-transition: opacity 0.2s ease-out;
            -o-transition: opacity 0.2s ease-out;
            transition: opacity 0.2s ease-out;
        }

        .btn-yellow.btn-gradient:hover:after {
            opacity: 1;
        }

        .btn-yellow.btn-gradient span.gradient {
            position: relative;
            z-index: 3;
        }

        .btn-yellow.btn-gradient:not([disabled]):not(.disabled).active,
        .btn-yellow.btn-gradient:not([disabled]):not(.disabled):active,
        .show > .btn-yellow.btn-gradient.dropdown-toggle {
            background: #FDEB71;
            /* Old browsers */
            background: -moz-linear-gradient(-45deg, #FDEB71 0%, #FDEB71 100%);
            /* FF3.6-15 */
            background: -webkit-linear-gradient(-45deg, #FDEB71 0%, #FDEB71 100%);
            /* Chrome10-25,Safari5.1-6 */
            background: linear-gradient(135deg, #FDEB71 0%, #FDEB71 100%);
            /* W3C, IE10+, FF16+, Chrome26+, Opera12+, Safari7+ */
            filter: progid:DXImageTransform.Microsoft.gradient(startColorstr=$ qp-color-1, endColorstr=$ qp-color-2, GradientType=1);
            /* IE6-9 fallback on horizontal gradient */
            -webkit-transition: opacity 0.2s ease-out;
            -moz-transition: opacity 0.2s ease-out;
            -o-transition: opacity 0.2s ease-out;
            transition: opacity 0.2s ease-out;
        }

        .btn-yellow.btn-gradient:active:hover:after {
            background: 0;
            /* Old browsers */
            background: -moz-linear-gradient(-45deg, 0 0%, 0 100%);
            /* FF3.6-15 */
            background: -webkit-linear-gradient(-45deg, 0 0%, 0 100%);
            /* Chrome10-25,Safari5.1-6 */
            background: linear-gradient(135deg, 0 0%, 0 100%);
            /* W3C, IE10+, FF16+, Chrome26+, Opera12+, Safari7+ */
            filter: progid:DXImageTransform.Microsoft.gradient(startColorstr=$ qp-color-1, endColorstr=$ qp-color-2, GradientType=1);
            /* IE6-9 fallback on horizontal gradient */
            -webkit-transition: opacity 0.2s ease-out;
            -moz-transition: opacity 0.2s ease-out;
            -o-transition: opacity 0.2s ease-out;
            transition: opacity 0.2s ease-out;
        }

        .btn-yellow.btn-gradient.disabled:hover,
        .btn-yellow.btn-gradient:disabled:hover {
            background-color: #000;
            background: #F8D800;
            /* Old browsers */
            background: -moz-linear-gradient(-45deg, #F8D800 0%, #FDEB71 100%);
            /* FF3.6-15 */
            background: -webkit-linear-gradient(-45deg, #F8D800 0%, #FDEB71 100%);
            /* Chrome10-25,Safari5.1-6 */
            background: linear-gradient(135deg, #F8D800 0%, #FDEB71 100%);
            /* W3C, IE10+, FF16+, Chrome26+, Opera12+, Safari7+ */
            filter: progid:DXImageTransform.Microsoft.gradient(startColorstr=$ qp-color-1, endColorstr=$ qp-color-2, GradientType=1);
            /* IE6-9 fallback on horizontal gradient */
            -webkit-transition: opacity 0.2s ease-out;
            -moz-transition: opacity 0.2s ease-out;
            -o-transition: opacity 0.2s ease-out;
            transition: opacity 0.2s ease-out;
        }

        .btn-yellow.btn-gradient.disabled:hover:after,
        .btn-yellow.btn-gradient:disabled:hover:after {
            display: none;
        }

        .btn-blue.btn-gradient {
            background: #3677FF;
            /* Old browsers */
            background: -moz-linear-gradient(-45deg, #3677FF 0%, #FFD26F 100%);
            /* FF3.6-15 */
            background: -webkit-linear-gradient(-45deg, #3677FF 0%, #FFD26F 100%);
            /* Chrome10-25,Safari5.1-6 */
            background: linear-gradient(135deg, #3677FF 0%, #FFD26F 100%);
            /* W3C, IE10+, FF16+, Chrome26+, Opera12+, Safari7+ */
            filter: progid:DXImageTransform.Microsoft.gradient(startColorstr=$ qp-color-1, endColorstr=$ qp-color-2, GradientType=1);
            /* IE6-9 fallback on horizontal gradient */
            -webkit-transition: opacity 0.2s ease-out;
            -moz-transition: opacity 0.2s ease-out;
            -o-transition: opacity 0.2s ease-out;
            transition: opacity 0.2s ease-out;
        }

        .btn-blue.btn-gradient:focus,
        .btn-blue.btn-gradient.focus,
        .btn-blue.btn-gradient:hover,
        .btn-blue.btn-gradient.dropdown-toggle:hover {
            background-color: #FFD26F !important;
        }

        .btn-blue.btn-gradient:after {
            background: #FFD26F;
            /* Old browsers */
            background: -moz-linear-gradient(-45deg, #FFD26F 0%, #FFD26F 100%);
            /* FF3.6-15 */
            background: -webkit-linear-gradient(-45deg, #FFD26F 0%, #FFD26F 100%);
            /* Chrome10-25,Safari5.1-6 */
            background: linear-gradient(135deg, #FFD26F 0%, #FFD26F 100%);
            /* W3C, IE10+, FF16+, Chrome26+, Opera12+, Safari7+ */
            filter: progid:DXImageTransform.Microsoft.gradient(startColorstr=$ qp-color-1, endColorstr=$ qp-color-2, GradientType=1);
            /* IE6-9 fallback on horizontal gradient */
            -webkit-transition: opacity 0.2s ease-out;
            -moz-transition: opacity 0.2s ease-out;
            -o-transition: opacity 0.2s ease-out;
            transition: opacity 0.2s ease-out;
        }

        .btn-blue.btn-gradient:hover:after {
            opacity: 1;
        }

        .btn-blue.btn-gradient span.gradient {
            position: relative;
            z-index: 3;
        }

        .btn-blue.btn-gradient:not([disabled]):not(.disabled).active,
        .btn-blue.btn-gradient:not([disabled]):not(.disabled):active,
        .show > .btn-blue.btn-gradient.dropdown-toggle {
            background: #FFD26F;
            /* Old browsers */
            background: -moz-linear-gradient(-45deg, #FFD26F 0%, #FFD26F 100%);
            /* FF3.6-15 */
            background: -webkit-linear-gradient(-45deg, #FFD26F 0%, #FFD26F 100%);
            /* Chrome10-25,Safari5.1-6 */
            background: linear-gradient(135deg, #FFD26F 0%, #FFD26F 100%);
            /* W3C, IE10+, FF16+, Chrome26+, Opera12+, Safari7+ */
            filter: progid:DXImageTransform.Microsoft.gradient(startColorstr=$ qp-color-1, endColorstr=$ qp-color-2, GradientType=1);
            /* IE6-9 fallback on horizontal gradient */
            -webkit-transition: opacity 0.2s ease-out;
            -moz-transition: opacity 0.2s ease-out;
            -o-transition: opacity 0.2s ease-out;
            transition: opacity 0.2s ease-out;
        }

        .btn-blue.btn-gradient:active:hover:after {
            background: 0;
            /* Old browsers */
            background: -moz-linear-gradient(-45deg, 0 0%, 0 100%);
            /* FF3.6-15 */
            background: -webkit-linear-gradient(-45deg, 0 0%, 0 100%);
            /* Chrome10-25,Safari5.1-6 */
            background: linear-gradient(135deg, 0 0%, 0 100%);
            /* W3C, IE10+, FF16+, Chrome26+, Opera12+, Safari7+ */
            filter: progid:DXImageTransform.Microsoft.gradient(startColorstr=$ qp-color-1, endColorstr=$ qp-color-2, GradientType=1);
            /* IE6-9 fallback on horizontal gradient */
            -webkit-transition: opacity 0.2s ease-out;
            -moz-transition: opacity 0.2s ease-out;
            -o-transition: opacity 0.2s ease-out;
            transition: opacity 0.2s ease-out;
        }

        .btn-blue.btn-gradient.disabled:hover,
        .btn-blue.btn-gradient:disabled:hover {
            background-color: #000;
            background: #3677FF;
            /* Old browsers */
            background: -moz-linear-gradient(-45deg, #3677FF 0%, #FFD26F 100%);
            /* FF3.6-15 */
            background: -webkit-linear-gradient(-45deg, #3677FF 0%, #FFD26F 100%);
            /* Chrome10-25,Safari5.1-6 */
            background: linear-gradient(135deg, #3677FF 0%, #FFD26F 100%);
            /* W3C, IE10+, FF16+, Chrome26+, Opera12+, Safari7+ */
            filter: progid:DXImageTransform.Microsoft.gradient(startColorstr=$ qp-color-1, endColorstr=$ qp-color-2, GradientType=1);
            /* IE6-9 fallback on horizontal gradient */
            -webkit-transition: opacity 0.2s ease-out;
            -moz-transition: opacity 0.2s ease-out;
            -o-transition: opacity 0.2s ease-out;
            transition: opacity 0.2s ease-out;
        }

        .btn-blue.btn-gradient.disabled:hover:after,
        .btn-blue.btn-gradient:disabled:hover:after {
            display: none;
        }

        .btn-red.btn-gradient {
            background: #EA5455;
            /* Old browsers */
            background: -moz-linear-gradient(-45deg, #EA5455 0%, #FC9131 100%);
            /* FF3.6-15 */
            background: -webkit-linear-gradient(-45deg, #EA5455 0%, #FC9131 100%);
            /* Chrome10-25,Safari5.1-6 */
            background: linear-gradient(135deg, #EA5455 0%, #FC9131 100%);
            /* W3C, IE10+, FF16+, Chrome26+, Opera12+, Safari7+ */
            filter: progid:DXImageTransform.Microsoft.gradient(startColorstr=$ qp-color-1, endColorstr=$ qp-color-2, GradientType=1);
            /* IE6-9 fallback on horizontal gradient */
            -webkit-transition: opacity 0.2s ease-out;
            -moz-transition: opacity 0.2s ease-out;
            -o-transition: opacity 0.2s ease-out;
            transition: opacity 0.2s ease-out;
        }

        .btn-red.btn-gradient:focus,
        .btn-red.btn-gradient.focus,
        .btn-red.btn-gradient:hover,
        .btn-red.btn-gradient.dropdown-toggle:hover {
            background-color: #FC9131 !important;
        }

        .btn-red.btn-gradient:after {
            background: #FC9131;
            /* Old browsers */
            background: -moz-linear-gradient(-45deg, #FC9131 0%, #FC9131 100%);
            /* FF3.6-15 */
            background: -webkit-linear-gradient(-45deg, #FC9131 0%, #FC9131 100%);
            /* Chrome10-25,Safari5.1-6 */
            background: linear-gradient(135deg, #FC9131 0%, #FC9131 100%);
            /* W3C, IE10+, FF16+, Chrome26+, Opera12+, Safari7+ */
            filter: progid:DXImageTransform.Microsoft.gradient(startColorstr=$ qp-color-1, endColorstr=$ qp-color-2, GradientType=1);
            /* IE6-9 fallback on horizontal gradient */
            -webkit-transition: opacity 0.2s ease-out;
            -moz-transition: opacity 0.2s ease-out;
            -o-transition: opacity 0.2s ease-out;
            transition: opacity 0.2s ease-out;
        }

        .btn-red.btn-gradient:hover:after {
            opacity: 1;
        }

        .btn-red.btn-gradient span.gradient {
            position: relative;
            z-index: 3;
        }

        .btn-red.btn-gradient:not([disabled]):not(.disabled).active,
        .btn-red.btn-gradient:not([disabled]):not(.disabled):active,
        .show > .btn-red.btn-gradient.dropdown-toggle {
            background: #FC9131;
            /* Old browsers */
            background: -moz-linear-gradient(-45deg, #FC9131 0%, #FC9131 100%);
            /* FF3.6-15 */
            background: -webkit-linear-gradient(-45deg, #FC9131 0%, #FC9131 100%);
            /* Chrome10-25,Safari5.1-6 */
            background: linear-gradient(135deg, #FC9131 0%, #FC9131 100%);
            /* W3C, IE10+, FF16+, Chrome26+, Opera12+, Safari7+ */
            filter: progid:DXImageTransform.Microsoft.gradient(startColorstr=$ qp-color-1, endColorstr=$ qp-color-2, GradientType=1);
            /* IE6-9 fallback on horizontal gradient */
            -webkit-transition: opacity 0.2s ease-out;
            -moz-transition: opacity 0.2s ease-out;
            -o-transition: opacity 0.2s ease-out;
            transition: opacity 0.2s ease-out;
        }

        .btn-red.btn-gradient:active:hover:after {
            background: 0;
            /* Old browsers */
            background: -moz-linear-gradient(-45deg, 0 0%, 0 100%);
            /* FF3.6-15 */
            background: -webkit-linear-gradient(-45deg, 0 0%, 0 100%);
            /* Chrome10-25,Safari5.1-6 */
            background: linear-gradient(135deg, 0 0%, 0 100%);
            /* W3C, IE10+, FF16+, Chrome26+, Opera12+, Safari7+ */
            filter: progid:DXImageTransform.Microsoft.gradient(startColorstr=$ qp-color-1, endColorstr=$ qp-color-2, GradientType=1);
            /* IE6-9 fallback on horizontal gradient */
            -webkit-transition: opacity 0.2s ease-out;
            -moz-transition: opacity 0.2s ease-out;
            -o-transition: opacity 0.2s ease-out;
            transition: opacity 0.2s ease-out;
        }

        .btn-red.btn-gradient.disabled:hover,
        .btn-red.btn-gradient:disabled:hover {
            background-color: #000;
            background: #EA5455;
            /* Old browsers */
            background: -moz-linear-gradient(-45deg, #EA5455 0%, #FC9131 100%);
            /* FF3.6-15 */
            background: -webkit-linear-gradient(-45deg, #EA5455 0%, #FC9131 100%);
            /* Chrome10-25,Safari5.1-6 */
            background: linear-gradient(135deg, #EA5455 0%, #FC9131 100%);
            /* W3C, IE10+, FF16+, Chrome26+, Opera12+, Safari7+ */
            filter: progid:DXImageTransform.Microsoft.gradient(startColorstr=$ qp-color-1, endColorstr=$ qp-color-2, GradientType=1);
            /* IE6-9 fallback on horizontal gradient */
            -webkit-transition: opacity 0.2s ease-out;
            -moz-transition: opacity 0.2s ease-out;
            -o-transition: opacity 0.2s ease-out;
            transition: opacity 0.2s ease-out;
        }

        .btn-red.btn-gradient.disabled:hover:after,
        .btn-red.btn-gradient:disabled:hover:after {
            display: none;
        }

        .btn-purple.btn-gradient {
            background: #973999;
            /* Old browsers */
            background: -moz-linear-gradient(-45deg, #973999 0%, #43CBFF 100%);
            /* FF3.6-15 */
            background: -webkit-linear-gradient(-45deg, #973999 0%, #43CBFF 100%);
            /* Chrome10-25,Safari5.1-6 */
            background: linear-gradient(135deg, #973999 0%, #43CBFF 100%);
            /* W3C, IE10+, FF16+, Chrome26+, Opera12+, Safari7+ */
            filter: progid:DXImageTransform.Microsoft.gradient(startColorstr=$ qp-color-1, endColorstr=$ qp-color-2, GradientType=1);
            /* IE6-9 fallback on horizontal gradient */
            -webkit-transition: opacity 0.2s ease-out;
            -moz-transition: opacity 0.2s ease-out;
            -o-transition: opacity 0.2s ease-out;
            transition: opacity 0.2s ease-out;
        }

        .btn-purple.btn-gradient:focus,
        .btn-purple.btn-gradient.focus,
        .btn-purple.btn-gradient:hover,
        .btn-purple.btn-gradient.dropdown-toggle:hover {
            background-color: #43CBFF !important;
        }

        .btn-purple.btn-gradient:after {
            background: #43CBFF;
            /* Old browsers */
            background: -moz-linear-gradient(-45deg, #43CBFF 0%, #43CBFF 100%);
            /* FF3.6-15 */
            background: -webkit-linear-gradient(-45deg, #43CBFF 0%, #43CBFF 100%);
            /* Chrome10-25,Safari5.1-6 */
            background: linear-gradient(135deg, #43CBFF 0%, #43CBFF 100%);
            /* W3C, IE10+, FF16+, Chrome26+, Opera12+, Safari7+ */
            filter: progid:DXImageTransform.Microsoft.gradient(startColorstr=$ qp-color-1, endColorstr=$ qp-color-2, GradientType=1);
            /* IE6-9 fallback on horizontal gradient */
            -webkit-transition: opacity 0.2s ease-out;
            -moz-transition: opacity 0.2s ease-out;
            -o-transition: opacity 0.2s ease-out;
            transition: opacity 0.2s ease-out;
        }

        .btn-purple.btn-gradient:hover:after {
            opacity: 1;
        }

        .btn-purple.btn-gradient span.gradient {
            position: relative;
            z-index: 3;
        }

        .btn-purple.btn-gradient:not([disabled]):not(.disabled).active,
        .btn-purple.btn-gradient:not([disabled]):not(.disabled):active,
        .show > .btn-purple.btn-gradient.dropdown-toggle {
            background: #43CBFF;
            /* Old browsers */
            background: -moz-linear-gradient(-45deg, #43CBFF 0%, #43CBFF 100%);
            /* FF3.6-15 */
            background: -webkit-linear-gradient(-45deg, #43CBFF 0%, #43CBFF 100%);
            /* Chrome10-25,Safari5.1-6 */
            background: linear-gradient(135deg, #43CBFF 0%, #43CBFF 100%);
            /* W3C, IE10+, FF16+, Chrome26+, Opera12+, Safari7+ */
            filter: progid:DXImageTransform.Microsoft.gradient(startColorstr=$ qp-color-1, endColorstr=$ qp-color-2, GradientType=1);
            /* IE6-9 fallback on horizontal gradient */
            -webkit-transition: opacity 0.2s ease-out;
            -moz-transition: opacity 0.2s ease-out;
            -o-transition: opacity 0.2s ease-out;
            transition: opacity 0.2s ease-out;
        }

        .btn-purple.btn-gradient:active:hover:after {
            background: 0;
            /* Old browsers */
            background: -moz-linear-gradient(-45deg, 0 0%, 0 100%);
            /* FF3.6-15 */
            background: -webkit-linear-gradient(-45deg, 0 0%, 0 100%);
            /* Chrome10-25,Safari5.1-6 */
            background: linear-gradient(135deg, 0 0%, 0 100%);
            /* W3C, IE10+, FF16+, Chrome26+, Opera12+, Safari7+ */
            filter: progid:DXImageTransform.Microsoft.gradient(startColorstr=$ qp-color-1, endColorstr=$ qp-color-2, GradientType=1);
            /* IE6-9 fallback on horizontal gradient */
            -webkit-transition: opacity 0.2s ease-out;
            -moz-transition: opacity 0.2s ease-out;
            -o-transition: opacity 0.2s ease-out;
            transition: opacity 0.2s ease-out;
        }

        .btn-purple.btn-gradient.disabled:hover,
        .btn-purple.btn-gradient:disabled:hover {
            background-color: #000;
            background: #973999;
            /* Old browsers */
            background: -moz-linear-gradient(-45deg, #973999 0%, #43CBFF 100%);
            /* FF3.6-15 */
            background: -webkit-linear-gradient(-45deg, #973999 0%, #43CBFF 100%);
            /* Chrome10-25,Safari5.1-6 */
            background: linear-gradient(135deg, #973999 0%, #43CBFF 100%);
            /* W3C, IE10+, FF16+, Chrome26+, Opera12+, Safari7+ */
            filter: progid:DXImageTransform.Microsoft.gradient(startColorstr=$ qp-color-1, endColorstr=$ qp-color-2, GradientType=1);
            /* IE6-9 fallback on horizontal gradient */
            -webkit-transition: opacity 0.2s ease-out;
            -moz-transition: opacity 0.2s ease-out;
            -o-transition: opacity 0.2s ease-out;
            transition: opacity 0.2s ease-out;
        }

        .btn-purple.btn-gradient.disabled:hover:after,
        .btn-purple.btn-gradient:disabled:hover:after {
            display: none;
        }

        .btn-orange.btn-gradient {
            background: #FC9131;
            /* Old browsers */
            background: -moz-linear-gradient(-45deg, #FC9131 0%, #FCCF31 100%);
            /* FF3.6-15 */
            background: -webkit-linear-gradient(-45deg, #FC9131 0%, #FCCF31 100%);
            /* Chrome10-25,Safari5.1-6 */
            background: linear-gradient(135deg, #FC9131 0%, #FCCF31 100%);
            /* W3C, IE10+, FF16+, Chrome26+, Opera12+, Safari7+ */
            filter: progid:DXImageTransform.Microsoft.gradient(startColorstr=$ qp-color-1, endColorstr=$ qp-color-2, GradientType=1);
            /* IE6-9 fallback on horizontal gradient */
            -webkit-transition: opacity 0.2s ease-out;
            -moz-transition: opacity 0.2s ease-out;
            -o-transition: opacity 0.2s ease-out;
            transition: opacity 0.2s ease-out;
        }

        .btn-orange.btn-gradient:focus,
        .btn-orange.btn-gradient.focus,
        .btn-orange.btn-gradient:hover,
        .btn-orange.btn-gradient.dropdown-toggle:hover {
            background-color: #FCCF31 !important;
        }

        .btn-orange.btn-gradient:after {
            background: #FCCF31;
            /* Old browsers */
            background: -moz-linear-gradient(-45deg, #FCCF31 0%, #FCCF31 100%);
            /* FF3.6-15 */
            background: -webkit-linear-gradient(-45deg, #FCCF31 0%, #FCCF31 100%);
            /* Chrome10-25,Safari5.1-6 */
            background: linear-gradient(135deg, #FCCF31 0%, #FCCF31 100%);
            /* W3C, IE10+, FF16+, Chrome26+, Opera12+, Safari7+ */
            filter: progid:DXImageTransform.Microsoft.gradient(startColorstr=$ qp-color-1, endColorstr=$ qp-color-2, GradientType=1);
            /* IE6-9 fallback on horizontal gradient */
            -webkit-transition: opacity 0.2s ease-out;
            -moz-transition: opacity 0.2s ease-out;
            -o-transition: opacity 0.2s ease-out;
            transition: opacity 0.2s ease-out;
        }

        .btn-orange.btn-gradient:hover:after {
            opacity: 1;
        }

        .btn-orange.btn-gradient span.gradient {
            position: relative;
            z-index: 3;
        }

        .btn-orange.btn-gradient:not([disabled]):not(.disabled).active,
        .btn-orange.btn-gradient:not([disabled]):not(.disabled):active,
        .show > .btn-orange.btn-gradient.dropdown-toggle {
            background: #FCCF31;
            /* Old browsers */
            background: -moz-linear-gradient(-45deg, #FCCF31 0%, #FCCF31 100%);
            /* FF3.6-15 */
            background: -webkit-linear-gradient(-45deg, #FCCF31 0%, #FCCF31 100%);
            /* Chrome10-25,Safari5.1-6 */
            background: linear-gradient(135deg, #FCCF31 0%, #FCCF31 100%);
            /* W3C, IE10+, FF16+, Chrome26+, Opera12+, Safari7+ */
            filter: progid:DXImageTransform.Microsoft.gradient(startColorstr=$ qp-color-1, endColorstr=$ qp-color-2, GradientType=1);
            /* IE6-9 fallback on horizontal gradient */
            -webkit-transition: opacity 0.2s ease-out;
            -moz-transition: opacity 0.2s ease-out;
            -o-transition: opacity 0.2s ease-out;
            transition: opacity 0.2s ease-out;
        }

        .btn-orange.btn-gradient:active:hover:after {
            background: 0;
            /* Old browsers */
            background: -moz-linear-gradient(-45deg, 0 0%, 0 100%);
            /* FF3.6-15 */
            background: -webkit-linear-gradient(-45deg, 0 0%, 0 100%);
            /* Chrome10-25,Safari5.1-6 */
            background: linear-gradient(135deg, 0 0%, 0 100%);
            /* W3C, IE10+, FF16+, Chrome26+, Opera12+, Safari7+ */
            filter: progid:DXImageTransform.Microsoft.gradient(startColorstr=$ qp-color-1, endColorstr=$ qp-color-2, GradientType=1);
            /* IE6-9 fallback on horizontal gradient */
            -webkit-transition: opacity 0.2s ease-out;
            -moz-transition: opacity 0.2s ease-out;
            -o-transition: opacity 0.2s ease-out;
            transition: opacity 0.2s ease-out;
        }

        .btn-orange.btn-gradient.disabled:hover,
        .btn-orange.btn-gradient:disabled:hover {
            background-color: #000;
            background: #FC9131;
            /* Old browsers */
            background: -moz-linear-gradient(-45deg, #FC9131 0%, #FCCF31 100%);
            /* FF3.6-15 */
            background: -webkit-linear-gradient(-45deg, #FC9131 0%, #FCCF31 100%);
            /* Chrome10-25,Safari5.1-6 */
            background: linear-gradient(135deg, #FC9131 0%, #FCCF31 100%);
            /* W3C, IE10+, FF16+, Chrome26+, Opera12+, Safari7+ */
            filter: progid:DXImageTransform.Microsoft.gradient(startColorstr=$ qp-color-1, endColorstr=$ qp-color-2, GradientType=1);
            /* IE6-9 fallback on horizontal gradient */
            -webkit-transition: opacity 0.2s ease-out;
            -moz-transition: opacity 0.2s ease-out;
            -o-transition: opacity 0.2s ease-out;
            transition: opacity 0.2s ease-out;
        }

        .btn-orange.btn-gradient.disabled:hover:after,
        .btn-orange.btn-gradient:disabled:hover:after {
            display: none;
        }

        .btn-green.btn-gradient {
            background: #28C76F;
            /* Old browsers */
            background: -moz-linear-gradient(-45deg, #28C76F 0%, #81FBB8 100%);
            /* FF3.6-15 */
            background: -webkit-linear-gradient(-45deg, #28C76F 0%, #81FBB8 100%);
            /* Chrome10-25,Safari5.1-6 */
            background: linear-gradient(135deg, #28C76F 0%, #81FBB8 100%);
            /* W3C, IE10+, FF16+, Chrome26+, Opera12+, Safari7+ */
            filter: progid:DXImageTransform.Microsoft.gradient(startColorstr=$ qp-color-1, endColorstr=$ qp-color-2, GradientType=1);
            /* IE6-9 fallback on horizontal gradient */
            -webkit-transition: opacity 0.2s ease-out;
            -moz-transition: opacity 0.2s ease-out;
            -o-transition: opacity 0.2s ease-out;
            transition: opacity 0.2s ease-out;
        }

        .btn-green.btn-gradient:focus,
        .btn-green.btn-gradient.focus,
        .btn-green.btn-gradient:hover,
        .btn-green.btn-gradient.dropdown-toggle:hover {
            background-color: #81FBB8 !important;
        }

        .btn-green.btn-gradient:after {
            background: #81FBB8;
            /* Old browsers */
            background: -moz-linear-gradient(-45deg, #81FBB8 0%, #81FBB8 100%);
            /* FF3.6-15 */
            background: -webkit-linear-gradient(-45deg, #81FBB8 0%, #81FBB8 100%);
            /* Chrome10-25,Safari5.1-6 */
            background: linear-gradient(135deg, #81FBB8 0%, #81FBB8 100%);
            /* W3C, IE10+, FF16+, Chrome26+, Opera12+, Safari7+ */
            filter: progid:DXImageTransform.Microsoft.gradient(startColorstr=$ qp-color-1, endColorstr=$ qp-color-2, GradientType=1);
            /* IE6-9 fallback on horizontal gradient */
            -webkit-transition: opacity 0.2s ease-out;
            -moz-transition: opacity 0.2s ease-out;
            -o-transition: opacity 0.2s ease-out;
            transition: opacity 0.2s ease-out;
        }

        .btn-green.btn-gradient:hover:after {
            opacity: 1;
        }

        .btn-green.btn-gradient span.gradient {
            position: relative;
            z-index: 3;
        }

        .btn-green.btn-gradient:not([disabled]):not(.disabled).active,
        .btn-green.btn-gradient:not([disabled]):not(.disabled):active,
        .show > .btn-green.btn-gradient.dropdown-toggle {
            background: #81FBB8;
            /* Old browsers */
            background: -moz-linear-gradient(-45deg, #81FBB8 0%, #81FBB8 100%);
            /* FF3.6-15 */
            background: -webkit-linear-gradient(-45deg, #81FBB8 0%, #81FBB8 100%);
            /* Chrome10-25,Safari5.1-6 */
            background: linear-gradient(135deg, #81FBB8 0%, #81FBB8 100%);
            /* W3C, IE10+, FF16+, Chrome26+, Opera12+, Safari7+ */
            filter: progid:DXImageTransform.Microsoft.gradient(startColorstr=$ qp-color-1, endColorstr=$ qp-color-2, GradientType=1);
            /* IE6-9 fallback on horizontal gradient */
            -webkit-transition: opacity 0.2s ease-out;
            -moz-transition: opacity 0.2s ease-out;
            -o-transition: opacity 0.2s ease-out;
            transition: opacity 0.2s ease-out;
        }

        .btn-green.btn-gradient:active:hover:after {
            background: 0;
            /* Old browsers */
            background: -moz-linear-gradient(-45deg, 0 0%, 0 100%);
            /* FF3.6-15 */
            background: -webkit-linear-gradient(-45deg, 0 0%, 0 100%);
            /* Chrome10-25,Safari5.1-6 */
            background: linear-gradient(135deg, 0 0%, 0 100%);
            /* W3C, IE10+, FF16+, Chrome26+, Opera12+, Safari7+ */
            filter: progid:DXImageTransform.Microsoft.gradient(startColorstr=$ qp-color-1, endColorstr=$ qp-color-2, GradientType=1);
            /* IE6-9 fallback on horizontal gradient */
            -webkit-transition: opacity 0.2s ease-out;
            -moz-transition: opacity 0.2s ease-out;
            -o-transition: opacity 0.2s ease-out;
            transition: opacity 0.2s ease-out;
        }

        .btn-green.btn-gradient.disabled:hover,
        .btn-green.btn-gradient:disabled:hover {
            background-color: #000;
            background: #28C76F;
            /* Old browsers */
            background: -moz-linear-gradient(-45deg, #28C76F 0%, #81FBB8 100%);
            /* FF3.6-15 */
            background: -webkit-linear-gradient(-45deg, #28C76F 0%, #81FBB8 100%);
            /* Chrome10-25,Safari5.1-6 */
            background: linear-gradient(135deg, #28C76F 0%, #81FBB8 100%);
            /* W3C, IE10+, FF16+, Chrome26+, Opera12+, Safari7+ */
            filter: progid:DXImageTransform.Microsoft.gradient(startColorstr=$ qp-color-1, endColorstr=$ qp-color-2, GradientType=1);
            /* IE6-9 fallback on horizontal gradient */
            -webkit-transition: opacity 0.2s ease-out;
            -moz-transition: opacity 0.2s ease-out;
            -o-transition: opacity 0.2s ease-out;
            transition: opacity 0.2s ease-out;
        }

        .btn-green.btn-gradient.disabled:hover:after,
        .btn-green.btn-gradient:disabled:hover:after {
            display: none;
        }

        .btn-group > .btn + .btn.dropdown-toggle-split {
            border-left: 1px solid rgba(255, 255, 255, 0.43) !important;
            padding-left: 1rem;
            padding-right: 1rem;
        }

        .btn-group-vertical > .btn {
            margin: 0;
        }

        .btn-group-vertical > .btn:first-child:not(:last-child) {
            margin: 0;
        }

        .btn-group-vertical > *:not(:last-child) {
            margin-bottom: 2px !important;
        }

        .btn-group.btn-group-toggle.btn-group-custom-checkbox .btn::before {
            font-family: "Batch Icons";
            content: "\f020";
            font-weight: 400;
            font-size: 1.3rem;
            position: relative;
            margin-right: 5px;
            line-height: 0.9;
            top: 1px;
        }

        .btn-group.btn-group-toggle.btn-group-custom-checkbox .btn.active::before {
            content: "\f164";
        }

        .btn-group.btn-group-toggle.btn-group-custom-radio .btn::before {
            font-family: "Batch Icons";
            content: "\F0C6";
            font-weight: 400;
            font-size: 1.3rem;
            position: relative;
            margin-right: 5px;
            line-height: 0.9;
            top: 1px;
        }

        .btn-group.btn-group-toggle.btn-group-custom-radio .btn.active::before {
            content: "\F0C7";
        }

        .btn .batch-icon {
            color: #FFFFFF;
            line-height: 1;
        }

        .btn-block {
            margin: auto;
        }

        .dropdown-item .batch-icon {
            color: #97a9b2;
        }

        /* Cards */
        .card,
        .card .card-text {
            font-weight: 400;
        }

        .card .card-body h3,
        .card .card-body h4 {
            font-weight: 300;
        }

        .card {
            height: 100%;
            box-shadow: 0 9px 23px rgba(0, 0, 0, 0.09), 0 5px 5px rgba(0, 0, 0, 0.06) !important;
            -webkit-transition: box-shadow 0.7s cubic-bezier(0.25, 0.8, 0.25, 1) !important;
            -moz-transition: box-shadow 0.7s cubic-bezier(0.25, 0.8, 0.25, 1) !important;
            -o-transition: box-shadow 0.7s cubic-bezier(0.25, 0.8, 0.25, 1) !important;
            transition: box-shadow 0.7s cubic-bezier(0.25, 0.8, 0.25, 1) !important;
            -webkit-border-radius: 0.4167rem;
            -moz-border-radius: 0.4167rem;
            -ms-border-radius: 0.4167rem;
            -o-border-radius: 0.4167rem;
            border-radius: 0.4167rem;
        }

        .card > a > img,
        .card > a > img.img-fluid,
        .card > img,
        .card > img.img-fluid {
            width: 100% !important;
        }

        .card > a:first-child > img,
        .card > img:first-child {
            -webkit-border-top-left-radius: 0.4167rem;
            -moz-border-top-left-radius: 0.4167rem;
            -ms-border-top-left-radius: 0.4167rem;
            -o-border-top-left-radius: 0.4167rem;
            border-top-left-radius: 0.4167rem;
            -webkit-border-top-right-radius: 0.4167rem;
            -moz-border-top-right-radius: 0.4167rem;
            -ms-border-top-right-radius: 0.4167rem;
            -o-border-top-right-radius: 0.4167rem;
            border-top-right-radius: 0.4167rem;
        }

        .card > a:last-child > img,
        .card > img:last-child {
            -webkit-border-bottom-left-radius: 0.4167rem;
            -moz-border-bottom-left-radius: 0.4167rem;
            -ms-border-bottom-left-radius: 0.4167rem;
            -o-border-bottom-left-radius: 0.4167rem;
            border-bottom-left-radius: 0.4167rem;
            -webkit-border-bottom-right-radius: 0.4167rem;
            -moz-border-bottom-right-radius: 0.4167rem;
            -ms-border-bottom-right-radius: 0.4167rem;
            -o-border-bottom-right-radius: 0.4167rem;
            border-bottom-right-radius: 0.4167rem;
        }

        .card .card-header {
            position: relative;
            color: #07a7e3;
            background-color: transparent;
            text-transform: uppercase;
            font-size: 1.333rem;
            border-bottom: 1px solid rgba(0, 0, 0, 0.09);
            padding-top: 2.5rem;
            margin-left: 2.083rem;
            margin-right: 2.083rem;
            padding-left: 0;
            padding-right: 0;
        }

        .card .card-header .header-btn-block {
            position: absolute;
            right: 0;
            top: 18px;
        }

        .card .card-header .header-btn-block .btn {
            margin: 0;
            padding-left: .95rem !important;
            padding-right: .95rem !important;
        }

        .card .card-header .header-btn-block .btn .batch-icon {
            color: #FFFFFF;
        }

        .card .card-header .task-list-stats {
            font-size: 1rem;
            font-weight: 400;
            text-transform: none;
        }

        .card .card-header .progress {
            position: absolute;
            z-index: 1;
            bottom: -2px;
            left: -2.15rem;
            right: -2.15rem;
            width: auto;
            margin: 0;
            -webkit-border-radius: 0 !important;
            -moz-border-radius: 0 !important;
            -ms-border-radius: 0 !important;
            -o-border-radius: 0 !important;
            border-radius: 0 !important;
        }

        .card .card-body {
            padding: 2.083rem;
            font-weight: 400;
        }

        .card .card-body .tile-left {
            position: absolute;
        }

        .card .card-body .tile-left .batch-icon {
            color: #FFFFFF;
        }

        .card .card-body .tile-right {
            text-align: right;
            line-height: 1.618;
        }

        .card .card-body .tile-right .tile-number {
            font-size: 2rem;
            font-weight: 400;
        }

        .card .card-body .card-chart {
            text-align: center;
            margin-left: auto;
            margin-right: auto;
        }

        .card .card-body .card-chart canvas {
            margin-left: auto;
            margin-right: auto;
        }

        .card .card-body .timeline p {
            color: #FFFFFF;
        }

        .card .card-body .timeline h2 {
            background-color: #4f5b60;
            -webkit-border-radius: 0.4167rem;
            -moz-border-radius: 0.4167rem;
            -ms-border-radius: 0.4167rem;
            -o-border-radius: 0.4167rem;
            border-radius: 0.4167rem;
        }

        .card .card-body .timeline .timeline-items {
            padding-top: 30px;
        }

        .card .card-body .timeline .timeline-items .timeline-item {
            left: auto;
            margin-bottom: 60px;
            padding: 2.083rem;
            -webkit-border-radius: 0.4167rem;
            -moz-border-radius: 0.4167rem;
            -ms-border-radius: 0.4167rem;
            -o-border-radius: 0.4167rem;
            border-radius: 0.4167rem;
            -webkit-border-top-right-radius: 0;
            -moz-border-top-right-radius: 0;
            -ms-border-top-right-radius: 0;
            -o-border-top-right-radius: 0;
            border-top-right-radius: 0;
        }

        .card .card-body .timeline .timeline-items .timeline-item hr {
            border-top: 1px solid rgba(255, 255, 255, 0.2);
        }

        .card .card-body .timeline .timeline-items .timeline-item h3 {
            font-weight: 400;
        }

        .card .card-body .timeline .timeline-items .timeline-item time::before {
            font-family: "Batch Icons";
            content: "\f090";
            font-weight: 400;
            font-size: 1.3rem;
        }

        .card .card-body .timeline .timeline-items .timeline-item::after {
            background-color: #4f5b60;
            left: calc(100% + 8.4%);
        }

        .card .card-body .timeline .timeline-items .timeline-item:nth-of-type(2n+1) {
            background-color: #07a7e3;
        }

        .card .card-body .timeline .timeline-items .timeline-item:nth-of-type(2n+1)::before {
            border-top: 1em solid #07a7e3;
        }

        .card .card-body .timeline .timeline-items .timeline-item:nth-of-type(2n) {
            background-color: #32dac3;
        }

        .card .card-body .timeline .timeline-items .timeline-item:nth-of-type(2n)::before {
            border-top: 1em solid #32dac3;
        }

        .card .card-body .timeline .timeline-items .timeline-item.centered:nth-of-type(2n+1)::before {
            border-top: 0;
            border-bottom: 1em solid #07a7e3;
        }

        .card .card-body .timeline .timeline-items .timeline-item.centered:nth-of-type(2n)::before {
            border-top: 0;
            border-bottom: 1em solid #32dac3;
        }

        .card .card-body .timeline .timeline-items .timeline-item.inverted {
            text-align: left;
            left: 54%;
            -webkit-border-top-right-radius: 0.4167rem;
            -moz-border-top-right-radius: 0.4167rem;
            -ms-border-top-right-radius: 0.4167rem;
            -o-border-top-right-radius: 0.4167rem;
            border-top-right-radius: 0.4167rem;
        }

        .card .card-body .timeline .timeline-items .timeline-item.inverted::after {
            left: calc(-8.78% - 13px);
        }

        .card .card-body .timeline .timeline-items .timeline-item.centered {
            margin-top: 100px;
            -webkit-border-top-right-radius: 0.4167rem;
            -moz-border-top-right-radius: 0.4167rem;
            -ms-border-top-right-radius: 0.4167rem;
            -o-border-top-right-radius: 0.4167rem;
            border-top-right-radius: 0.4167rem;
        }

        .card .card-body .timeline .timeline-items .timeline-item.centered::before {
            left: calc(50% - 10px);
        }

        .card .card-body .timeline .timeline-items .timeline-item.centered::after {
            display: block;
            content: '';
            background: #5b5555;
            width: 30px;
            height: 30px;
            position: absolute;
            top: -50px;
            -webkit-border-radius: 100%;
            -moz-border-radius: 100%;
            -ms-border-radius: 100%;
            -o-border-radius: 100%;
            border-radius: 100%;
            left: calc(50% - 12px);
        }

        .card .card-body .timeline::before {
            background-color: #4f5b60;
        }

        .card .card-body .calendar-container .fc.fc-bootstrap3 a,
        .card .card-body .calendar-container .ui-widget .fc-event {
            color: #FFFFFF;
        }

        .card .card-body .calendar-container .fc-more {
            color: #07a7e3 !important;
            text-decoration: underline !important;
        }

        .card .card-body .calendar-container .fc-more:hover,
        .card .card-body .calendar-container .fc-more:focus {
            text-decoration: none !important;
        }

        .card .card-body .calendar-container .fc-more-popover {
            background-color: #FFFFFF;
        }

        .card .card-body .calendar-container .fc.fc-bootstrap3 a:hover,
        .card .card-body .calendar-container .fc.fc-bootstrap3 a:focus,
        .card .card-body .calendar-container .ui-widget .fc-event:hover,
        .card .card-body .calendar-container .ui-widget .fc-event:focus {
            text-decoration: underline;
        }

        .card .card-body .calendar-container .fc-event,
        .card .card-body .calendar-container .fc-event-dot {
            background-color: #07a7e3;
            border: 0;
        }

        .card .card-body .calendar-container .fc-event + .empty-list {
            display: none;
        }

        .card .card-body .calendar-container .calendar-controls .legend-block-color .legend-block-color-box {
            border: 2px solid #FFFFFF;
            height: 40px;
            width: 40px;
            margin: 5px 0;
            padding: 10px;
            -webkit-border-radius: 0.4167rem;
            -moz-border-radius: 0.4167rem;
            -ms-border-radius: 0.4167rem;
            -o-border-radius: 0.4167rem;
            border-radius: 0.4167rem;
        }

        .card .card-body .calendar-container .calendar-controls .legend-block-color .legend-block-color-box i {
            color: #FFFFFF;
        }

        .card .card-body .calendar-container .calendar-controls .input-group .input-group-prepend .dropdown-menu .dropdown-item.legend-block-item,
        .card .card-body .calendar-container .calendar-controls .input-group .input-group-append .dropdown-menu .dropdown-item.legend-block-item {
            float: left;
            width: auto;
            clear: none;
            padding: .25rem 1.66rem;
        }

        .card .card-body .calendar-container .calendar-controls .event-preview .event-preview-item {
            color: #4f5b60;
            background-color: #FFFFFF;
            margin-bottom: 15px;
            border: 2px dashed #d2d2d2;
        }

        .card .card-body .calendar-container .calendar-controls .event-preview .event-preview-item .legend-block-item {
            padding: 2px 1rem;
        }

        .card .card-body .calendar-container .calendar-controls .event-preview .event-preview-item .legend-block-item .legend-block-color {
            display: inline-block;
        }

        .card .card-body .calendar-container .calendar-controls .event-preview .event-preview-item .legend-block-item .legend-block-text {
            display: inline-block;
            margin-left: 5px;
            font-size: 0.85rem;
            color: #4f5b60;
        }

        .card .card-body .calendar-container .calendar-controls .available-events .event-list .fc-event {
            color: #4f5b60;
            background-color: #FFFFFF;
            margin-bottom: 15px;
            cursor: pointer;
            box-shadow: 0 9px 23px rgba(0, 0, 0, 0.09), 0 5px 5px rgba(0, 0, 0, 0.06) !important;
            -webkit-transition: border-color 0.225s ease-in-out, box-shadow 0.225s ease-in-out;
            -moz-transition: border-color 0.225s ease-in-out, box-shadow 0.225s ease-in-out;
            -o-transition: border-color 0.225s ease-in-out, box-shadow 0.225s ease-in-out;
            transition: border-color 0.225s ease-in-out, box-shadow 0.225s ease-in-out;
        }

        .card .card-body .calendar-container .calendar-controls .available-events .event-list .fc-event .legend-block-item {
            padding: 2px 1rem;
        }

        .card .card-body .calendar-container .calendar-controls .available-events .event-list .fc-event .legend-block-item .legend-block-color {
            display: inline-block;
        }

        .card .card-body .calendar-container .calendar-controls .available-events .event-list .fc-event .legend-block-item .legend-block-text {
            display: inline-block;
            margin-left: 5px;
        }

        .card .card-body .calendar-container .calendar-controls .available-events .event-list .fc-event.ui-draggable-dragging {
            border-color: #4f5b60;
        }

        .card .card-body .calendar-container .calendar-controls .available-events .event-list .fc-event:hover,
        .card .card-body .calendar-container .calendar-controls .available-events .event-list .fc-event:focus {
            box-shadow: 0 9px 23px rgba(0, 0, 0, 0.18), 0 5px 5px rgba(0, 0, 0, 0.12) !important;
        }

        .card .card-body .calendar-container #calendar .fc-event .fc-content {
            padding: 2px 8px;
        }

        .card .card-body .calendar-container #calendar .fc-time-grid-event .fc-time {
            padding-top: 3px;
        }

        .card .card-body .calendar-container #calendar .fc-toolbar .fc-center {
            padding-top: 1rem;
            display: grid;
            width: 100%;
        }

        .card .card-body .calendar-container #calendar .fc-toolbar .fc-left,
        .card .card-body .calendar-container #calendar .fc-toolbar .fc-right {
            float: none;
        }

        .card .card-body .calendar-container #calendar .fc-popover {
            box-shadow: 0 7px 23px 0 rgba(0, 0, 0, 0.1), 0 13px 49px 0 rgba(0, 0, 0, 0.06) !important;
        }

        .card .card-body .calendar-container #calendar button {
            height: auto;
            padding: .95rem 2.13rem .85rem;
            box-shadow: none !important;
        }

        .card .card-img {
            -webkit-border-radius: 0.4167rem;
            -moz-border-radius: 0.4167rem;
            -ms-border-radius: 0.4167rem;
            -o-border-radius: 0.4167rem;
            border-radius: 0.4167rem;
        }

        .card .card-img-overlay {
            color: #FFFFFF !important;
            background-color: rgba(0, 0, 0, 0.3);
            -webkit-border-radius: 0.4167rem;
            -moz-border-radius: 0.4167rem;
            -ms-border-radius: 0.4167rem;
            -o-border-radius: 0.4167rem;
            border-radius: 0.4167rem;
        }

        .card .card-img-overlay * {
            color: #FFFFFF !important;
        }

        .card .card-table {
            padding: 0 0 2.083rem;
        }

        .card .card-table table thead tr th:first-child,
        .card .card-table table tfoot tr th:first-child {
            padding-left: 2.083rem;
        }

        .card .card-table table thead tr th:last-child,
        .card .card-table table tfoot tr th:last-child {
            padding-right: 2.083rem;
        }

        .card .card-table table tbody tr > *:first-child {
            padding-left: 2.083rem;
        }

        .card .card-table table tbody tr > *:last-child {
            padding-right: 2.083rem;
        }

        .card .card-media-list {
            height: 100%;
            padding: 0 0 2.083rem;
        }

        .card .card-media-list .media {
            padding: 5px 2.083rem;
        }

        .card .card-media-list .media .heading {
            font-weight: 500;
        }

        .card .card-media-list .media:first-child {
            padding-top: 10px;
        }

        .card .card-media-list .media:last-child {
            padding-bottom: 10px;
        }

        .card .card-mailbox {
            padding: 0;
            /* Email List */
            /* Message View */
            /* Mailbox - Compose */
        }

        .card .card-mailbox .mailbox-menu {
            margin-bottom: 20px;
        }

        .card .card-mailbox .mailbox-menu .mailbox-compose-outer .compose-message {
            margin-top: 3px;
        }

        .card .card-mailbox .mailbox-menu .mailbox-compose-outer .mailbox-mobile-menu-control {
            margin-top: 10px;
            text-transform: uppercase;
        }

        .card .card-mailbox .mailbox-menu .list-group.mailbox-menu-actual {
            display: none;
        }

        .card .card-mailbox .mailbox-menu .list-group.mailbox-menu-actual .list-group-item {
            text-transform: uppercase;
            border: 0;
            background-color: transparent;
        }

        .card .card-mailbox .mailbox-menu .list-group.mailbox-menu-actual .list-group-item .batch-icon {
            margin-right: 0.5rem;
        }

        .card .card-mailbox .mailbox-menu .list-group.mailbox-menu-actual .list-group-item.active {
            background-color: #07a7e3;
            border-color: #07a7e3;
            color: #FFFFFF;
        }

        .card .card-mailbox .mailbox-menu .list-group.mailbox-menu-actual .list-group-item.active .batch-icon {
            color: #FFFFFF;
            margin-right: 0.5rem;
        }

        .card .card-mailbox .mailbox-menu .list-group.mailbox-menu-actual .list-group-item:hover,
        .card .card-mailbox .mailbox-menu .list-group.mailbox-menu-actual .list-group-item:focus {
            background-color: #F7F7FA;
        }

        .card .card-mailbox .mailbox-menu .list-group.mailbox-menu-actual .list-group-item.active:hover,
        .card .card-mailbox .mailbox-menu .list-group.mailbox-menu-actual .list-group-item.active:focus {
            background-color: #07a7e3;
            border-color: #07a7e3;
            opacity: 0.7;
        }

        .card .card-mailbox .mailbox-menu .mailbox-tags {
            padding-top: 10px;
        }

        .card .card-mailbox .mailbox-menu .mailbox-tags .badge {
            margin-bottom: 5px;
        }

        .card .card-mailbox .mailbox-container {
            padding: 2.083rem 0;
        }

        .card .card-mailbox .mailbox-container .mailbox-controls {
            margin-bottom: 20px;
        }

        .card .card-mailbox .mailbox-container .mailbox-controls .email-pager-top .email-pager-count {
            float: right;
            margin-right: 10px;
            margin-top: 10px;
        }

        .card .card-mailbox .mailbox-container .mailbox-controls .email-pager-top .email-pager-container {
            float: right;
            margin-left: 6px;
        }

        .card .card-mailbox .mailbox-container .mailbox-controls .email-select-all {
            float: left;
            margin: 14px 35px 5px 9px;
        }

        .card .card-mailbox .mailbox-container .mailbox-controls .email-select-all label {
            padding-left: 8px;
        }

        .card .card-mailbox .mailbox-container .mailbox-controls .email-select-all label input {
            display: none;
        }

        .card .card-mailbox .mailbox-container .mailbox-controls .email-select-all label .checkbox-actual {
            float: left;
        }

        .card .card-mailbox .mailbox-container .mailbox-controls .email-select-all label .custom-control-description {
            padding-left: 11px;
            margin-top: 3px;
        }

        .card .card-mailbox .mailbox-container .email-pager-bottom .email-pager-count {
            margin-top: 10px;
            float: left;
        }

        .card .card-mailbox .mailbox-container .email-pager-bottom .email-pager-container {
            float: right;
        }

        .card .card-mailbox .mailbox-container tr {
            cursor: pointer;
            font-weight: 400;
        }

        .card .card-mailbox .mailbox-container tr .email-checkbox {
            max-width: 29px;
        }

        .card .card-mailbox .mailbox-container tr .email-checkbox .custom-control {
            margin-top: -2px;
        }

        .card .card-mailbox .mailbox-container tr .email-checkbox .custom-control input {
            display: none;
        }

        .card .card-mailbox .mailbox-container tr .email-star .email-star-status {
            display: block;
            margin-top: 3px;
        }

        .card .card-mailbox .mailbox-container tr .email-star .email-star-status .email-important {
            color: #F5C400;
            display: none;
        }

        .card .card-mailbox .mailbox-container tr .email-star .email-star-status .email-normal {
            display: block;
        }

        .card .card-mailbox .mailbox-container tr .email-star .email-star-status.checked .email-important {
            display: block;
        }

        .card .card-mailbox .mailbox-container tr .email-star .email-star-status.checked .email-normal {
            display: none;
        }

        .card .card-mailbox .mailbox-container tr .email-sender {
            max-width: 150px;
        }

        .card .card-mailbox .mailbox-container tr .email-subject .email-extra-icons {
            float: right;
        }

        .card .card-mailbox .mailbox-container tr .email-subject .email-extra-icons span {
            float: right;
            margin-left: 3px;
        }

        .card .card-mailbox .mailbox-container tr .email-datetime {
            text-align: right;
            max-width: 110px;
        }

        .card .card-mailbox .mailbox-container tr.highlighted {
            background-color: #FFFFCC;
        }

        .card .card-mailbox .mailbox-container tr.email-status-unread {
            color: #384044;
            font-weight: 500;
            letter-spacing: 0.03em;
        }

        .card .card-mailbox .mailbox-container tr.email-status-unread td {
            font-weight: 500;
        }

        .card .card-mailbox .mailbox-container tr.empty-list {
            text-align: center;
            font-size: 1.5em;
            font-weight: 400;
        }

        .card .card-mailbox .mailbox-container tr + .empty-list {
            display: none;
        }

        .card .card-mailbox .mailbox-message-view tr {
            cursor: auto;
        }

        .card .card-mailbox .mailbox-message-view .message-subject {
            border-bottom: 1px solid #dddddd;
            margin-bottom: 13px;
            padding: 0 10px 10px;
            overflow: hidden;
            clear: both;
        }

        .card .card-mailbox .mailbox-message-view .message-subject .badge {
            float: right;
            margin: 7px 0 0 10px;
        }

        .card .card-mailbox .mailbox-message-view .message-subject .email-extra-icons {
            float: right;
            margin-left: 10px;
            margin-top: 9px;
        }

        .card .card-mailbox .mailbox-message-view .message-subject .email-extra-icons span {
            float: right;
            margin-left: 3px;
        }

        .card .card-mailbox .mailbox-message-view .message-general-info-container {
            border-bottom: 1px solid #dddddd;
            min-height: 68px;
            padding: 0 10px 15px;
        }

        .card .card-mailbox .mailbox-message-view .message-general-info-container .message-controls {
            float: right;
        }

        .card .card-mailbox .mailbox-message-view .message-general-info-container .message-general-info .message-sender-image {
            float: left;
            margin-top: 2px;
            text-align: center;
            width: 62px;
        }

        .card .card-mailbox .mailbox-message-view .message-general-info-container .message-general-info .message-sender {
            margin: 0 0 0 62px;
            padding-top: 3px;
        }

        .card .card-mailbox .mailbox-message-view .message-general-info-container .message-general-info .message-sender .sender-name {
            font-weight: bold;
            letter-spacing: 0.03em;
        }

        .card .card-mailbox .mailbox-message-view .message-general-info-container .message-general-info .message-sender .sender-email {
            color: #aaaaaa;
        }

        .card .card-mailbox .mailbox-message-view .message-general-info-container .message-general-info .message-recepient {
            margin: 5px 0 0 62px;
        }

        .card .card-mailbox .mailbox-message-view .message-general-info-container .message-general-info .message-recepient .recepient-name {
            font-weight: bold;
            letter-spacing: 0.03em;
        }

        .card .card-mailbox .mailbox-message-view .message-general-info-container .message-general-info .message-recepient .send-date {
            color: #aaaaaa;
        }

        .card .card-mailbox .mailbox-message-view .message-general-info-container .message-general-info .message-recepient-others {
            display: none;
            margin: 5px 0 0 62px;
        }

        .card .card-mailbox .mailbox-message-view .message-general-info-container .message-general-info .message-recepient-others ul {
            padding: 0;
            list-style: none;
        }

        .card .card-mailbox .mailbox-message-view .message-general-info-container .message-general-info .message-recepient-others ul li {
            margin-bottom: 5px;
            font-weight: 400;
        }

        .card .card-mailbox .mailbox-message-view .message-body-container {
            padding: 10px;
        }

        .card .card-mailbox .mailbox-message-view .message-body-container .message-body {
            padding-bottom: 20px;
            margin-bottom: 10px;
            border-bottom: 1px solid #dddddd;
        }

        .card .card-mailbox .mailbox-message-view .message-body-container .message-attachment-gallery {
            margin-bottom: 20px;
        }

        .card .card-mailbox .mailbox-message-view .message-body-container .message-attachment-gallery .gallery-preview .gallery-item {
            display: inline-block;
            margin-bottom: 15px;
            margin-right: 10px;
            max-width: 300px;
            min-width: 150px;
            max-height: 175px;
            width: 30%;
        }

        .card .card-mailbox .mailbox-message-view .message-body-container .message-attachment-gallery .gallery-preview .gallery-item .gallery-item-image {
            border: 1px solid #dddddd;
            margin-bottom: 5px;
        }

        .card .card-mailbox .mailbox-message-view .message-body-container .message-attachment-gallery .gallery-preview .gallery-item .gallery-item-image img {
            padding: 7px;
            width: 100% !important;
            height: auto !important;
        }

        .card .card-mailbox .mailbox-message-view .message-body-container .message-attachment-gallery .gallery-preview .gallery-item .gallery-item-image:hover {
            border: 1px solid #bbbbbb;
        }

        .card .card-mailbox .mailbox-message-view .message-body-container .message-attachment-gallery .gallery-preview .gallery-item .gallery-item-controls a {
            padding: 5px 10px;
        }

        .card .card-mailbox .mailbox-message-view .message-body-container .message-attachment-list .attachment-action {
            text-align: right;
        }

        .card .card-mailbox .mailbox-message-view .message-body-container .message-attachment-list .attachment-action a {
            padding: 5px 10px;
        }

        .card .card-mailbox .mailbox-message-compose .email-recepient-main-container #add-bcc,
        .card .card-mailbox .mailbox-message-compose .email-recepient-main-container #add-cc {
            display: none;
        }

        .card .card-mailbox .mailbox-message-compose .email-recepient-bcc-container,
        .card .card-mailbox .mailbox-message-compose .email-recepient-cc-container {
            display: block;
        }

        .card .card-mailbox .mailbox-message-compose .message-attachment-list .attachment-action {
            text-align: right;
        }

        .card .card-mailbox .mailbox-message-compose .message-attachment-list .attachment-action a {
            padding: 5px 10px;
        }

        .card .card-task-list {
            height: 100%;
            padding: 1rem 0 2.083rem;
        }

        .card .card-task-list .task-manager .task-list {
            height: 470px;
        }

        .card .card-task-list .task-list {
            overflow: hidden;
            padding: 0;
        }

        .card .card-task-list .task-list .task-list-item {
            padding: 0;
            position: relative;
        }

        .card .card-task-list .task-list .task-list-item .custom-control {
            margin: 0;
            padding: 0;
        }

        .card .card-task-list .task-list .task-list-item .custom-control .custom-control-wrap {
            -webkit-transition: opacity 0.225s ease-in-out;
            -moz-transition: opacity 0.225s ease-in-out;
            -o-transition: opacity 0.225s ease-in-out;
            transition: opacity 0.225s ease-in-out;
        }

        .card .card-task-list .task-list .task-list-item .custom-control label.custom-control-label {
            background-color: #FFFFFF;
            display: block;
            padding: 10px 2.083rem 10px 4.6rem;
            margin: 0;
            -webkit-transition: opacity 0.225s ease-in-out;
            -moz-transition: opacity 0.225s ease-in-out;
            -o-transition: opacity 0.225s ease-in-out;
            transition: opacity 0.225s ease-in-out;
        }

        .card .card-task-list .task-list .task-list-item .custom-control label.custom-control-label .badge {
            margin-right: 5px;
        }

        .card .card-task-list .task-list .task-list-item .custom-control label.custom-control-label::before {
            top: 12px;
            left: 25px;
        }

        .card .card-task-list .task-list .task-list-item .custom-control label.custom-control-label::after {
            top: 13px;
            left: 27px;
        }

        .card .card-task-list .task-list .task-list-item .custom-control label.custom-control-label:hover,
        .card .card-task-list .task-list .task-list-item .custom-control label.custom-control-label:focus {
            background-color: #F7F7FA;
        }

        .card .card-task-list .task-list .task-list-item .custom-control.active .custom-control-wrap {
            opacity: 0.5;
            color: #7e7e7e;
            text-decoration: line-through;
        }

        .card .card-task-list .task-list .task-list-item .custom-control.active.anti-active .custom-control-wrap {
            opacity: 1 !important;
            color: #72848c !important;
            text-decoration: none !important;
        }

        .card .card-task-list .task-list .task-list-item .task-item-details {
            padding: 15px 10px 15px 4.583rem;
            display: none;
        }

        .card .card-task-list .task-list .task-list-item .task-item-details:empty {
            display: none;
        }

        .card .card-task-list .task-list .task-list-item .task-item-details:empty + .task-item-controls .show-task {
            display: none !important;
        }

        .card .card-task-list .task-list .task-list-item .task-item-controls {
            position: absolute;
            right: 2.083rem;
            top: 0;
            opacity: 0;
            -webkit-transition: opacity 0.225s ease-in-out;
            -moz-transition: opacity 0.225s ease-in-out;
            -o-transition: opacity 0.225s ease-in-out;
            transition: opacity 0.225s ease-in-out;
        }

        .card .card-task-list .task-list .task-list-item .task-item-users {
            position: absolute;
            right: calc(55px + 2.083rem);
            top: 3px;
            -webkit-transition: opacity 0.225s ease-in-out;
            -moz-transition: opacity 0.225s ease-in-out;
            -o-transition: opacity 0.225s ease-in-out;
            transition: opacity 0.225s ease-in-out;
        }

        .card .card-task-list .task-list .task-list-item .task-item-users .assigned-user {
            display: inline-block;
            opacity: 0.7;
            -webkit-transition: opacity 0.225s ease-in-out;
            -moz-transition: opacity 0.225s ease-in-out;
            -o-transition: opacity 0.225s ease-in-out;
            transition: opacity 0.225s ease-in-out;
        }

        .card .card-task-list .task-list .task-list-item .task-item-users .assigned-user .profile-picture {
            width: 34px;
            height: 34px;
        }

        .card .card-task-list .task-list .task-list-item .task-item-users .assigned-user .profile-picture img.list-thumbnail {
            width: 30px;
            height: 30px;
        }

        .card .card-task-list .task-list .task-list-item .task-item-users .assigned-user .profile-picture.has-message::after {
            top: -8px;
            left: -11px;
        }

        .card .card-task-list .task-list .task-list-item .task-item-users:empty {
            display: none;
        }

        .card .card-task-list .task-list .task-list-item:nth-child(even) .custom-control {
            margin: 0;
        }

        .card .card-task-list .task-list .task-list-item:nth-child(even) .custom-control label.custom-control-label {
            background-color: #F7F7FA;
        }

        .card .card-task-list .task-list .task-list-item:nth-child(even) .custom-control label.custom-control-label:hover,
        .card .card-task-list .task-list .task-list-item:nth-child(even) .custom-control label.custom-control-label:focus {
            background-color: #eeeef4;
        }

        .card .card-task-list .task-list .task-list-item:hover .task-item-controls,
        .card .card-task-list .task-list .task-list-item:focus .task-item-controls {
            opacity: 1;
        }

        .card .card-task-list .task-list .task-list-item:hover .task-item-users .assigned-user,
        .card .card-task-list .task-list .task-list-item:focus .task-item-users .assigned-user {
            opacity: 1;
        }

        .card .card-task-list .task-list .task-list-item.checked {
            background-color: #eeeef4;
        }

        .card .card-task-list .task-manager-list-container {
            border-left: 1px solid #dddddd;
            border-right: 1px solid #dddddd;
            border-bottom: 1px solid #dddddd;
            padding: 20px 15px;
            border-top: 2px solid #1f91f3;
        }

        .card .card-user-profile {
            background-color: #F7F7FA;
            padding: 0;
        }

        .card .card-user-profile .profile-page-left {
            position: relative;
            padding: 2.083rem;
        }

        .card .card-user-profile .profile-page-center {
            padding: 2.083rem;
            background-color: #FFFFFF;
        }

        .card .card-user-profile .profile-page-center .media-feed-control {
            margin-top: 1rem;
            padding: 10px 10px 4px;
            background-color: #F7F7FA;
        }

        .card .card-user-profile .profile-page-center .media-feed-control a {
            opacity: 0.5;
            color: #7e7e7e;
            -webkit-transition: opacity 0.225s ease-in-out;
            -moz-transition: opacity 0.225s ease-in-out;
            -o-transition: opacity 0.225s ease-in-out;
            transition: opacity 0.225s ease-in-out;
        }

        .card .card-user-profile .profile-page-center .media-feed-control a:not(:last-child) {
            margin-right: 15px;
        }

        .card .card-user-profile .profile-page-center .media-feed-control a:focus,
        .card .card-user-profile .profile-page-center .media-feed-control a:hover {
            opacity: 1;
        }

        .card .card-user-profile .profile-page-center > .comment-block {
            margin-bottom: 2.5rem;
        }

        .card .card-user-profile .profile-page-center > .comment-block textarea {
            min-height: 5rem;
            margin-bottom: 0;
            opacity: 0.5;
            -webkit-border-bottom-right-radius: 0;
            -moz-border-bottom-right-radius: 0;
            -ms-border-bottom-right-radius: 0;
            -o-border-bottom-right-radius: 0;
            border-bottom-right-radius: 0;
            -webkit-border-bottom-left-radius: 0;
            -moz-border-bottom-left-radius: 0;
            -ms-border-bottom-left-radius: 0;
            -o-border-bottom-left-radius: 0;
            border-bottom-left-radius: 0;
            -webkit-transition: opacity 0.225s ease-in-out;
            -moz-transition: opacity 0.225s ease-in-out;
            -o-transition: opacity 0.225s ease-in-out;
            transition: opacity 0.225s ease-in-out;
        }

        .card .card-user-profile .profile-page-center > .comment-block textarea:hover,
        .card .card-user-profile .profile-page-center > .comment-block textarea:focus {
            opacity: 1;
        }

        .card .card-user-profile .profile-page-center > .comment-block textarea + .media-feed-control {
            margin-top: 0;
            padding-top: 15px;
        }

        .card .card-user-profile .profile-page-center > .comment-block textarea + .media-feed-control .btn {
            opacity: 0.5 !important;
            margin-top: -6px;
        }

        .card .card-user-profile .profile-page-center > .comment-block textarea:focus + .media-feed-control .btn {
            opacity: 1 !important;
        }

        .card .card-user-profile .profile-page-center > ul > li.media {
            padding-bottom: 2.083rem;
            margin-bottom: 2.083rem;
            border-bottom: 1px solid rgba(0, 0, 0, 0.09);
        }

        .card .card-user-profile .profile-page-center > ul > li.media .profile-picture {
            display: none;
        }

        .card .card-user-profile .profile-page-center > ul > li.media .media-body {
            margin-left: 0 !important;
        }

        .card .card-user-profile .profile-page-center > ul > li.media .media-body .media-title {
            font-weight: 500;
        }

        .card .card-user-profile .profile-page-center > ul > li.media .media-body .media-title small {
            margin-left: 5px;
            text-transform: none;
            font-weight: 400;
            font-size: 90%;
        }

        .card .card-user-profile .profile-page-center > ul > li.media .media-body .media-body-reply-block ul .comment-reply-block .form-group textarea {
            opacity: 0.5;
            min-height: 3rem;
            -webkit-transition: all 0.225s ease-in-out !important;
            -moz-transition: all 0.225s ease-in-out !important;
            -o-transition: all 0.225s ease-in-out !important;
            transition: all 0.225s ease-in-out !important;
        }

        .card .card-user-profile .profile-page-center > ul > li.media .media-body .media-body-reply-block ul .comment-reply-block .form-group textarea:hover {
            opacity: 1;
        }

        .card .card-user-profile .profile-page-center > ul > li.media .media-body .media-body-reply-block ul .comment-reply-block .form-group textarea:focus {
            opacity: 1;
            height: 10rem;
        }

        .card .card-user-profile .profile-page-center > ul > li.media .media-body .media-body-reply-block ul .comment-reply-block .form-group .comment-reply {
            margin-top: -50px;
            opacity: 0;
            -webkit-transition: all 0.225s ease-in-out !important;
            -moz-transition: all 0.225s ease-in-out !important;
            -o-transition: all 0.225s ease-in-out !important;
            transition: all 0.225s ease-in-out !important;
        }

        .card .card-user-profile .profile-page-center > ul > li.media .media-body .media-body-reply-block ul .comment-reply-block .form-group textarea:focus + .comment-reply {
            margin-top: 0;
            opacity: 1;
        }

        .card .card-user-profile .profile-page-center > ul > li.media:last-child {
            border-bottom: 0;
        }

        .card .card-user-profile .profile-page-block-outer .profile-page-block {
            float: left;
            margin-bottom: 10px;
            margin-right: 5px;
        }

        .card .card-form-wizard .nav {
            display: table;
            width: 100%;
        }

        .card .card-form-wizard .nav > li {
            display: table-cell;
            float: none;
            vertical-align: top;
        }

        .card .card-form-wizard .nav > li > a {
            display: none;
            padding: 10px 4px;
            opacity: 0.5;
        }

        .card .card-form-wizard .nav > li > a > i.batch-icon,
        .card .card-form-wizard .nav > li > a > span.wi,
        .card .card-form-wizard .nav > li > a > span.glyphicon {
            float: left;
            color: #cccccc;
            margin-top: 5px;
        }

        .card .card-form-wizard .nav > li > a > span.main-text {
            display: block;
            margin-left: 42px;
        }

        .card .card-form-wizard .nav > li > a > span.main-text > .h2 {
            display: block;
        }

        .card .card-form-wizard .nav > li > a > span.main-text > small {
            display: block;
            color: #DDDDDD;
        }

        .card .card-form-wizard .nav > li > a.active {
            opacity: 1;
        }

        .card .card-form-wizard .nav > li > a.active > i.batch-icon,
        .card .card-form-wizard .nav > li > a.active > span.wi,
        .card .card-form-wizard .nav > li > a.active > span.glyphicon {
            color: #555555;
        }

        .card .card-form-wizard .nav > li > a.active > span.main-text > .h2 {
            display: block;
        }

        .card .card-form-wizard .nav > li > a.active > span.main-text > small {
            color: #07a7e3;
        }

        .card .card-form-wizard .nav > li > a.show {
            display: block;
        }

        .card .card-form-wizard .nav-pills > li > a,
        .card .card-form-wizard .nav-pills > li > a:hover,
        .card .card-form-wizard .nav-pills > li > a:focus,
        .card .card-form-wizard .nav-pills > li.active > a,
        .card .card-form-wizard .nav-pills > li.active > a:hover,
        .card .card-form-wizard .nav-pills > li.active > a:focus {
            background: none transparent;
        }

        .card .card-form-wizard .tab-content {
            padding: 2.083rem;
        }

        .card .card-footer {
            padding-left: 2.083rem;
            padding-right: 2.083rem;
            padding-bottom: 2.083rem;
        }

        .card:hover,
        .card:focus {
            box-shadow: 0 9px 23px rgba(0, 0, 0, 0.18), 0 5px 5px rgba(0, 0, 0, 0.12) !important;
        }

        .card.lightbox {
            -webkit-transition: all 0.225s ease-in-out !important;
            -moz-transition: all 0.225s ease-in-out !important;
            -o-transition: all 0.225s ease-in-out !important;
            transition: all 0.225s ease-in-out !important;
        }

        .card.lightbox:hover {
            transform: scale(1.05);
        }

        .card.card-xs {
            height: 95px;
            overflow: hidden;
        }

        .card.card-sm {
            height: 187px;
            overflow: hidden;
        }

        .card.card-md {
            height: 396px;
            overflow: hidden;
        }

        .card.card-md .card-task-list {
            max-height: 300px;
        }

        .card.card-md .card-media-list {
            max-height: 330px;
        }

        .card.card-lg {
            height: 536px;
            overflow: hidden;
        }

        .card.card-lg .card-task-list {
            max-height: 440px;
        }

        .card.card-lg .card-media-list {
            max-height: 470px;
        }

        .card .batch-icon-xxl {
            opacity: 0.75;
            -webkit-transition: opacity 0.225s ease-in-out;
            -moz-transition: opacity 0.225s ease-in-out;
            -o-transition: opacity 0.225s ease-in-out;
            transition: opacity 0.225s ease-in-out;
        }

        .card:hover .batch-icon-xxl,
        .card:focus .batch-icon-xxl {
            opacity: 1;
        }

        /* Forms */
        label {
            font-family: 'Montserrat', sans-serif !important;
            font-size: 12px;
            font-weight: 400;
        }

        .custom-file-input,
        .form-control {
            background-color: #FFFFFF !important;
            padding: .6rem .75rem;
            margin-top: 0;
            border: 1px solid #d2d2d2;
        }

        .custom-file {
            height: calc(3.25rem + 2px);
        }

        .form-control-file,
        .custom-file-input {
            height: calc(3.25rem + 2px);
        }

        .custom-file-label {
            padding: 1.375rem .75rem;
            line-height: 0.8;
            height: calc(3.25rem + 2px);
            border-color: #d2d2d2;
            box-shadow: 0 1px 0 0 #d2d2d2;
            -webkit-border-radius: 5px;
            -moz-border-radius: 5px;
            -ms-border-radius: 5px;
            -o-border-radius: 5px;
            border-radius: 5px;
        }

        .custom-file-label::after {
            line-height: 2.5;
            height: calc(calc(3.25rem + 2px) - 1px * 2);
        }

        .form-control-sm {
            height: 1.4rem !important;
        }

        .form-control-lg {
            height: 3rem !important;
        }

        select.form-control,
        select.custom-select {
            border-color: #d2d2d2;
            box-shadow: 0 1px 0 0 #d2d2d2;
        }

        select.form-control:focus,
        select.custom-select:focus {
            border-color: #07a7e3;
            box-shadow: 0 1px 0 0 #07a7e3;
        }

        select.form-control:not([size]):not([multiple]),
        select.custom-select:not([size]):not([multiple]) {
            height: calc(3.199rem + 2px);
        }

        .input-group-lg > .input-group-prepend > select.btn:not([size]):not([multiple]), .input-group-lg > .input-group-append > select.btn:not([size]):not([multiple]), .input-group-lg > select.form-control:not([size]):not([multiple]), .input-group-lg > select.input-group-text:not([size]):not([multiple]), select.form-control-lg:not([size]):not([multiple]) {
            height: calc(4.199rem + 2px) !important;
        }

        .input-group-md > .input-group-prepend > select.btn:not([size]):not([multiple]), .input-group-md > .input-group-append > select.btn:not([size]):not([multiple]), .input-group-md > select.form-control:not([size]):not([multiple]), .input-group-md > select.input-group-text:not([size]):not([multiple]), select.form-control-sm:not([size]):not([multiple]) {
            height: calc(2.199rem + 2px) !important;
        }

        textarea.form-control {
            border-color: #d2d2d2;
            box-shadow: 0 1px 0 0 #d2d2d2;
            min-height: 10rem;
            -webkit-border-radius: 5px;
            -moz-border-radius: 5px;
            -ms-border-radius: 5px;
            -o-border-radius: 5px;
            border-radius: 5px;
            -webkit-transition: all 0.225s ease-in-out !important;
            -moz-transition: all 0.225s ease-in-out !important;
            -o-transition: all 0.225s ease-in-out !important;
            transition: all 0.225s ease-in-out !important;
        }

        textarea.form-control:focus {
            min-height: 10rem;
            -webkit-border-radius: 5px;
            -moz-border-radius: 5px;
            -ms-border-radius: 5px;
            -o-border-radius: 5px;
            border-radius: 5px;
            -webkit-transition: all 0.225s ease-in-out !important;
            -moz-transition: all 0.225s ease-in-out !important;
            -o-transition: all 0.225s ease-in-out !important;
            transition: all 0.225s ease-in-out !important;
        }

        .form-group {
            margin-bottom: 5px;
        }

        .form-group .form-control {
            -webkit-border-radius: 5px;
            -moz-border-radius: 5px;
            -ms-border-radius: 5px;
            -o-border-radius: 5px;
            border-radius: 5px;
        }

        .form-group input.form-control {
            width: calc(100% - 1.2rem - 2px);
        }

        .form-group small {
            font-weight: 300;
        }

        .form-group.row,
        .form-row {
            display: flex;
        }

        .form-group.row .btn,
        .form-row .btn {
            margin: 0 2.083rem 0 0;
        }

        .form-inline .form-group input.form-control {
            width: auto;
            margin-bottom: 0;
        }

        .form-inline .btn {
            margin: 0 2.083rem 0 0;
        }

        .form-check input:disabled + .form-check-label {
            opacity: 0.7;
            font-style: italic;
            font-weight: 300 !important;
            cursor: not-allowed;
        }

        .form-check .form-check-label {
            margin-left: 3px;
            margin-right: 10px;
        }

        .custom-select.is-valid,
        .form-control.is-valid,
        .was-validated .custom-select:valid,
        .was-validated .form-control:valid {
            border-color: #0ad251 !important;
        }

        .form-control.border-success,
        .custom-select.is-valid:focus,
        .form-control.is-valid:focus,
        .was-validated .custom-select:valid:focus,
        .was-validated .form-control:valid:focus {
            border-color: #0ad251 !important;
            box-shadow: 0 1px 0 0 #0ad251;
        }

        .custom-select.is-invalid,
        .form-control.is-invalid,
        .was-validated .custom-select:invalid,
        .was-validated .form-control:invalid {
            border-color: #f43a59 !important;
        }

        .form-control.border-danger,
        .custom-select.is-invalid:focus,
        .form-control.is-invalid:focus,
        .was-validated .custom-select:invalid:focus,
        .was-validated .form-control:invalid:focus {
            border-color: #f43a59 !important;
            box-shadow: 0 1px 0 0 #f43a59;
        }

        .form-control.border-priamry {
            border-color: #07a7e3 !important;
            box-shadow: 0 1px 0 0 #07a7e3;
        }

        .form-control.border-secondary {
            border-color: #4f5b60 !important;
            box-shadow: 0 1px 0 0 #4f5b60;
        }

        .form-control.border-warning {
            border-color: #fce418 !important;
            box-shadow: 0 1px 0 0 #fce418;
        }

        .form-control.border-info {
            border-color: #55d3f5 !important;
            box-shadow: 0 1px 0 0 #55d3f5;
        }

        .form-text {
            font-weight: 300;
        }

        .col-form-label {
            line-height: 3.3;
        }

        .col-form-label-lg {
            line-height: 3.3;
        }

        .input-group {
            -ms-flex-wrap: nowrap;
            flex-wrap: nowrap;
        }

        .input-group .input-group-prepend .btn,
        .input-group .input-group-append .btn {
            margin: 0;
        }

        .input-group .input-group-prepend .btn + .btn,
        .input-group .input-group-append .btn + .btn {
            margin-left: 1px;
        }

        .input-group .input-group-prepend .btn-primary,
        .input-group .input-group-prepend .btn-outline-primary,
        .input-group .input-group-append .btn-primary,
        .input-group .input-group-append .btn-outline-primary {
            box-shadow: 0 1px 0 0 #07a7e3 !important;
        }

        .input-group .input-group-prepend .btn-secondary,
        .input-group .input-group-prepend .btn-outline-secondary,
        .input-group .input-group-append .btn-secondary,
        .input-group .input-group-append .btn-outline-secondary {
            box-shadow: 0 1px 0 0 #4f5b60 !important;
        }

        .input-group .input-group-prepend .btn-success,
        .input-group .input-group-prepend .btn-outline-success,
        .input-group .input-group-append .btn-success,
        .input-group .input-group-append .btn-outline-success {
            box-shadow: 0 1px 0 0 #0ad251 !important;
        }

        .input-group .input-group-prepend .btn-info,
        .input-group .input-group-prepend .btn-outline-info,
        .input-group .input-group-append .btn-info,
        .input-group .input-group-append .btn-outline-info {
            box-shadow: 0 1px 0 0 #55d3f5 !important;
        }

        .input-group .input-group-prepend .btn-warning,
        .input-group .input-group-prepend .btn-outline-warning,
        .input-group .input-group-append .btn-warning,
        .input-group .input-group-append .btn-outline-warning {
            box-shadow: 0 1px 0 0 #fce418 !important;
        }

        .input-group .input-group-prepend .btn-danger,
        .input-group .input-group-prepend .btn-outline-danger,
        .input-group .input-group-append .btn-danger,
        .input-group .input-group-append .btn-outline-danger {
            box-shadow: 0 1px 0 0 #f43a59 !important;
        }

        .input-group .input-group-prepend .input-group-text,
        .input-group .input-group-append .input-group-text {
            border-color: #d2d2d2;
            background-color: #d2d2d2;
            box-shadow: 0 1px 0 0 #d2d2d2;
            -webkit-transition: all 0.225s ease-in-out !important;
            -moz-transition: all 0.225s ease-in-out !important;
            -o-transition: all 0.225s ease-in-out !important;
            transition: all 0.225s ease-in-out !important;
        }

        .input-group .input-group-prepend .input-group-text .batch-icon,
        .input-group .input-group-append .input-group-text .batch-icon {
            -webkit-transition: all 0.225s ease-in-out !important;
            -moz-transition: all 0.225s ease-in-out !important;
            -o-transition: all 0.225s ease-in-out !important;
            transition: all 0.225s ease-in-out !important;
        }

        .input-group .input-group-prepend .dropdown-toggle-split,
        .input-group .input-group-append .dropdown-toggle-split {
            padding-left: 1rem;
            padding-right: 1rem;
        }

        .input-group .input-group-prepend .input-group-text {
            -webkit-border-top-right-radius: 0;
            -moz-border-top-right-radius: 0;
            -ms-border-top-right-radius: 0;
            -o-border-top-right-radius: 0;
            border-top-right-radius: 0;
            -webkit-border-bottom-right-radius: 0;
            -moz-border-bottom-right-radius: 0;
            -ms-border-bottom-right-radius: 0;
            -o-border-bottom-right-radius: 0;
            border-bottom-right-radius: 0;
            -webkit-border-top-left-radius: 5px;
            -moz-border-top-left-radius: 5px;
            -ms-border-top-left-radius: 5px;
            -o-border-top-left-radius: 5px;
            border-top-left-radius: 5px;
            -webkit-border-bottom-left-radius: 5px;
            -moz-border-bottom-left-radius: 5px;
            -ms-border-bottom-left-radius: 5px;
            -o-border-bottom-left-radius: 5px;
            border-bottom-left-radius: 5px;
        }

        .input-group .input-group-prepend .input-group-text + .input-group-text {
            margin-left: 1px;
        }

        .input-group .input-group-append .input-group-text {
            -webkit-border-top-right-radius: 5px;
            -moz-border-top-right-radius: 5px;
            -ms-border-top-right-radius: 5px;
            -o-border-top-right-radius: 5px;
            border-top-right-radius: 5px;
            -webkit-border-bottom-right-radius: 5px;
            -moz-border-bottom-right-radius: 5px;
            -ms-border-bottom-right-radius: 5px;
            -o-border-bottom-right-radius: 5px;
            border-bottom-right-radius: 5px;
            -webkit-border-top-left-radius: 0;
            -moz-border-top-left-radius: 0;
            -ms-border-top-left-radius: 0;
            -o-border-top-left-radius: 0;
            border-top-left-radius: 0;
            -webkit-border-bottom-left-radius: 0;
            -moz-border-bottom-left-radius: 0;
            -ms-border-bottom-left-radius: 0;
            -o-border-bottom-left-radius: 0;
            border-bottom-left-radius: 0;
        }

        .input-group .input-group-append .input-group-text .batch-icon {
            color: #FFFFFF;
        }

        .input-group .input-group-append .input-group-text:not(:last-child) {
            margin-right: 2px;
        }

        .input-group.focus .input-group-text {
            color: #FFFFFF;
            background-color: #07a7e3;
            border-color: #07a7e3;
            box-shadow: 0 1px 0 0 #07a7e3;
        }

        .input-group.focus .input-group-text .batch-icon {
            color: #FFFFFF;
        }

        .input-group.short-input-field > input {
            width: 20px;
        }

        .input-group.short-input-field > .input-group-prepend .btn,
        .input-group.short-input-field > .input-group-append .btn {
            padding-left: 1.35rem !important;
            padding-right: 1.35rem !important;
        }

        .input-group.input-group-lg .form-control {
            height: 3.1rem;
        }

        .form-control:disabled,
        .form-control[readonly],
        .form-control[readonly]:focus {
            border: 1px solid #d2d2d2;
            box-shadow: 0 1px 0 0 #d2d2d2;
            background-color: #ececec !important;
        }

        .form-control:disabled {
            text-decoration: line-through;
        }

        input[type=date], input[type=datetime-local], input[type=email], input[type=number], input[type=password], input[type=search-md], input[type=search], input[type=tel], input[type=text], input[type=time], input[type=url], textarea.md-textarea {
            width: calc(100% - 1.5rem);
            border: 1px solid #d2d2d2;
            box-shadow: 0 1px 0 0 #d2d2d2;
            -webkit-border-radius: 5px;
            -moz-border-radius: 5px;
            -ms-border-radius: 5px;
            -o-border-radius: 5px;
            border-radius: 5px;
        }

        .form-control-plaintext {
            border: transparent !important;
            box-shadow: none !important;
            padding-top: 11px;
        }

        input[type=date]:focus:not([readonly]), input[type=datetime-local]:focus:not([readonly]), input[type=email]:focus:not([readonly]), input[type=number]:focus:not([readonly]), input[type=password]:focus:not([readonly]), input[type=search-md]:focus:not([readonly]), input[type=search]:focus:not([readonly]), input[type=tel]:focus:not([readonly]), input[type=text]:focus:not([readonly]), input[type=time]:focus:not([readonly]), input[type=url]:focus:not([readonly]), textarea.md-textarea:focus:not([readonly]), textarea:focus:not([readonly]) {
            border: 1px solid #d2d2d2;
            box-shadow: 0 1px 0 0 #d2d2d2;
        }

        input[type=date].valid, input[type=date]:focus.valid, input[type=datetime-local].valid, input[type=datetime-local]:focus.valid, input[type=email].valid, input[type=email]:focus.valid, input[type=number].valid, input[type=number]:focus.valid, input[type=password].valid, input[type=password]:focus.valid, input[type=search-md].valid, input[type=search-md]:focus.valid, input[type=search].valid, input[type=search]:focus.valid, input[type=tel].valid, input[type=tel]:focus.valid, input[type=text].valid, input[type=text]:focus.valid, input[type=time].valid, input[type=time]:focus.valid, input[type=url].valid, input[type=url]:focus.valid, textarea.md-textarea.valid, textarea.md-textarea:focus.valid {
            border: 1px solid #d2d2d2;
            box-shadow: 0 1px 0 0 #d2d2d2;
        }

        .custom-control {
            margin-right: 1rem;
        }

        .custom-control .custom-control-label {
            margin-left: 0.5rem;
            margin-top: 0.3rem;
            cursor: pointer;
        }

        .custom-control .custom-control-label::before,
        .custom-control .custom-control-indicator {
            width: 1.5rem;
            height: 1.5rem;
            -webkit-transition: opacity 0.225s ease-in-out !important;
            -moz-transition: opacity 0.225s ease-in-out !important;
            -o-transition: opacity 0.225s ease-in-out !important;
            transition: opacity 0.225s ease-in-out !important;
        }

        .custom-control .custom-control-label::after {
            width: 1.3rem;
            height: 1.3rem;
            opacity: 0;
            -webkit-transition: opacity 0.225s ease-in-out !important;
            -moz-transition: opacity 0.225s ease-in-out !important;
            -o-transition: opacity 0.225s ease-in-out !important;
            transition: opacity 0.225s ease-in-out !important;
        }

        .custom-control .custom-control-input:disabled ~ .custom-control-label {
            opacity: 0.5;
            text-decoration: line-through;
        }

        .custom-control .custom-control-input:checked ~ .custom-control-label::after {
            opacity: 1;
        }

        .custom-control .custom-control-indicator + .custom-control-description {
            margin-top: 0.3rem;
            display: inline-block;
            margin-left: 0.5rem;
            -webkit-transition: all 0.225s ease-in-out !important;
            -moz-transition: all 0.225s ease-in-out !important;
            -o-transition: all 0.225s ease-in-out !important;
            transition: all 0.225s ease-in-out !important;
        }

        .custom-control .custom-control-input:checked ~ .custom-control-indicator {
            background-color: #07a7e3;
        }

        .custom-checkbox .custom-control-input:checked ~ .custom-control-label::after {
            top: 5px;
            left: 1px;
        }

        .custom-radio .custom-control-input:checked ~ .custom-control-label::after {
            top: 5px;
            left: 1px;
        }

        .custom-control-input.is-valid:checked ~ .custom-control-label::after,
        .was-validated .custom-checkbox.custom-control-input:valid:checked ~ .custom-control-label::after {
            background-color: #0ad251;
        }

        .custom-checkbox .custom-control-input:checked ~ .custom-control-label::before {
            background-color: #07a7e3;
        }

        .custom-radio .custom-control-input:checked ~ .custom-control-indicator {
            background-position: center center;
        }

        .custom-radio .custom-control-input:checked ~ .custom-control-label::before {
            background-color: #07a7e3;
        }

        .custom-control.custom-color-control {
            min-width: 2.5rem;
            min-height: 2.5rem;
            padding-left: 2rem;
            cursor: pointer;
            display: inline-block;
        }

        .custom-control.custom-color-control .custom-control-label::before {
            width: 2.5rem;
            height: 2.5rem;
        }

        .custom-control.custom-color-control .custom-control-label::after {
            width: 1.5rem;
            height: 1.5rem;
        }

        .custom-radio.custom-color-control .custom-control-input:checked ~ .custom-control-label::after {
            top: 9px;
            left: 6px;
            background-image: url("data:image/svg+xml;charset=utf8,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 8 8'%3E%3Cpath fill='%23fff' d='M6.564.75l-3.59 3.612-1.538-1.55L0 4.26 2.974 7.25 8 2.193z'/%3E%3C/svg%3E");
        }

        .invalid-feedback {
            margin-left: 0.5rem;
        }

        /* Progress Bar */
        .progress {
            height: auto;
            margin-bottom: 1rem;
        }

        .progress .progress-bar {
            font-size: 0.7rem;
            height: 0.9rem;
            background-color: #07a7e3;
            -webkit-transition: width 0.3s ease-in-out;
            -moz-transition: width 0.3s ease-in-out;
            -o-transition: width 0.3s ease-in-out;
            transition: width 0.3s ease-in-out;
        }

        .progress .progress-bar.progress-bar-sm {
            height: 3px;
        }

        .progress .progress-bar.progress-bar-lg {
            height: 20px;
        }

        /* Pagination */
        .page-item {
            margin-left: 2px;
        }

        .page-link {
            color: #07a7e3;
            padding: .75rem 1.083rem;
        }

        .page-item.active .page-link {
            background-color: #07a7e3;
            box-shadow: none !important;
        }

        .pagination .page-link {
            font-size: 1rem;
        }

        .pagination-lg .page-item .page-link {
            padding: 1rem 2rem;
        }

        .pagination-lg .page-item.active .page-link {
            -webkit-border-radius: 5px;
            -moz-border-radius: 5px;
            -ms-border-radius: 5px;
            -o-border-radius: 5px;
            border-radius: 5px;
        }

        .pager.wizard {
            padding: 0;
            margin: 0;
            list-style: none;
        }

        .pager li.previous {
            float: left;
        }

        .pager li.next {
            float: right;
        }

        .pager li > a,
        .pager li > span {
            font-weight: 500;
            line-height: 1.25;
            text-transform: uppercase;
            box-shadow: none !important;
            font-size: 1rem;
            -webkit-border-radius: 0.4167rem;
            -moz-border-radius: 0.4167rem;
            -ms-border-radius: 0.4167rem;
            -o-border-radius: 0.4167rem;
            border-radius: 0.4167rem;
            font-weight: 500;
            padding: .95rem 2.13rem .85rem;
        }

        .pager li > a:hover,
        .pager li > span:hover,
        .pager li > a:focus,
        .pager li > span:focus {
            /*opacity: 0.8;*/
        }

        .pager li.next > a,
        .pager li.next > span,
        .pager li.last > a,
        .pager li.last > span {
            background: #1f91f3;
            color: #ffffff;
        }

        .pager li.next > a:hover,
        .pager li.next > a:focus,
        .pager li.next > span:hover,
        .pager li.next > span:focus,
        .pager li.last > a:hover,
        .pager li.last > a:focus,
        .pager li.last > span:hover,
        .pager li.last > span:focus {
            background: #005ba9;
        }

        .pager li.disabled > a,
        .pager li.disabled > span {
            background: none;
            box-shadow: none;
            color: #888888;
        }

        /* Navbar */
        .navbar {
            text-transform: uppercase;
            letter-spacing: 0.03rem;
            padding: 1.5rem 3rem !important;
            box-shadow: 0 2px 23px 0 rgba(0, 0, 0, 0.1), 0 2px 49px 0 rgba(0, 0, 0, 0.06);
            z-index: 9000;
            -webkit-border-radius: 0;
            -moz-border-radius: 0;
            -ms-border-radius: 0;
            -o-border-radius: 0;
            border-radius: 0;
        }

        .navbar > .navbar-collapse > form .input-group {
            width: 100%;
            -webkit-transition: width 0.225s ease-in-out;
            -moz-transition: width 0.225s ease-in-out;
            -o-transition: width 0.225s ease-in-out;
            transition: width 0.225s ease-in-out;
        }

        .navbar > .navbar-collapse > form .input-group .form-control {
            background-color: transparent !important;
            width: 100%;
            height: 2rem;
            margin-right: 0;
            opacity: 0.8;
            border-bottom-color: #FFFFFF;
            box-shadow: 0 1px 0 0 #FFFFFF;
            -webkit-transition: opacity 0.225s ease-in-out;
            -moz-transition: opacity 0.225s ease-in-out;
            -o-transition: opacity 0.225s ease-in-out;
            transition: opacity 0.225s ease-in-out;
        }

        .navbar > .navbar-collapse > form .input-group .form-control:focus {
            opacity: 1;
        }

        .navbar .nav-link {
            padding: 0.7rem 1.4rem;
            -webkit-transition: color 0.3s ease-in-out !important;
            -moz-transition: color 0.3s ease-in-out !important;
            -o-transition: color 0.3s ease-in-out !important;
            transition: color 0.3s ease-in-out !important;
        }

        .navbar .navbar-brand {
            margin-top: 6px;
            margin-bottom: 6px;
        }

        .navbar .breadcrumb a,
        .navbar .navbar-nav .nav-item a {
            margin-top: 6px;
            margin-bottom: 0px;
        }

        .navbar .navbar-nav {
            flex-direction: row;
        }

        .navbar .navbar-nav .nav-item a {
            display: block;
        }

        .navbar .navbar-nav:not(.navbar-notifications):not(.navbar-profile) {
            flex-direction: column;
        }

        .navbar .navbar-nav.navbar-language-translation {
            margin-top: 2px;
        }

        .navbar .navbar-nav.mobile-only-control .nav-item,
        .navbar .navbar-nav.navbar-notifications .nav-item {
            position: relative;
        }

        .navbar .navbar-nav.mobile-only-control .nav-item .nav-link .notification-number,
        .navbar .navbar-nav.navbar-notifications .nav-item .nav-link .notification-number {
            position: absolute;
            opacity: 1;
            top: -4px;
            right: 2px;
            background-color: #f43a59;
            color: #FFFFFF;
            display: block;
            padding: 2px 6px 0;
            line-height: 1.5rem;
            font-size: 0.9rem;
            min-width: 26px;
            text-align: center;
            border: 3px solid #FFFFFF;
            -webkit-border-radius: 50%;
            -moz-border-radius: 50%;
            -ms-border-radius: 50%;
            -o-border-radius: 50%;
            border-radius: 50%;
            -webkit-transition: opacity 0.225s ease-in-out;
            -moz-transition: opacity 0.225s ease-in-out;
            -o-transition: opacity 0.225s ease-in-out;
            transition: opacity 0.225s ease-in-out;
        }

        .navbar .navbar-nav.mobile-only-control .nav-item.dropdown .nav-link,
        .navbar .navbar-nav.navbar-notifications .nav-item.dropdown .nav-link {
            padding-right: 0.5rem;
            position: relative;
        }

        .navbar .navbar-nav.mobile-only-control .nav-item.dropdown .nav-link .notification-number,
        .navbar .navbar-nav.navbar-notifications .nav-item.dropdown .nav-link .notification-number {
            opacity: 1;
            top: -10px;
        }

        .navbar .navbar-nav.mobile-only-control .nav-item.dropdown .nav-link#navbar-notification-search-mobile + .dropdown-menu,
        .navbar .navbar-nav.mobile-only-control .nav-item.dropdown .nav-link#navbar-notification-search + .dropdown-menu,
        .navbar .navbar-nav.navbar-notifications .nav-item.dropdown .nav-link#navbar-notification-search-mobile + .dropdown-menu,
        .navbar .navbar-nav.navbar-notifications .nav-item.dropdown .nav-link#navbar-notification-search + .dropdown-menu {
            background-color: #122f3b;
            padding: 1.5rem 3rem !important;
        }

        .navbar .navbar-nav.mobile-only-control .nav-item.dropdown .nav-link#navbar-notification-search-mobile + .dropdown-menu .input-group,
        .navbar .navbar-nav.mobile-only-control .nav-item.dropdown .nav-link#navbar-notification-search + .dropdown-menu .input-group,
        .navbar .navbar-nav.navbar-notifications .nav-item.dropdown .nav-link#navbar-notification-search-mobile + .dropdown-menu .input-group,
        .navbar .navbar-nav.navbar-notifications .nav-item.dropdown .nav-link#navbar-notification-search + .dropdown-menu .input-group {
            width: 100%;
            -webkit-transition: width 0.225s ease-in-out;
            -moz-transition: width 0.225s ease-in-out;
            -o-transition: width 0.225s ease-in-out;
            transition: width 0.225s ease-in-out;
        }

        .navbar .navbar-nav.mobile-only-control .nav-item.dropdown .nav-link#navbar-notification-search-mobile + .dropdown-menu .input-group .form-control,
        .navbar .navbar-nav.mobile-only-control .nav-item.dropdown .nav-link#navbar-notification-search + .dropdown-menu .input-group .form-control,
        .navbar .navbar-nav.navbar-notifications .nav-item.dropdown .nav-link#navbar-notification-search-mobile + .dropdown-menu .input-group .form-control,
        .navbar .navbar-nav.navbar-notifications .nav-item.dropdown .nav-link#navbar-notification-search + .dropdown-menu .input-group .form-control {
            background-color: #122f3b !important;
            height: 2rem;
            margin-right: 1px;
            box-shadow: 0 1px 0 0 #97a9b2;
        }

        .navbar .navbar-nav.mobile-only-control .nav-item.dropdown .nav-link#navbar-notification-search-mobile + .dropdown-menu .input-group .form-control:focus,
        .navbar .navbar-nav.mobile-only-control .nav-item.dropdown .nav-link#navbar-notification-search + .dropdown-menu .input-group .form-control:focus,
        .navbar .navbar-nav.navbar-notifications .nav-item.dropdown .nav-link#navbar-notification-search-mobile + .dropdown-menu .input-group .form-control:focus,
        .navbar .navbar-nav.navbar-notifications .nav-item.dropdown .nav-link#navbar-notification-search + .dropdown-menu .input-group .form-control:focus {
            color: #FFFFFF !important;
            border-bottom-color: #FFFFFF !important;
            box-shadow: 0 1px 0 0 #FFFFFF !important;
        }

        .navbar .navbar-nav.mobile-only-control .nav-item.dropdown .dropdown-menu,
        .navbar .navbar-nav.navbar-notifications .nav-item.dropdown .dropdown-menu {
            text-transform: none;
        }

        .navbar .navbar-nav.mobile-only-control .nav-item.dropdown .dropdown-menu .dropdown-item:not(:last-child),
        .navbar .navbar-nav.navbar-notifications .nav-item.dropdown .dropdown-menu .dropdown-item:not(:last-child) {
            display: block !important;
        }

        .navbar .navbar-nav.mobile-only-control .nav-item.dropdown .dropdown-menu > .media,
        .navbar .navbar-nav.navbar-notifications .nav-item.dropdown .dropdown-menu > .media {
            padding: 0 !important;
        }

        .navbar .navbar-nav.mobile-only-control .nav-item.dropdown .dropdown-menu > .media > a,
        .navbar .navbar-nav.navbar-notifications .nav-item.dropdown .dropdown-menu > .media > a {
            display: flex;
            padding: 10px 3rem 10px 1.5rem !important;
            width: 100%;
            padding-top: 10px;
            padding-bottom: 10px;
        }

        .navbar .navbar-nav.mobile-only-control .nav-item.dropdown .dropdown-menu > .media > a i.batch-icon,
        .navbar .navbar-nav.navbar-notifications .nav-item.dropdown .dropdown-menu > .media > a i.batch-icon {
            color: #07a7e3;
        }

        .navbar .navbar-nav.mobile-only-control .nav-item.dropdown .dropdown-menu > .media > a .media-body .notification-heading,
        .navbar .navbar-nav.navbar-notifications .nav-item.dropdown .dropdown-menu > .media > a .media-body .notification-heading {
            text-transform: none;
        }

        .navbar .navbar-nav.mobile-only-control .nav-item.dropdown .dropdown-menu > .media > a .media-body .notification-time,
        .navbar .navbar-nav.navbar-notifications .nav-item.dropdown .dropdown-menu > .media > a .media-body .notification-time {
            color: #07a7e3;
            display: block;
            font-size: 0.9rem;
        }

        .navbar .navbar-nav.mobile-only-control .nav-item.dropdown .dropdown-menu > .media > a:hover,
        .navbar .navbar-nav.navbar-notifications .nav-item.dropdown .dropdown-menu > .media > a:hover {
            background-color: #F7F7FA;
        }

        .navbar .navbar-nav.mobile-only-control .nav-item.dropdown .dropdown-menu > .media:nth-child(even) > a,
        .navbar .navbar-nav.navbar-notifications .nav-item.dropdown .dropdown-menu > .media:nth-child(even) > a {
            background-color: #F7F7FA;
        }

        .navbar .navbar-nav.mobile-only-control .nav-item.dropdown .dropdown-menu > .media:nth-child(even) > a:hover,
        .navbar .navbar-nav.mobile-only-control .nav-item.dropdown .dropdown-menu > .media:nth-child(even) > a:focus,
        .navbar .navbar-nav.navbar-notifications .nav-item.dropdown .dropdown-menu > .media:nth-child(even) > a:hover,
        .navbar .navbar-nav.navbar-notifications .nav-item.dropdown .dropdown-menu > .media:nth-child(even) > a:focus {
            background-color: #eeeef4;
        }

        .navbar .navbar-nav.mobile-only-control .nav-item.dropdown .dropdown-menu.dropdown-menu-right,
        .navbar .navbar-nav.navbar-notifications .nav-item.dropdown .dropdown-menu.dropdown-menu-right {
            left: auto !important;
            right: 0 !important;
        }

        .navbar .navbar-nav.mobile-only-control .nav-item.dropdown.show .nav-link .notification-number,
        .navbar .navbar-nav.navbar-notifications .nav-item.dropdown.show .nav-link .notification-number {
            opacity: 0;
        }

        .navbar .navbar-nav.mobile-only-control .nav-item .nav-link {
            margin-top: 6px;
            position: relative;
        }

        .navbar .navbar-nav.mobile-only-control .nav-item .nav-link .notification-number {
            top: -8px !important;
            right: -12px !important;
        }

        .navbar .navbar-nav.navbar-profile {
            margin-left: 1rem !important;
        }

        .navbar .navbar-nav.navbar-profile .nav-item .nav-link.dropdown-toggle {
            padding: 0 1rem 0 0;
            margin: 0;
        }

        .navbar .navbar-nav.navbar-profile .nav-item .nav-link.dropdown-toggle .profile-name {
            display: none;
            font-weight: 400;
            float: left !important;
            margin-top: 1.3rem !important;
        }

        .navbar .navbar-nav.navbar-profile .nav-item .nav-link.dropdown-toggle .profile-picture {
            margin-left: 1rem !important;
        }

        .navbar .navbar-nav.navbar-profile .nav-item .nav-link.dropdown-toggle::after {
            margin-top: 2rem;
        }

        .navbar .navbar-nav.navbar-profile .nav-item .dropdown-menu.dropdown-menu-right {
            left: auto !important;
            right: 0 !important;
        }

        .navbar form {
            margin-top: 0 !important;
            margin-bottom: 0 !important;
        }

        .navbar form .form-control {
            border-left: transparent !important;
            border-right: transparent !important;
            border-top: transparent !important;
            padding: 8px 10px;
            -webkit-border-radius: 0;
            -moz-border-radius: 0;
            -ms-border-radius: 0;
            -o-border-radius: 0;
            border-radius: 0;
        }

        .navbar form .form-control:focus {
            border-left: transparent !important;
            border-right: transparent !important;
            border-top: transparent !important;
        }

        .navbar-light {
            color: #97a9b2;
        }

        .navbar-dark {
            color: #FFFFFF;
        }

        .navbar .navbar-nav.navbar-notifications .nav-item.dropdown .dropdown-menu > .media > a .media-body .notification-heading,
        .navbar .navbar-nav.navbar-notifications .nav-item.dropdown .dropdown-menu > .media > a .media-body .notification-text {
            color: #72848c;
        }

        .navbar.navbar-light .navbar-nav .nav-item .nav-link,
        .navbar.navbar-light .navbar-nav .nav-item > a.nav-link > .batch-icon,
        .navbar.navbar-light .navbar-nav .nav-item a.nav-link {
            color: #97a9b2;
            font-weight: 400;
        }

        .navbar .navbar-nav .nav-item .batch-icon {
            position: relative;
            top: 1px;
        }

        .navbar.navbar-light .navbar-nav .nav-item .nav-link.disabled,
        .navbar.navbar-light .navbar-nav .nav-item .nav-link.disabled:hover {
            color: #c3cdd3;
        }

        .navbar.navbar-light .navbar-nav .nav-item:hover > a.nav-link,
        .navbar.navbar-light .navbar-nav .nav-item:focus > a.nav-link,
        .navbar.navbar-light .navbar-nav .nav-item:hover > a.nav-link > .batch-icon,
        .navbar.navbar-light .navbar-nav .nav-item:focus > a.nav-link > .batch-icon,
        .navbar.navbar-light .breadcrumb .nav-item.active > a.nav-link,
        .navbar.navbar-light .navbar-nav .nav-item.active > a.nav-link {
            color: #4f5b60;
        }

        .navbar.navbar-light .breadcrumb .nav-item.active > .nav-link:hover,
        .navbar.navbar-light .navbar-nav .nav-item.active > .nav-link:hover,
        .navbar.navbar-light form .form-control {
            color: #4f5b60 !important;
        }

        .navbar .hamburger {
            margin-top: 0.8rem;
            padding-bottom: 0.5rem;
            cursor: pointer;
            flex-basis: 66px;
        }

        .navbar.navbar-light .hamburger .hamburger-inner,
        .navbar.navbar-light .hamburger .hamburger-inner::before,
        .navbar.navbar-light .hamburger .hamburger-inner::after {
            background-color: #97a9b2 !important;
        }

        .navbar.navbar-dark .hamburger .hamburger-inner,
        .navbar.navbar-dark .hamburger .hamburger-inner::before,
        .navbar.navbar-dark .hamburger .hamburger-inner::after {
            background-color: #FFFFFF !important;
        }

        .navbar.navbar-light .hamburger:hover .hamburger-inner,
        .navbar.navbar-light .hamburger:hover .hamburger-inner::before,
        .navbar.navbar-light .hamburger:hover .hamburger-inner::after,
        .navbar.navbar-light .hamburger:focus .hamburger-inner,
        .navbar.navbar-light .hamburger:focus .hamburger-inner::before,
        .navbar.navbar-light .hamburger:focus .hamburger-inner::after {
            background-color: #4f5b60 !important;
        }

        .navbar.navbar-dark .hamburger:hover .hamburger-inner,
        .navbar.navbar-dark .hamburger:hover .hamburger-inner::before,
        .navbar.navbar-dark .hamburger:hover .hamburger-inner::after,
        .navbar.navbar-dark .hamburger:focus .hamburger-inner,
        .navbar.navbar-dark .hamburger:focus .hamburger-inner::before,
        .navbar.navbar-dark .hamburger:focus .hamburger-inner::after {
            opacity: 0.8;
        }

        .navbar .breadcrumb .nav-item .nav-link:focus,
        .navbar .breadcrumb .nav-item .nav-link:hover,
        .navbar .navbar-nav .nav-item .nav-link:focus,
        .navbar .navbar-nav .nav-item .nav-link:hover {
            color: #4f5b60;
        }

        .navbar.navbar-light form .form-control {
            color: #97a9b2 !important;
            border-bottom: 1px solid #97a9b2 !important;
            box-shadow: 0 1px 0 0 #97a9b2 !important;
        }

        .navbar.navbar-light form .form-control:focus {
            color: #4f5b60 !important;
            border-bottom: 1px solid #4f5b60 !important;
            box-shadow: 0 1px 0 0 #4f5b60;
        }

        .navbar.navbar-dark form .form-control {
            color: #FFFFFF !important;
            border-bottom: 1px solid #FFFFFF !important;
            box-shadow: 0 1px 0 0 #FFFFFF;
        }

        .navbar.navbar-dark form .form-control:focus {
            color: #FFFFFF !important;
            border-bottom: 1px solid #FFFFFF !important;
            box-shadow: 0 1px 0 0 #FFFFFF;
        }

        .navbar.navbar-light form .form-control::-webkit-input-placeholder {
            color: #97a9b2;
        }

        .navbar.navbar-light form .form-control:-moz-placeholder {
            color: #97a9b2;
        }

        .navbar.navbar-light form .form-control::-moz-placeholder {
            color: #97a9b2;
        }

        .navbar.navbar-light form .form-control::-ms-placeholder {
            color: #97a9b2;
        }

        .navbar.navbar-light form .form-control::placeholder {
            color: #97a9b2;
        }

        .navbar form .btn,
        .navbar-light form .btn,
        .navbar-dark form .btn {
            margin-top: 0 !important;
            margin-bottom: 0 !important;
        }

        .navbar form input {
            margin-left: 0;
        }

        .navbar.navbar-dark .navbar-nav .nav-item .nav-link,
        .navbar.navbar-dark .navbar-nav .nav-item > a.nav-link > .batch-icon,
        .navbar.navbar-dark .navbar-nav .nav-item a.nav-link {
            color: #FFFFFF;
            font-weight: 400;
        }

        /* Modal */
        .modal {
            z-index: 9002;
        }

        .modal-backdrop {
            z-index: 9000;
        }

        .modal-dialog .modal-content {
            box-shadow: 0 9px 23px rgba(0, 0, 0, 0.09), 0 5px 5px rgba(0, 0, 0, 0.06);
            -webkit-border-radius: 0.4167rem;
            -moz-border-radius: 0.4167rem;
            -ms-border-radius: 0.4167rem;
            -o-border-radius: 0.4167rem;
            border-radius: 0.4167rem;
        }

        /* Lists */
        .list-group .list-group-item.active {
            background-color: #07a7e3;
            border-color: #07a7e3;
        }

        .list-group .list-group-item.active * {
            color: #FFFFFF;
        }

        .list-group .list-group-item.disabled,
        .list-group .list-group-item:disabled {
            color: #d2d2d2;
        }

        .list-group .list-group-item-action {
            color: #72848c;
        }

        .list-group .list-group-item-action.active {
            color: #FFFFFF;
        }

        /* Main QuillPro Styles */
        /* Sidebar */
        .sidebar.bg-dark,
        .sidebar {
            color: #FFFFFF;
            background-color: #122f3b;
            width: 225px;
            position: fixed;
            z-index: 9001;
            left: -240px;
            box-shadow: 2px 0 10px 0 rgba(0, 0, 0, 0.12), 2px 0 15px 0 rgba(0, 0, 0, 0.09);
            -webkit-transition: left 0.225s ease-in-out, height 0.225s ease-in-out !important;
            -moz-transition: left 0.225s ease-in-out, height 0.225s ease-in-out !important;
            -o-transition: left 0.225s ease-in-out, height 0.225s ease-in-out !important;
            transition: left 0.225s ease-in-out, height 0.225s ease-in-out !important;
        }

        .sidebar.bg-dark .hamburger,
        .sidebar .hamburger {
            position: absolute;
            top: 22px;
            padding-top: 15px;
            color: #FFFFFF;
            background-color: #122f3b;
            box-shadow: 2px 0 10px 0 rgba(0, 0, 0, 0.12), 2px 0 15px 0 rgba(0, 0, 0, 0.09);
            -webkit-transition: right 0.225s ease-in-out, opacity 0.225s ease-in-out !important;
            -moz-transition: right 0.225s ease-in-out, opacity 0.225s ease-in-out !important;
            -o-transition: right 0.225s ease-in-out, opacity 0.225s ease-in-out !important;
            transition: right 0.225s ease-in-out, opacity 0.225s ease-in-out !important;
        }

        .sidebar.bg-dark .hamburger .hamburger-inner,
        .sidebar.bg-dark .hamburger .hamburger-inner::before,
        .sidebar.bg-dark .hamburger .hamburger-inner::after,
        .sidebar .hamburger .hamburger-inner,
        .sidebar .hamburger .hamburger-inner::before,
        .sidebar .hamburger .hamburger-inner::after {
            background-color: #FFFFFF !important;
        }

        .sidebar.bg-dark .hamburger .hamburger:hover .hamburger-inner,
        .sidebar.bg-dark .hamburger .hamburger:hover .hamburger-inner::before,
        .sidebar.bg-dark .hamburger .hamburger:hover .hamburger-inner::after,
        .sidebar.bg-dark .hamburger .hamburger:focus .hamburger-inner,
        .sidebar.bg-dark .hamburger .hamburger:focus .hamburger-inner::before,
        .sidebar.bg-dark .hamburger .hamburger:focus .hamburger-inner::after,
        .sidebar .hamburger .hamburger:hover .hamburger-inner,
        .sidebar .hamburger .hamburger:hover .hamburger-inner::before,
        .sidebar .hamburger .hamburger:hover .hamburger-inner::after,
        .sidebar .hamburger .hamburger:focus .hamburger-inner,
        .sidebar .hamburger .hamburger:focus .hamburger-inner::before,
        .sidebar .hamburger .hamburger:focus .hamburger-inner::after {
            background-color: #FFFFFF !important;
        }

        .sidebar.bg-dark .nav a,
        .sidebar .nav a {
            color: #FFFFFF;
        }

        .sidebar.bg-dark .nav a.navbar-brand,
        .sidebar .nav a.navbar-brand {
            margin: 1rem 0 0 0;
            padding: 1rem 2rem;
        }

        .sidebar.bg-dark .nav .nav-item .nav-link,
        .sidebar .nav .nav-item .nav-link {
            -webkit-border-radius: 0;
            -moz-border-radius: 0;
            -ms-border-radius: 0;
            -o-border-radius: 0;
            border-radius: 0;
            padding: 1rem 2rem;
        }

        .sidebar.bg-dark .nav .nav-item .nav-link i.batch-icon,
        .sidebar .nav .nav-item .nav-link i.batch-icon {
            color: #FFFFFF;
            margin-right: 0.5rem;
            position: relative;
            top: 1px;
            opacity: 0.7;
        }

        .sidebar.bg-dark .nav .nav-item .nav-link:hover i.batch-icon,
        .sidebar.bg-dark .nav .nav-item .nav-link:focus i.batch-icon,
        .sidebar.bg-dark .nav .nav-item .nav-link.active i.batch-icon,
        .sidebar .nav .nav-item .nav-link:hover i.batch-icon,
        .sidebar .nav .nav-item .nav-link:focus i.batch-icon,
        .sidebar .nav .nav-item .nav-link.active i.batch-icon {
            opacity: 1;
        }

        .sidebar.bg-dark .nav .nav-item .nav-link.nav-parent::after,
        .sidebar .nav .nav-item .nav-link.nav-parent::after {
            font-family: "Batch Icons";
            content: "\f14A";
            font-weight: 400;
            font-size: 1.3rem;
            margin-top: -0.22rem;
            float: right;
            opacity: 0.7;
            -webkit-transition: all 300ms;
            -moz-transition: all 300ms;
            -o-transition: all 300ms;
            transition: all 300ms;
        }

        .sidebar.bg-dark .nav .nav-item .nav-link.nav-parent:hover::after,
        .sidebar.bg-dark .nav .nav-item .nav-link.nav-parent:focus::after,
        .sidebar .nav .nav-item .nav-link.nav-parent:hover::after,
        .sidebar .nav .nav-item .nav-link.nav-parent:focus::after {
            opacity: 1;
        }

        .sidebar.bg-dark .nav .nav-item .nav-link.nav-parent + ul.nav,
        .sidebar .nav .nav-item .nav-link.nav-parent + ul.nav {
            display: none;
            border-left: 5px solid #07a7e3;
        }

        .sidebar.bg-dark .nav .nav-item .nav-link.nav-parent + ul.nav .nav-link,
        .sidebar .nav .nav-item .nav-link.nav-parent + ul.nav .nav-link {
            padding-left: 3.8rem;
        }

        .sidebar.bg-dark .nav .nav-item .nav-link.nav-parent + ul.nav ul.nav,
        .sidebar .nav .nav-item .nav-link.nav-parent + ul.nav ul.nav {
            background-color: #0c1f27;
        }

        .sidebar.bg-dark .nav .nav-item .nav-link.nav-parent + ul.nav ul.nav .nav-link,
        .sidebar .nav .nav-item .nav-link.nav-parent + ul.nav ul.nav .nav-link {
            padding-left: 4.8rem;
        }

        .sidebar.bg-dark .nav .nav-item .nav-link.nav-parent + ul.nav ul.nav ul.nav,
        .sidebar .nav .nav-item .nav-link.nav-parent + ul.nav ul.nav ul.nav {
            background-color: #08161c;
        }

        .sidebar.bg-dark .nav .nav-item.open > .nav-link.nav-parent::after,
        .sidebar .nav .nav-item.open > .nav-link.nav-parent::after {
            opacity: 1;
            -ms-transform: rotate(-90deg);
            /* IE 9 */
            -webkit-transform: rotate(-90deg);
            /* Safari */
            transform: rotate(-90deg);
        }

        .sidebar.bg-dark .nav .nav-header,
        .sidebar .nav .nav-header {
            color: #FFFFFF;
            text-transform: uppercase;
            padding: 0.5rem 2rem;
            margin: 2rem 0 0 0;
            font-weight: 700;
        }

        .sidebar.bg-dark .mCSB_container > ul.nav:last-child,
        .sidebar .mCSB_container > ul.nav:last-child {
            margin-bottom: 50px;
        }

        .sidebar-hidden.sidebar.bg-dark,
        .sidebar-hidden.sidebar {
            left: -240px;
        }

        .sidebar-hidden.sidebar.bg-dark.open,
        .sidebar-hidden.sidebar.open {
            left: 0;
        }

        .sidebar-hidden.sidebar.bg-dark + .right-column,
        .sidebar-hidden.sidebar + .right-column {
            margin-left: 0;
        }

        .sidebar-hidden.sidebar.bg-dark + .right-column .navbar .hamburger,
        .sidebar-hidden.sidebar + .right-column .navbar .hamburger {
            display: inline-block;
        }

        .sidebar-horizontal.bg-dark,
        .sidebar-horizontal {
            display: none;
        }

        .sidebar-horizontal.bg-dark .navbar-nav,
        .sidebar-horizontal .navbar-nav {
            flex-direction: column;
        }

        .sidebar-horizontal.bg-dark .navbar-nav .nav-item .nav-link.dropdown-toggle::after,
        .sidebar-horizontal .navbar-nav .nav-item .nav-link.dropdown-toggle::after {
            float: right;
            margin-top: 8px;
        }

        .sidebar-horizontal.bg-dark .navbar-nav .nav-item .dropdown-menu,
        .sidebar-horizontal .navbar-nav .nav-item .dropdown-menu {
            position: static !important;
            width: 100%;
            -webkit-transition: all 0.225s ease-in-out;
            -moz-transition: all 0.225s ease-in-out;
            -o-transition: all 0.225s ease-in-out;
            transition: all 0.225s ease-in-out;
        }

        .sidebar-horizontal.fixed-top {
            max-height: 250px;
        }

        .navbar-sidebar-horizontal.bg-dark,
        .navbar-sidebar-horizontal {
            width: 100%;
            color: #FFFFFF;
            z-index: 9001;
            background-color: #122f3b;
        }

        .navbar-sidebar-horizontal.bg-dark.fixed-top + .right-column,
        .navbar-sidebar-horizontal.fixed-top + .right-column {
            padding-top: 75.5px;
        }

        .navbar-sidebar-horizontal.bg-dark.fixed-top + .right-column > .sidebar-horizontal.fixed-top,
        .navbar-sidebar-horizontal.fixed-top + .right-column > .sidebar-horizontal.fixed-top {
            top: 87.5px;
        }

        .sidebar-horizontal .batch-icon {
            display: none;
        }

        .sidebar-horizontal.bg-gradient,
        .sidebar-horizontal.bg-danger.bg-gradient,
        .sidebar-horizontal.bg-warning.bg-gradient,
        .sidebar-horizontal.bg-info.bg-gradient,
        .sidebar-horizontal.bg-success.bg-gradient,
        .sidebar.bg-gradient,
        .sidebar.bg-danger.bg-gradient,
        .sidebar.bg-warning.bg-gradient,
        .sidebar.bg-info.bg-gradient,
        .sidebar.bg-success.bg-gradient {
            background-color: #122f3b;
            background-image: none;
            -webkit-transition: none;
            -moz-transition: none;
            -o-transition: none;
            transition: none;
        }

        .sidebar-horizontal.bg-gradient .nav .nav-item .nav-link:hover,
        .sidebar-horizontal.bg-gradient .nav .nav-item .nav-link.active,
        .sidebar-horizontal.bg-primary.bg-gradient .nav .nav-item .nav-link.active,
        .sidebar.bg-gradient .nav .nav-item .nav-link:hover,
        .sidebar.bg-gradient .nav .nav-item .nav-link.active,
        .sidebar.bg-primary.bg-gradient .nav .nav-item .nav-link.active {
            background: #07a7e3;
            /* Old browsers */
            background: -moz-linear-gradient(-45deg, #07a7e3 0%, #32dac3 100%);
            /* FF3.6-15 */
            background: -webkit-linear-gradient(-45deg, #07a7e3 0%, #32dac3 100%);
            /* Chrome10-25,Safari5.1-6 */
            background: linear-gradient(135deg, #07a7e3 0%, #32dac3 100%);
            /* W3C, IE10+, FF16+, Chrome26+, Opera12+, Safari7+ */
            filter: progid:DXImageTransform.Microsoft.gradient(startColorstr=$ qp-color-1, endColorstr=$ qp-color-2, GradientType=1);
            /* IE6-9 fallback on horizontal gradient */
            -webkit-transition: opacity 0.2s ease-out;
            -moz-transition: opacity 0.2s ease-out;
            -o-transition: opacity 0.2s ease-out;
            transition: opacity 0.2s ease-out;
            -webkit-transition: width 0.3s ease-in-out;
            -moz-transition: width 0.3s ease-in-out;
            -o-transition: width 0.3s ease-in-out;
            transition: width 0.3s ease-in-out;
        }

        .sidebar-horizontal.bg-success.bg-gradient .nav .nav-item .nav-link:hover,
        .sidebar-horizontal.bg-success.bg-gradient .nav .nav-item .nav-link.active,
        .sidebar.bg-success.bg-gradient .nav .nav-item .nav-link:hover,
        .sidebar.bg-success.bg-gradient .nav .nav-item .nav-link.active {
            background: #28C76F;
            /* Old browsers */
            background: -moz-linear-gradient(-45deg, #28C76F 0%, #81FBB8 100%);
            /* FF3.6-15 */
            background: -webkit-linear-gradient(-45deg, #28C76F 0%, #81FBB8 100%);
            /* Chrome10-25,Safari5.1-6 */
            background: linear-gradient(135deg, #28C76F 0%, #81FBB8 100%);
            /* W3C, IE10+, FF16+, Chrome26+, Opera12+, Safari7+ */
            filter: progid:DXImageTransform.Microsoft.gradient(startColorstr=$ qp-color-1, endColorstr=$ qp-color-2, GradientType=1);
            /* IE6-9 fallback on horizontal gradient */
            -webkit-transition: opacity 0.2s ease-out;
            -moz-transition: opacity 0.2s ease-out;
            -o-transition: opacity 0.2s ease-out;
            transition: opacity 0.2s ease-out;
            -webkit-transition: width 0.3s ease-in-out;
            -moz-transition: width 0.3s ease-in-out;
            -o-transition: width 0.3s ease-in-out;
            transition: width 0.3s ease-in-out;
        }

        .sidebar-horizontal.bg-success.bg-gradient .nav .nav-item .nav-link.nav-parent + ul.nav,
        .sidebar.bg-success.bg-gradient .nav .nav-item .nav-link.nav-parent + ul.nav {
            border-left-color: #28C76F;
        }

        .sidebar-horizontal.bg-info.bg-gradient .nav .nav-item .nav-link:hover,
        .sidebar-horizontal.bg-info.bg-gradient .nav .nav-item .nav-link.active,
        .sidebar.bg-info.bg-gradient .nav .nav-item .nav-link:hover,
        .sidebar.bg-info.bg-gradient .nav .nav-item .nav-link.active {
            background: #3677FF;
            /* Old browsers */
            background: -moz-linear-gradient(-45deg, #3677FF 0%, #FFD26F 100%);
            /* FF3.6-15 */
            background: -webkit-linear-gradient(-45deg, #3677FF 0%, #FFD26F 100%);
            /* Chrome10-25,Safari5.1-6 */
            background: linear-gradient(135deg, #3677FF 0%, #FFD26F 100%);
            /* W3C, IE10+, FF16+, Chrome26+, Opera12+, Safari7+ */
            filter: progid:DXImageTransform.Microsoft.gradient(startColorstr=$ qp-color-1, endColorstr=$ qp-color-2, GradientType=1);
            /* IE6-9 fallback on horizontal gradient */
            -webkit-transition: opacity 0.2s ease-out;
            -moz-transition: opacity 0.2s ease-out;
            -o-transition: opacity 0.2s ease-out;
            transition: opacity 0.2s ease-out;
            -webkit-transition: width 0.3s ease-in-out;
            -moz-transition: width 0.3s ease-in-out;
            -o-transition: width 0.3s ease-in-out;
            transition: width 0.3s ease-in-out;
        }

        .sidebar-horizontal.bg-info.bg-gradient .nav .nav-item .nav-link.nav-parent + ul.nav,
        .sidebar.bg-info.bg-gradient .nav .nav-item .nav-link.nav-parent + ul.nav {
            border-left-color: #3677FF;
        }

        .sidebar-horizontal.bg-warning.bg-gradient .nav .nav-item .nav-link:hover,
        .sidebar-horizontal.bg-warning.bg-gradient .nav .nav-item .nav-link.active,
        .sidebar.bg-warning.bg-gradient .nav .nav-item .nav-link:hover,
        .sidebar.bg-warning.bg-gradient .nav .nav-item .nav-link.active {
            background: #FC9131;
            /* Old browsers */
            background: -moz-linear-gradient(-45deg, #FC9131 0%, #FCCF31 100%);
            /* FF3.6-15 */
            background: -webkit-linear-gradient(-45deg, #FC9131 0%, #FCCF31 100%);
            /* Chrome10-25,Safari5.1-6 */
            background: linear-gradient(135deg, #FC9131 0%, #FCCF31 100%);
            /* W3C, IE10+, FF16+, Chrome26+, Opera12+, Safari7+ */
            filter: progid:DXImageTransform.Microsoft.gradient(startColorstr=$ qp-color-1, endColorstr=$ qp-color-2, GradientType=1);
            /* IE6-9 fallback on horizontal gradient */
            -webkit-transition: opacity 0.2s ease-out;
            -moz-transition: opacity 0.2s ease-out;
            -o-transition: opacity 0.2s ease-out;
            transition: opacity 0.2s ease-out;
            -webkit-transition: width 0.3s ease-in-out;
            -moz-transition: width 0.3s ease-in-out;
            -o-transition: width 0.3s ease-in-out;
            transition: width 0.3s ease-in-out;
        }

        .sidebar-horizontal.bg-warning.bg-gradient .nav .nav-item .nav-link.nav-parent + ul.nav,
        .sidebar.bg-warning.bg-gradient .nav .nav-item .nav-link.nav-parent + ul.nav {
            border-left-color: #FC9131;
        }

        .sidebar-horizontal.bg-danger.bg-gradient .nav .nav-item .nav-link:hover,
        .sidebar-horizontal.bg-danger.bg-gradient .nav .nav-item .nav-link.active,
        .sidebar.bg-danger.bg-gradient .nav .nav-item .nav-link:hover,
        .sidebar.bg-danger.bg-gradient .nav .nav-item .nav-link.active {
            background: #EA5455;
            /* Old browsers */
            background: -moz-linear-gradient(-45deg, #EA5455 0%, #FC9131 100%);
            /* FF3.6-15 */
            background: -webkit-linear-gradient(-45deg, #EA5455 0%, #FC9131 100%);
            /* Chrome10-25,Safari5.1-6 */
            background: linear-gradient(135deg, #EA5455 0%, #FC9131 100%);
            /* W3C, IE10+, FF16+, Chrome26+, Opera12+, Safari7+ */
            filter: progid:DXImageTransform.Microsoft.gradient(startColorstr=$ qp-color-1, endColorstr=$ qp-color-2, GradientType=1);
            /* IE6-9 fallback on horizontal gradient */
            -webkit-transition: opacity 0.2s ease-out;
            -moz-transition: opacity 0.2s ease-out;
            -o-transition: opacity 0.2s ease-out;
            transition: opacity 0.2s ease-out;
            -webkit-transition: width 0.3s ease-in-out;
            -moz-transition: width 0.3s ease-in-out;
            -o-transition: width 0.3s ease-in-out;
            transition: width 0.3s ease-in-out;
        }

        .sidebar-horizontal.bg-danger.bg-gradient .nav .nav-item .nav-link.nav-parent + ul.nav,
        .sidebar.bg-danger.bg-gradient .nav .nav-item .nav-link.nav-parent + ul.nav {
            border-left-color: #EA5455;
        }

        /* Right Column - General */
        .subtext {
            font-size: 0.9rem;
            font-weight: 300;
        }

        .strike-out {
            color: #999999;
            text-decoration: line-through;
        }

        .clickable {
            cursor: pointer;
            -webkit-transition: color 0.225s ease-in-out, background-color 0.225s ease-in-out !important;
            -moz-transition: color 0.225s ease-in-out, background-color 0.225s ease-in-out !important;
            -o-transition: color 0.225s ease-in-out, background-color 0.225s ease-in-out !important;
            transition: color 0.225s ease-in-out, background-color 0.225s ease-in-out !important;
        }

        .clickable:hover,
        .clickable:focus {
            background-color: #F7F7FA;
        }

        /* Right Column */
        .right-column {
            width: 100%;
            -webkit-transition: margin-left 0.225s ease-in-out !important;
            -moz-transition: margin-left 0.225s ease-in-out !important;
            -o-transition: margin-left 0.225s ease-in-out !important;
            transition: margin-left 0.225s ease-in-out !important;
        }

        .sidebar + .right-column {
            margin-left: 0;
        }

        /* Profile Pictures */
        .profile-picture {
            width: 48px;
            height: 48px;
            padding-top: 2px;
            -webkit-border-radius: 50%;
            -moz-border-radius: 50%;
            -ms-border-radius: 50%;
            -o-border-radius: 50%;
            border-radius: 50%;
            position: relative;
        }

        .profile-picture img {
            display: block;
            width: 44px;
            height: 44px;
            -webkit-border-radius: 50%;
            -moz-border-radius: 50%;
            -ms-border-radius: 50%;
            -o-border-radius: 50%;
            border-radius: 50%;
            border: 2px solid #FFFFFF;
            margin: 0 auto;
        }

        .profile-picture.has-message::after {
            font-family: "Batch Icons";
            font-size: 2.6rem;
            font-weight: 300;
            line-height: 1;
            display: inline-block;
            content: "\F140";
            color: #07a7e3;
            position: absolute;
            top: -5px;
            left: -10px;
        }

        .profile-picture.profile-picture-lg {
            width: 150px;
            height: 150px;
            margin: 0 auto;
        }

        .profile-picture.profile-picture-lg img {
            width: 144px;
            height: 144px;
            margin: 1px auto 0;
            border: 5px solid #FFFFFF;
        }

        .profile-picture.profile-picture-lg.has-message::after {
            top: -3px;
            left: -7px;
            font-size: 4.6rem;
        }

        /* Custom Scrollbar */
        .mCSB_inside > .mCSB_container {
            margin-right: 0;
        }

        .mCSB_scrollTools .mCSB_draggerContainer {
            left: -10px;
        }

        .mCS-dark.mCSB_scrollTools .mCSB_dragger .mCSB_dragger_bar {
            background-color: #7e7e7e;
        }

        .mCS-dark.mCSB_scrollTools .mCSB_dragger:active .mCSB_dragger_bar,
        .mCS-dark.mCSB_scrollTools .mCSB_dragger.mCSB_dragger_onDrag .mCSB_dragger_bar {
            background-color: #66767c;
        }

        .mCSB_scrollTools_vertical.mCSB_scrollTools_onDrag_expand .mCSB_dragger.mCSB_dragger_onDrag_expanded .mCSB_dragger_bar,
        .mCSB_scrollTools_vertical.mCSB_scrollTools_onDrag_expand .mCSB_draggerContainer:hover .mCSB_dragger .mCSB_dragger_bar {
            width: 8px;
        }

        .mCSB_dragger_bar,
        .mCSB_draggerRail {
            -webkit-transition: width 0.225s ease-in-out !important;
            -moz-transition: width 0.225s ease-in-out !important;
            -o-transition: width 0.225s ease-in-out !important;
            transition: width 0.225s ease-in-out !important;
        }

        .mCSB_scrollTools_vertical.mCSB_scrollTools_onDrag_expand .mCSB_dragger.mCSB_dragger_onDrag_expanded + .mCSB_draggerRail,
        .mCSB_scrollTools_vertical.mCSB_scrollTools_onDrag_expand .mCSB_draggerContainer:hover .mCSB_draggerRail {
            width: 4px;
        }

        /* Charts */
        .chart-epc {
            position: relative;
            text-align: center;
            height: 100px;
            width: 100px;
            margin: 0 auto;
        }

        .chart-epc canvas {
            position: absolute;
            top: 0;
            left: 0;
        }

        .chart-epc .percent {
            display: inline-block;
            font-size: 20px;
            font-weight: 400;
            margin-left: 6px;
            z-index: 2;
        }

        .chart-epc .percent:after {
            content: '%';
            font-size: 0.6em;
        }

        .chart-controls {
            text-align: center;
        }

        /* Map */
        .jqvmap-zoomin,
        .jqvmap-zoomout {
            width: 20px;
            height: 20px;
            padding: 5px 5px 5px 4px;
            background-color: #07a7e3;
            -webkit-border-radius: 0.4167rem;
            -moz-border-radius: 0.4167rem;
            -ms-border-radius: 0.4167rem;
            -o-border-radius: 0.4167rem;
            border-radius: 0.4167rem;
        }

        .jqvmap-zoomout {
            top: 35px;
        }

        .jqvmap-zoomin:hover,
        .jqvmap-zoomin:focus,
        .jqvmap-zoomout:hover,
        .jqvmap-zoomout:focus {
            background-color: #25bff8 !important;
        }

        .jqvmap-zoomin:active,
        .jqvmap-zoomout:active {
            background-color: #0583b2 !important;
        }

        /* Search Results */
        .search-results-list .search-link {
            color: #08a13e;
        }

        /* Price Lists */
        .card-price-list {
            display: flex;
            flex-direction: column;
        }

        .card-price-list * {
            text-align: center;
            text-transform: uppercase;
        }

        .card-price-list .pricing-plan {
            padding: 25px;
        }

        .card-price-list .pricing-plan:last-child {
            border-bottom: none;
        }

        .card-price-list .pricing-img {
            margin-bottom: 25px;
            max-width: 100%;
        }

        .card-price-list .pricing-header {
            color: #4f5b60;
            letter-spacing: 1px;
        }

        .card-price-list .pricing-features {
            letter-spacing: 1px;
            margin: 50px 0 25px;
            padding: 0;
            list-style: none;
        }

        .card-price-list .pricing-features-item {
            border-top: 1px solid #F7F7FA;
            line-height: 1.5;
            padding: 15px 0;
        }

        .card-price-list .pricing-features-item:last-child {
            border-bottom: 1px solid #e1f1ff;
        }

        .card-price-list .pricing-price {
            color: #07a7e3;
            display: block;
            font-size: 2.5rem;
            font-weight: 300;
        }

        .price-list-type-2 {
            text-align: center;
            width: 100%;
            max-width: 1000px;
            margin: 40px auto 0;
        }

        .price-list-type-2 * {
            -webkit-box-sizing: border-box;
            box-sizing: border-box;
        }

        .price-list-type-2 .plan {
            padding-left: 0;
            margin: 0 0 55px;
            width: 100%;
            position: relative;
            float: left;
            background-color: #FFFFFF;
            color: #4f5b60;
            box-shadow: 0 9px 23px rgba(0, 0, 0, 0.09), 0 5px 5px rgba(0, 0, 0, 0.06);
            -webkit-transition: box-shadow 0.7s cubic-bezier(0.25, 0.8, 0.25, 1);
            -moz-transition: box-shadow 0.7s cubic-bezier(0.25, 0.8, 0.25, 1);
            -o-transition: box-shadow 0.7s cubic-bezier(0.25, 0.8, 0.25, 1);
            transition: box-shadow 0.7s cubic-bezier(0.25, 0.8, 0.25, 1);
        }

        .price-list-type-2 .plan:hover,
        .price-list-type-2 .plan:focus {
            box-shadow: 0 9px 23px rgba(0, 0, 0, 0.18), 0 5px 5px rgba(0, 0, 0, 0.12);
        }

        .price-list-type-2 header {
            position: relative;
        }

        .price-list-type-2 .plan-title {
            position: relative;
            top: 0;
            padding: 5px 15px;
            margin: 0 auto;
            -webkit-transform: translateY(-50%);
            transform: translateY(-50%);
            margin: 0;
            display: inline-block;
            background-color: #66767c;
            color: #FFFFFF;
            text-transform: uppercase;
            box-shadow: 0 7px 23px 0 rgba(0, 0, 0, 0.1), 0 13px 49px 0 rgba(0, 0, 0, 0.06) !important;
        }

        .price-list-type-2 .plan-cost {
            padding: 0px 10px 20px;
        }

        .price-list-type-2 .plan-price {
            font-size: 2.5rem;
            color: #07a7e3;
        }

        .price-list-type-2 .plan-type {
            opacity: 0.6;
        }

        .price-list-type-2 .plan-features {
            padding: 0;
            margin: 0;
            text-align: center;
            list-style: outside none none;
        }

        .price-list-type-2 .plan-features li {
            padding: 10px 5%;
        }

        .price-list-type-2 .plan-features li:nth-child(even) {
            background: rgba(0, 0, 0, 0.08);
        }

        .price-list-type-2 .plan-features i {
            margin-right: 8px;
            opacity: 0.4;
        }

        .price-list-type-2 .plan-select {
            padding: 10px;
        }

        .price-list-type-2 .featured {
            margin-top: -10px;
            background-color: #07a7e3;
            color: #FFFFFF;
            z-index: 1;
        }

        .price-list-type-2 .featured .plan-title,
        .price-list-type-2 .featured .plan-price {
            color: #FFFFFF;
        }

        .price-list-type-2 .featured .plan-cost {
            padding: 10px 10px 20px;
        }

        .price-list-type-2 .featured .plan-select {
            padding: 10px;
        }

        /* Tags Input */
        .bootstrap-tagsinput {
            display: block;
            padding-top: 8px;
            box-shadow: 0 1px 0 0 #d2d2d2;
        }

        .bootstrap-tagsinput .tag.badge {
            font-size: 1rem;
            font-weight: 400;
            margin-bottom: 5px;
        }

        .bootstrap-tagsinput .twitter-typeahead {
            top: -3px;
            border: 0 !important;
            box-shadow: none !important;
        }

        .bootstrap-tagsinput .twitter-typeahead input {
            color: #72848c;
            border: 0 !important;
            box-shadow: none !important;
        }

        .bootstrap-tagsinput .twitter-typeahead .tt-menu {
            width: 20rem;
            font-size: 1rem;
            margin: 0;
            padding: .5rem 0;
            min-width: 10rem;
            background-color: #FFFFFF;
            box-shadow: 0 2px 5px 0 rgba(0, 0, 0, 0.16), 0 2px 10px 0 rgba(0, 0, 0, 0.12);
        }

        .bootstrap-tagsinput .twitter-typeahead .tt-menu .tt-dataset .tt-suggestion {
            color: #97a9b2 !important;
            cursor: pointer;
            text-transform: uppercase;
            padding: 10px 1.5rem !important;
        }

        .bootstrap-tagsinput input {
            color: #72848c;
            border: 0 !important;
            box-shadow: none !important;
        }

        /* Signin, Signup, Forgotten Password */
        .sisu.right-column .signin-left-column {
            padding-top: 10vw;
            padding-right: 3rem !important;
            padding-left: 3rem !important;
        }

        .sisu.right-column .signin-left-column .signin-logo {
            display: inline-block;
            margin-bottom: 30px;
        }

        .sisu.right-column .signin-right-column {
            background-position: center;
            background-size: cover;
            text-align: center;
            padding-top: 10vw;
        }

        .sisu.right-column .signin-right-column .signin-logo {
            display: inline-block;
            margin-bottom: 30px;
        }

        /* Datatables */
        .dataTables_filter label {
            width: 100%;
        }

        /* Notifications - Toastr */
        #toast-container > .toast {
            padding: 15px 15px 15px 55px;
            background-color: #07a7e3;
            background-image: none !important;
            box-shadow: 0 2px 5px 0 rgba(0, 0, 0, 0.16), 0 2px 10px 0 rgba(0, 0, 0, 0.12) !important;
        }

        #toast-container > .toast::before {
            font-family: "Batch Icons";
            font-weight: 300;
            position: absolute;
            font-size: 2.5rem;
            left: 15px;
            top: 20px;
        }

        #toast-container > .toast.toast-success {
            background-color: #0ad251;
        }

        #toast-container > .toast.toast-success::before {
            content: "\f164";
        }

        #toast-container > .toast.toast-info {
            background-color: #07a7e3;
        }

        #toast-container > .toast.toast-info::before {
            content: "\f12D";
        }

        #toast-container > .toast.toast-warning {
            color: #4f5b60;
            background-color: #fce418;
        }

        #toast-container > .toast.toast-warning::before {
            content: "\f15A";
        }

        #toast-container > .toast.toast-error {
            background-color: #f43a59;
        }

        #toast-container > .toast.toast-error::before {
            content: "\f093";
        }

        /* Carousel */
        .carousel {
            box-shadow: 0 9px 23px rgba(0, 0, 0, 0.09), 0 5px 5px rgba(0, 0, 0, 0.06);
            -webkit-transition: box-shadow 0.7s cubic-bezier(0.25, 0.8, 0.25, 1) !important;
            -moz-transition: box-shadow 0.7s cubic-bezier(0.25, 0.8, 0.25, 1) !important;
            -o-transition: box-shadow 0.7s cubic-bezier(0.25, 0.8, 0.25, 1) !important;
            transition: box-shadow 0.7s cubic-bezier(0.25, 0.8, 0.25, 1) !important;
        }

        .carousel .carousel-inner .carousel-item img {
            margin-left: auto;
            margin-right: auto;
        }

        .carousel .carousel-control-prev .batch-icon,
        .carousel .carousel-control-next .batch-icon {
            color: #07a7e3;
        }

        .carousel .carousel-control-prev .carousel-control-prev-icon,
        .carousel .carousel-control-prev .carousel-control-next-icon,
        .carousel .carousel-control-next .carousel-control-prev-icon,
        .carousel .carousel-control-next .carousel-control-next-icon {
            background-image: none;
        }

        .carousel:hover,
        .carousel:focus {
            box-shadow: 0 9px 23px rgba(0, 0, 0, 0.18), 0 5px 5px rgba(0, 0, 0, 0.12);
        }

        /* Ecommerce Pages */
        .category-page h1,
        .product-page h1 {
            line-height: 1.1;
        }

        .category-page .price-block,
        .product-page .price-block {
            font-size: 2.5rem;
        }

        .category-page .price-block .price-new,
        .product-page .price-block .price-new {
            float: left;
            font-weight: 500;
        }

        .category-page .price-block .price-old,
        .product-page .price-block .price-old {
            float: left;
            font-size: 60%;
            color: #f43a59;
            margin-top: 11px;
            text-decoration: line-through;
            margin-left: 10px;
        }

        .category-page .price-block .price-discount,
        .product-page .price-block .price-discount {
            padding-top: 0;
            font-size: 1rem;
            clear: both;
            color: #0ad251;
        }

        .category-page .ratings,
        .product-page .ratings {
            margin-bottom: 25px;
        }

        .category-page .ratings .batch-icon,
        .product-page .ratings .batch-icon {
            font-size: 2.6rem;
            color: #4f5b60;
            cursor: pointer;
            margin: 0 -4px;
            opacity: 0.2;
        }

        .category-page .ratings .batch-icon.rating-highlighted,
        .product-page .ratings .batch-icon.rating-highlighted {
            color: #fce418;
            opacity: 1;
        }

        .category-page .ratings .batch-icon:hover,
        .category-page .ratings .batch-icon:focus,
        .product-page .ratings .batch-icon:hover,
        .product-page .ratings .batch-icon:focus {
            color: #f4e353;
            opacity: 0.5;
        }

        .category-page .card .card-body .card-title {
            margin-bottom: 0;
        }

        .category-page .card .card-body .price-block {
            font-size: 1.5rem;
        }

        .category-page .card .card-body .price-block .price-new {
            float: none;
            display: inline-block;
            font-weight: 500;
        }

        .category-page .card .card-body .price-block .price-old {
            float: none;
            display: inline-block;
            margin-top: 0;
            margin-left: 5px;
        }

        .category-page .card .card-body .ratings {
            margin-bottom: 5px;
        }

        /* Tooltips/Popover */
        .popover {
            font-family: 'Montserrat', sans-serif;
            border-color: rgba(0, 0, 0, 0.1);
            box-shadow: 0 3px 11px rgba(0, 0, 0, 0.12), 0 3px 5px rgba(0, 0, 0, 0.12) !important;
            z-index: 9999;
        }

        .popover .popover-header {
            padding: 1rem 2rem 0.5rem;
        }

        .popover .popover-body {
            padding: 1rem 2rem;
        }

        .popover .popover-header:not(:empty) + .popover-body:not(:empty) {
            padding: 0.5rem 2rem 1rem;
        }

        .tooltip {
            box-shadow: 0 7px 23px 0 rgba(0, 0, 0, 0.1), 0 13px 49px 0 rgba(0, 0, 0, 0.06) !important;
            z-index: 9999;
        }

        /* Responsiveness */
        @media (max-width: 575px) {
            .sidebar.open {
                left: 0;
            }

            .sidebar.open .hamburger {
                opacity: 1;
                right: -66px;
            }

            .sidebar .hamburger {
                opacity: 0;
                right: 0;
            }

            .card .card-body .timeline .timeline-items .timeline-item {
                width: 100%;
                left: auto !important;
                margin-top: 100px !important;
                -webkit-border-top-right-radius: 0.4167rem;
                -moz-border-top-right-radius: 0.4167rem;
                -ms-border-top-right-radius: 0.4167rem;
                -o-border-top-right-radius: 0.4167rem;
                border-top-right-radius: 0.4167rem;
            }

            .card .card-body .timeline .timeline-items .timeline-item::before {
                display: none !important;
            }

            .card .card-body .timeline .timeline-items .timeline-item::after {
                display: block !important;
                content: '';
                background: #5b5555 !important;
                width: 30px !important;
                height: 30px !important;
                position: absolute !important;
                top: -50px !important;
                -webkit-border-radius: 100% !important;
                -moz-border-radius: 100% !important;
                -ms-border-radius: 100% !important;
                -o-border-radius: 100% !important;
                border-radius: 100% !important;
                left: calc(50% - 12px) !important;
            }

            .card .card .card-mailbox .mailbox-container tr .email-sender {
                display: none;
            }

            .sisu.right-column .signin-left-column .signin-logo {
                display: none;
            }

            #toast-container > div {
                width: 100%;
            }
        }

        @media (min-width: 576px) {
            .price-list-type-2 .plan {
                width: 100%;
            }

            .sidebar.open {
                left: 0;
            }

            .sidebar.open .hamburger {
                opacity: 1;
                right: -66px;
            }

            .sidebar .hamburger {
                opacity: 0;
                right: 0;
            }

            .fc-toolbar .fc-left {
                float: left !important;
            }

            .fc-toolbar .fc-right {
                float: right !important;
            }

            .sisu.right-column .signin-left-column {
                min-height: 630px;
            }

            .sisu.right-column .signin-right-column {
                padding-top: 5rem;
            }

            .card .card-deck .card {
                height: auto;
            }

            .card .card-user-profile {
                -webkit-border-bottom-left-radius: 0.4167rem;
                -moz-border-bottom-left-radius: 0.4167rem;
                -ms-border-bottom-left-radius: 0.4167rem;
                -o-border-bottom-left-radius: 0.4167rem;
                border-bottom-left-radius: 0.4167rem;
                -webkit-border-bottom-right-radius: 0.4167rem;
                -moz-border-bottom-right-radius: 0.4167rem;
                -ms-border-bottom-right-radius: 0.4167rem;
                -o-border-bottom-right-radius: 0.4167rem;
                border-bottom-right-radius: 0.4167rem;
            }

            .card .card-user-profile .profile-page-center > ul > li.media .profile-picture {
                display: block !important;
            }

            .card .card-user-profile .profile-page-center > ul > li.media .media-body {
                margin-left: 1.5rem !important;
            }

            .card-group .card {
                height: auto;
            }

            .card-columns .card {
                width: 95%;
                margin-bottom: 3rem;
            }
        }

        @media (min-width: 768px) {
            .navbar .navbar-nav.navbar-profile .nav-item .nav-link.dropdown-toggle .profile-name {
                display: block;
            }

            .sidebar-horizontal .batch-icon {
                display: inline-block;
            }

            .price-list-type-2 .plan {
                width: 49%;
            }

            .price-list-type-2 .plan:not(:last-child) {
                margin-right: 1%;
            }

            .card .card-mailbox .mailbox-container .mailbox-controls {
                float: none !important;
                text-align: left !important;
            }

            .card .card-user-profile .profile-page-left {
                float: left;
                width: 280px;
            }

            .card .card-user-profile .profile-page-center {
                float: left;
                min-height: 810px;
                width: calc(100% - 280px);
                border-right: 1px solid rgba(0, 0, 0, 0.09);
                border-left: 1px solid rgba(0, 0, 0, 0.09);
            }

            .card .card-user-profile .profile-page-center > ul > li.media .profile-picture {
                display: block !important;
            }

            .card .card-user-profile .profile-page-center > ul > li.media .media-body {
                margin-left: 1.5rem !important;
            }

            .sisu.right-column .signin-left-column {
                box-shadow: 9px 0 23px rgba(0, 0, 0, 0.09), 5px 0 5px rgba(0, 0, 0, 0.06);
            }

            .sisu.right-column .signin-right-column {
                min-height: 630px;
                text-align: left;
                padding-top: 20rem;
            }
        }

        @media (min-width: 992px) {
            .navbar-expand-lg .navbar-nav .nav-link {
                padding-right: 1.5rem;
                padding-left: 1.5rem;
            }

            .navbar .hamburger {
                display: none;
            }

            .navbar > .navbar-collapse {
                flex-basis: 100%;
            }

            .navbar .navbar-nav.navbar-profile .nav-item .nav-link.dropdown-toggle {
                padding: 0;
            }

            .navbar .navbar-nav:not(.navbar-notifications):not(.navbar-profile) {
                flex-direction: row;
            }

            .sidebar.bg-dark,
            .sidebar {
                left: 0;
            }

            .sidebar-horizontal.bg-dark,
            .sidebar-horizontal {
                display: block;
            }

            .sidebar-horizontal.bg-dark .navbar-nav,
            .sidebar-horizontal .navbar-nav {
                flex-direction: row;
            }

            .sidebar-horizontal.bg-dark .navbar-nav .nav-item .nav-link.dropdown-toggle::after,
            .sidebar-horizontal .navbar-nav .nav-item .nav-link.dropdown-toggle::after {
                float: none;
                margin-top: 0;
            }

            .sidebar-horizontal.bg-dark .navbar-nav .nav-item .dropdown-menu,
            .sidebar-horizontal .navbar-nav .nav-item .dropdown-menu {
                position: absolute !important;
                width: 20rem;
            }

            .sidebar-horizontal.bg-dark .navbar-nav .nav-item .dropdown-menu .dropdown-menu,
            .sidebar-horizontal .navbar-nav .nav-item .dropdown-menu .dropdown-menu {
                left: 0;
                top: 64%;
            }

            .sidebar + .right-column {
                margin-left: 225px;
            }

            .navbar-sidebar-horizontal.bg-dark.fixed-top + .right-column > .sidebar-horizontal.fixed-top + .main-content,
            .navbar-sidebar-horizontal.fixed-top + .right-column > .sidebar-horizontal.fixed-top + .main-content {
                padding-top: 127px !important;
            }

            .navbar-nav {
                float: left;
                flex-direction: row;
            }

            .navbar-nav .nav-item a {
                display: block;
            }

            .pricing-plan {
                border-bottom: none;
                border-right: 1px solid #e1f1ff;
                flex-basis: 100%;
                padding: 25px 50px;
            }

            .pricing-plan:last-child {
                border-right: none;
            }

            .card .card-price-list {
                flex-direction: row;
            }

            .card .card-mailbox .mailbox-menu {
                padding: 0 0 2.083rem 0;
            }

            .card .card-mailbox .mailbox-compose-outer {
                margin-bottom: 20px;
                padding-bottom: 20px;
            }

            .card .card-mailbox .mailbox-tags {
                border-top: 1px solid #DDDDDD;
            }

            .card .card-form-wizard .nav > li > a {
                display: block;
            }

            .sisu.right-column .signin-left-column {
                padding-right: 5rem !important;
                padding-left: 5rem !important;
            }

            .sisu.right-column .signin-right-column {
                padding-top: 20rem;
                padding-right: 5rem !important;
                padding-left: 5rem !important;
            }
        }

        @media (min-width: 1200px) {
            .price-list-type-2 .plan {
                width: 24%;
            }

            .price-list-type-2 .plan:not(:last-child) {
                margin-right: 1%;
            }

            .sisu.right-column .signin-left-column {
                padding-right: 10rem !important;
                padding-left: 10rem !important;
            }

            .sisu.right-column .signin-right-column {
                padding-top: 23rem;
                padding-right: 10rem !important;
                padding-left: 10rem !important;
            }
        }

        h3 {
            font-weight: 700 !important;
        }

        #sidebar .nav-item .fa {
            margin: 0 6px 0 0px;
            font-size: 16px;
            color: #cacaca;
        }

        #sidebar .nav-item:hover .fa {
            margin: 0 6px 0 0px;
            font-size: 16px;
            color: #fff;
        }

        @media only screen and (min-width: 992px) {
            #searchForm {
                min-width: 600px;
            }
        }

        .table .btn[class*=btn-outline-] {
            padding: 0.7rem !important;
            font-size: 1px;
        }

        .table.no-border tr td {
            border: none;
        }

        .row-header {
            background-color: #dadada;
        }

        .row-header:hover {
            background-color: #dadada !important;
        }

        .form-control:disabled {
            text-decoration: none;
        }

        .search-form {
            /*looks like bug in the styling, fix by applying this*/
            /*looks like bug in the styling, fix by applying this*/
        }

        .search-form .input-group {
            margin-right: 20px;
        }

        .search-form .btn-group {
            margin-top: 10px;
        }

        @media only screen and (min-width: 768px) {
            .search-form .btn-group {
                margin-top: 0;
            }
        }

        @media only screen and (min-width: 768px) {
            .search-form {
                margin-top: 5px;
                float: right;
                display: inline-flex;
            }
        }

        .search-form .form-control-sm, .search-form .input-group-md > .form-control, .search-form .input-group-md > .input-group-append > .btn, .search-form .input-group-md > .input-group-append > .input-group-text, .search-form .input-group-md > .input-group-prepend > .btn, .search-form .input-group-md > .input-group-prepend > .input-group-text {
            padding: .28rem .5rem;
            font-size: .875rem;
            line-height: 1.5;
            border-radius: .2rem;
        }

        .search-form .input-group-md > .input-group-prepend > select.btn:not([size]):not([multiple]), .search-form .input-group-md > .input-group-append > select.btn:not([size]):not([multiple]), .search-form .input-group-md > select.form-control:not([size]):not([multiple]), .search-form .input-group-md > select.input-group-text:not([size]):not([multiple]), .search-form select.form-control-sm:not([size]):not([multiple]) {
            height: calc(2.199rem + 8px) !important;
        }

        .dataTables_action .btn {
            margin-top: 0;
        }

        @media (max-width: 765px) {
            .dataTables_action .btn {
                margin-bottom: 10px;
            }
        }

        @media (min-width: 770px) and (max-width: 992px) {
            .dataTables_filter {
                margin-left: -40px;
            }
        }

        @media (min-width: 1030px) and (max-width: 1300px) {
            .dataTables_filter {
                margin-left: -40px;
            }
        }

        @media (max-width: 765px) {
            .dataTables_filter .btn-group {
                margin-top: 10px;
            }
        }

        .dataTables_filter .col-md-3 {
            margin-right: 0;
            padding-right: 0;
        }

        .dataTables_filter span#inputGroup-sizing-sm {
            width: 65px;
        }

        .card-header .btn {
            padding: .65rem 2.13rem .65rem !important;
        }

        .search-form {
            text-align: right;
        }

        .search-form .row .col-md-3:last-child {
            text-align: left;
        }

        #generic-item-list .form-row .form-input,
        #journal-entry-list .form-row .form-input,
        #generic-deduction-list .form-row .form-input,
        #generic-addition-list .form-row .form-input,
        #classschedule-item-list .form-row .form-input {
            width: 100%;
            display: flex;
            flex-wrap: wrap;
        }

        @media only screen and (min-width: 768px) {
            #generic-item-list .form-row .form-input,
            #journal-entry-list .form-row .form-input,
            #generic-deduction-list .form-row .form-input,
            #generic-addition-list .form-row .form-input,
            #classschedule-item-list .form-row .form-input {
                margin-right: 10px;
                width: calc(100% - 180px);
            }
        }

        #generic-item-list .form-row .remove-item,
        #journal-entry-list .form-row .remove-item,
        #generic-deduction-list .form-row .remove-item,
        #generic-addition-list .form-row .remove-item,
        #classschedule-item-list .form-row .remove-item {
            padding-top: 0;
            margin-left: auto;
            margin-right: auto;
        }

        @media only screen and (min-width: 768px) {
            #generic-item-list .form-row .remove-item,
            #journal-entry-list .form-row .remove-item,
            #generic-deduction-list .form-row .remove-item,
            #generic-addition-list .form-row .remove-item,
            #classschedule-item-list .form-row .remove-item {
                padding-top: 36px;
            }
        }

        .btn-outline-secondary {
            border-color: #d2d2d2 !important;
            color: #d2d2d2 !important;
        }

        .input-group .input-group-prepend .btn-secondary, .input-group .input-group-prepend .btn-outline-secondary, .input-group .input-group-append .btn-secondary, .input-group .input-group-append .btn-outline-secondary {
            box-shadow: 0 1px 0 0 #d2d2d2 !important;
        }

        .row-details .details-item {
            max-width: 250px;
        }

        .row-details .details-item .item-title {
            margin-bottom: 5px;
        }

        .group-details-action {
            text-align: right;
        }

        .validation-summary-errors ul {
            list-style: none;
            color: red;
            padding: 0;
        }

        .sisu.right-column .signin-left-column .signin-logo {
            margin-bottom: 10px;
        }

        .signin-right-column {
            background-image: url("/images/login-bg.jpg");
        }

        /*logo text*/
        .text-logo {
            font-size: 30px;
            font-weight: 500;
        }

        .aa {
            color: #20abdf;
        }

        .finance-buddy {
            color: #24c5d0;
        }

        .account-information .card-body {
            padding: 12px 20px;
            background-color: #f8f8f8;
            border-right: 1px solid #ccc;
            padding-bottom: 0 !important;
        }

        .account-information .card-body .tile-left {
            margin-top: 10px;
        }

        .account-information .card-body .tile-left .tile-number {
            font-size: 40px;
            font-size: 40px;
            line-height: 0.8;
        }

        .account-information .highlight {
            margin-top: 25px;
            height: 2px;
            border-radius: 2px;
        }

        .account-information .bg-color-blue {
            background-color: #5bc0de;
        }

        .account-information .tiles-row .batch-icon {
            color: #ccc;
        }

        .account-information .billing-details {
            margin-top: 20px;
            max-width: 400px;
            -webkit-box-flex: 0;
            flex: 0 0 50%;
        }

        .account-information .billing-info {
            margin-left: 15px;
            margin-top: 20px;
            max-width: 400px;
            -webkit-box-flex: 0;
            flex: 0 0 50%;
        }

        .account-information .package-info {
            margin-top: 20px;
            -webkit-box-flex: 0;
            flex: 0 0 50%;
        }

        .widget-row .card-tile .fa {
            font-size: 60px;
            color: #ffffff !important;
            opacity: 0.75;
        }

        .widget-row .card-tile:hover .fa {
            font-size: 60px;
            color: #ffffff !important;
            opacity: 1;
        }

        /* accordion styles */
        #accordion .card-header a {
            color: #72848c;
            font-weight: 500;
        }

        #accordion .card-header .fa-chevron {
            transform: rotate(90deg);
            transition: .3s;
        }

        #accordion .card-header .fa-chevron::before {
            content: "\f054";
        }

        #accordion .card-header .collapsed .fa-chevron {
            transform: none;
            transition: .3s;
        }

        #accordion .card-header .collapsed .fa-chevron::before {
            content: "\f054";
        }

        #vertical-timeline {
            position: relative;
            padding: 0;
            margin-top: 2em;
            margin-bottom: 2em;
        }

        #vertical-timeline::before {
            content: '';
            position: absolute;
            top: 0;
            left: 18px;
            height: 100%;
            width: 4px;
            background: #f1f1f1;
        }

        .vertical-timeline-content .btn {
            float: right;
        }

        #vertical-timeline.light-timeline:before {
            background: #e7eaec;
        }

        .dark-timeline .vertical-timeline-content:before {
            border-color: transparent #f5f5f5 transparent transparent;
        }

        .dark-timeline.center-orientation .vertical-timeline-content:before {
            border-color: transparent transparent transparent #f5f5f5;
        }

        .dark-timeline .vertical-timeline-block:nth-child(2n) .vertical-timeline-content:before,
        .dark-timeline.center-orientation .vertical-timeline-block:nth-child(2n) .vertical-timeline-content:before {
            border-color: transparent #f5f5f5 transparent transparent;
        }

        .dark-timeline .vertical-timeline-content,
        .dark-timeline.center-orientation .vertical-timeline-content {
            background: #f5f5f5;
        }

        @media only screen and (min-width: 1170px) {
            #vertical-timeline.center-orientation {
                margin-top: 3em;
                margin-bottom: 3em;
            }

            #vertical-timeline.center-orientation:before {
                left: 50%;
                margin-left: -2px;
            }
        }

        @media only screen and (max-width: 1170px) {
            .center-orientation.dark-timeline .vertical-timeline-content:before {
                border-color: transparent #f5f5f5 transparent transparent;
            }
        }

        .vertical-timeline-block {
            position: relative;
            margin: 2em 0;
        }

        .vertical-timeline-block:after {
            content: "";
            display: table;
            clear: both;
        }

        .vertical-timeline-block:first-child {
            margin-top: 0;
        }

        .vertical-timeline-block:last-child {
            margin-bottom: 0;
        }

        @media only screen and (min-width: 1170px) {
            .center-orientation .vertical-timeline-block {
                margin: 4em 0;
            }

            .center-orientation .vertical-timeline-block:first-child {
                margin-top: 0;
            }

            .center-orientation .vertical-timeline-block:last-child {
                margin-bottom: 0;
            }
        }

        .vertical-timeline-icon {
            position: absolute;
            top: 0;
            left: 0;
            width: 40px;
            height: 40px;
            border-radius: 50%;
            font-size: 16px;
            border: 3px solid #f1f1f1;
            text-align: center;
        }

        .vertical-timeline-icon i {
            display: block;
            width: 24px;
            height: 24px;
            position: relative;
            left: 50%;
            top: 50%;
            margin-left: -12px;
            margin-top: -9px;
        }

        @media only screen and (min-width: 1170px) {
            .center-orientation .vertical-timeline-icon {
                width: 50px;
                height: 50px;
                left: 50%;
                margin-left: -25px;
                -webkit-transform: translateZ(0);
                -webkit-backface-visibility: hidden;
                font-size: 19px;
            }

            .center-orientation .vertical-timeline-icon i {
                margin-left: -12px;
                margin-top: -10px;
            }

            .center-orientation .cssanimations .vertical-timeline-icon.is-hidden {
                visibility: hidden;
            }
        }

        .vertical-timeline-content {
            position: relative;
            margin-left: 60px;
            background: white;
            border-radius: 0.25em;
            padding: 1em;
        }

        .vertical-timeline-content:after {
            content: "";
            display: table;
            clear: both;
        }

        .vertical-timeline-content h2 {
            font-weight: 400;
            margin-top: 4px;
        }

        .vertical-timeline-content p {
            margin: 1em 0;
            line-height: 1.6;
        }

        .vertical-timeline-content .vertical-date {
            float: left;
            font-weight: 500;
        }

        .vertical-date small {
            color: #1ab394;
            font-weight: 400;
        }

        .vertical-timeline-content::before {
            content: '';
            position: absolute;
            top: 16px;
            right: 100%;
            height: 0;
            width: 0;
            border: 7px solid transparent;
            border-right: 7px solid white;
        }

        @media only screen and (min-width: 768px) {
            .vertical-timeline-content h2 {
                font-size: 18px;
            }

            .vertical-timeline-content p {
                font-size: 13px;
            }
        }

        @media only screen and (min-width: 1170px) {
            .center-orientation .vertical-timeline-content {
                margin-left: 0;
                padding: 1.6em;
                width: 45%;
            }

            .center-orientation .vertical-timeline-content::before {
                top: 24px;
                left: 100%;
                border-color: transparent;
                border-left-color: white;
            }

            .center-orientation .vertical-timeline-content .btn {
                float: left;
            }

            .center-orientation .vertical-timeline-content .vertical-date {
                position: absolute;
                width: 100%;
                left: 122%;
                top: 2px;
                font-size: 14px;
            }

            .center-orientation .vertical-timeline-block:nth-child(even) .vertical-timeline-content {
                float: right;
            }

            .center-orientation .vertical-timeline-block:nth-child(even) .vertical-timeline-content::before {
                top: 24px;
                left: auto;
                right: 100%;
                border-color: transparent;
                border-right-color: white;
            }

            .center-orientation .vertical-timeline-block:nth-child(even) .vertical-timeline-content .btn {
                float: right;
            }

            .center-orientation .vertical-timeline-block:nth-child(even) .vertical-timeline-content .vertical-date {
                left: auto;
                right: 122%;
                text-align: right;
            }

            .center-orientation .cssanimations .vertical-timeline-content.is-hidden {
                visibility: hidden;
            }
        }

        .pagination {
            margin: 0 auto;
            display: inline-flex;
        }

        .pagination li {
            padding: 7px;
        }

        .pagination li:hover {
            -webkit-transition: all .3s linear;
            transition: all .3s linear;
            background-color: #eee;
            border-radius: 2px;
        }

        .pagination li.active {
            border-radius: 2px;
            background-color: #07a7e3;
            box-shadow: none !important;
        }

        .pagination li.disabled {
            cursor: not-allowed;
        }

        .pagination li.disabled a {
            cursor: not-allowed;
        }

        .pagination li.active a {
            color: white;
        }

        .pagination li a {
            padding: 7px;
            background-color: transparent;
            font-size: 1rem;
            border: 0;
            -webkit-transition: all .3s linear;
            transition: all .3s linear;
        }

        .ui-autocomplete {
            position: absolute;
            z-index: 1000;
            cursor: default;
            padding: 0;
            margin-top: 2px;
            list-style: none;
            background-color: #ffffff;
            border: 1px solid #ccc;
            -webkit-border-radius: 5px;
            -moz-border-radius: 5px;
            border-radius: 5px;
            -webkit-box-shadow: 0 5px 10px rgba(0, 0, 0, 0.2);
            -moz-box-shadow: 0 5px 10px rgba(0, 0, 0, 0.2);
            box-shadow: 0 5px 10px rgba(0, 0, 0, 0.2);
            /*Support Scrollable*/
            max-height: 100px;
            overflow-y: auto;
            /* prevent horizontal scrollbar */
            overflow-x: hidden;
        }

        /* IE 6 doesn't support max-height   * we use height instead, but this forces the menu to always be this tall */
        * html .ui-autocomplete {
            height: 100px;
        }

        .ui-autocomplete > li {
            padding: 3px 20px;
        }

        .ui-autocomplete > li.ui-state-focus {
            background-color: #DDD;
        }

        .ui-helper-hidden-accessible {
            display: none;
        }

        .navbar-expand-lg .navbar-collapse {
            display: -webkit-box !important;
            display: -ms-flexbox !important;
            display: flex !important;
            -ms-flex-preferred-size: auto;
            flex-basis: auto;
        }

        /*.navbar .navbar-nav.navbar-profile .nav-item .dropdown-menu.dropdown-menu-right {
    li {
        form {
            cursor: pointer;
        }
    }
}*/
    </style>
    <br/><br/>
    <div class="nk-content">
        <div class="container-fluid">
            <div class="nk-content-inner">
                <div class="nk-content-body">
                    <div class="row g-gs">


                        <h2 style="font-size:42px">Dashboard</h2>
                        <div class="col-md-12">

                            <div class="card">
                                <div class="card-body">
                                    <h2 class="" style="margin-bottom: 2rem">Welcome, {{$userName->name}} !</h2>
                                    <p><i class="fa fa-calendar"></i> Today's date
                                        is {{date("d/m/Y")}}</p>
                                    <p class="">SifuTutor, your ultimate companion in mastering new skills and
                                        knowledge! SifuTutor seamlessly connects you with expert tutors in various
                                        subjects, offering personalized and interactive sessions tailored to your unique
                                        learning needs. .</p>
                                </div>
                            </div>
                        </div>

                        <div class="col-sm-6 col-xl-6 col-xxl-3">
                            <div
                                style="color: #FFFFFF !important; background: linear-gradient(135deg, #7e5ad5 0%, #1d1143 100%);"
                                class="card">
                                <div class="card-body">
                                    <div class="card-title-group align-items-start">
                                        <div class="card-title">
                                            <h4 style="color:#fff" class="title"><span
                                                    style="font-weight:bold; font-size:27px;">INCOME</span> <br/> This
                                                Month</h4>

                                        </div>
                                    </div>
                                    <div class="mt-2 mb-4">
                                        <div style="color:#fff" class="amount h1">
                                            RM {{number_format($incomeCollected,2)}}</div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-sm-6 col-xl-6 col-xxl-3">
                            <div style="    color: #FFFFFF !important;
    background: #07a7e3;
    background: -moz-linear-gradient(-45deg, #07a7e3 0%, #32dac3 100%);
    background: -webkit-linear-gradient(-45deg, #07a7e3 0%, #32dac3 100%);
    background: linear-gradient(135deg, #07a7e3 0%, #32dac3 100%);
    filter: progid:DXImageTransform.Microsoft.gradient( startColorstr=$qp-color-1, endColorstr=$qp-color-2,GradientType=1 );
    -webkit-transition: opacity 0.2s ease-out;
    -moz-transition: opacity 0.2s ease-out;
    -o-transition: opacity 0.2s ease-out;
    transition: opacity 0.2s ease-out;" class="card">
                                <div class="card-body">
                                    <div class="card-title-group align-items-start">
                                        <div class="card-title">
                                            <h4 style="color:#fff" class="title"><span
                                                    style="font-weight:bold; font-size:27px;">EXPENSE </span><br/> This
                                                Month</h4>
                                        </div>
                                    </div>
                                    <div class="mt-2 mb-4">
                                        <div style="color:#fff" class="amount h1">
                                            RM {{number_format($expenditures,2)}}</div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-sm-6 col-xl-6 col-xxl-3">
                            <div
                                style="color: #FFFFFF !important; background: linear-gradient(135deg, #7e5ad5 0%, #1d1143 100%);"
                                class="card">
                                <div class="card-body">
                                    <div class="card-title-group align-items-start">
                                        <div class="card-title">
                                            <h4 style="color:#fff" class="title"><span
                                                    style="font-weight:bold; font-size:21px;">INCOME COLLECTED</span>
                                                <br/> This Month</h4>
                                        </div>
                                    </div>
                                    <div class="mt-2 mb-4">
                                        <div style="color:#fff" class="amount h1">
                                            RM {{number_format($incomeCollected* 50,2)}}</div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-sm-6 col-xl-6 col-xxl-3">
                            <div style="color: #FFFFFF !important;
    background: #07a7e3;
    background: -moz-linear-gradient(-45deg, #07a7e3 0%, #32dac3 100%);
    background: -webkit-linear-gradient(-45deg, #07a7e3 0%, #32dac3 100%);
    background: linear-gradient(135deg, #07a7e3 0%, #32dac3 100%);
    filter: progid:DXImageTransform.Microsoft.gradient( startColorstr=$qp-color-1, endColorstr=$qp-color-2,GradientType=1 );
    -webkit-transition: opacity 0.2s ease-out;
    -moz-transition: opacity 0.2s ease-out;
    -o-transition: opacity 0.2s ease-out;
    transition: opacity 0.2s ease-out;" class="card">
                                <div class="card-body">
                                    <div class="card-title-group align-items-start">
                                        <div class="card-title">
                                            <h4 style="color:#fff" class="title"><span
                                                    style="font-weight:bold; font-size:21px;">AVG PER INVOICE</span>
                                                <br/> This Month</h4>
                                        </div>
                                    </div>
                                    <div class="mt-2 mb-3">
                                        <div style="color:#fff" class="amount h1">
                                            RM {{number_format($average_per_invoice,2)}}</div>
                                    </div>
                                </div>
                            </div>
                        </div>


                        <div class="col-sm-6 col-xl-6 col-xxl-3">
                            <div
                                style="color: #FFFFFF !important; background: linear-gradient(135deg, #e4d063 0%, #e8571fbd 100%);"
                                class="card  card-xs ">
                                <div style="padding:0px !important" class="card-body">
                                    <div class="card-title-group align-items-start">
                                        <div class="card-title">
                                            <h4 style="color:#fff" class="title">Active Staffs</h4>
                                        </div>
                                    </div>
                                    <div class="mt-2 mb-4">
                                        <div style="color:#fff"
                                             class="amount h1">@php $allTutors = DB::table('users')->where('role','!=','1')->where('role','!=','4')->count('id'); @endphp {{$allTutors}}</div>
                                    </div>
                                </div>
                            </div>
                        </div>


                        <div class="col-sm-6 col-xl-6 col-xxl-3">
                            <div
                                style="color: #FFFFFF !important;background: linear-gradient(135deg, #60aecc 0%, #397d77 100%);"
                                class="card card-xs ">
                                <div style="padding:0px !important" class="card-body">
                                    <div class="card-title-group align-items-start">
                                        <div class="card-title">
                                            <h4 style="color:#fff" class="title">Active Tutors</h4>
                                        </div>
                                    </div>
                                    <div class="mt-2 mb-4">
                                        <div style="color:#fff"
                                             class="amount h1">@php $allTutors = DB::table('tutors')->count('id'); @endphp {{$allTutors}} </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-sm-6 col-xl-6 col-xxl-3">
                            <div
                                style="color: #FFFFFF !important; background: linear-gradient(135deg, #e4d063 0%, #e8571fbd 100%);"
                                class="card  card-xs ">
                                <div style="padding:0px !important" class="card-body">
                                    <div class="card-title-group align-items-start">
                                        <div class="card-title">
                                            <h4 style="color:#fff" class="title">Active Students</h4>
                                        </div>
                                    </div>
                                    <div class="mt-2 mb-4">
                                        <div style="color:#fff"
                                             class="amount h1">@php $allStudents = DB::table('students')->count('id'); @endphp {{$allStudents}} </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-sm-6 col-xl-6 col-xxl-3">
                            <div
                                style="color: #FFFFFF !important; background: linear-gradient(135deg, #60aecc 0%, #397d77 100%);"
                                class="card card-xs ">
                                <div style="padding:0px !important" class="card-body">
                                    <div class="card-title-group align-items-start">
                                        <div class="card-title">
                                            <h4 style="color:#fff" class="title">This month new students</h4>
                                        </div>
                                    </div>
                                    <div class="mt-2 mb-4">
                                        <div style="color:#fff" class="amount h1"></div>
                                    </div>
                                </div>
                            </div>
                        </div>


                        <div class="col-xxl-8 col-md-8">
                            <div class="card h-100">
                                <div class="card-body">
                                    <div class="card-title-group flex-wrap">
                                        <div class="card-title">
                                            <h5 class="title">REVENUE VS EXPENSE</h5>
                                        </div>
                                    </div>
                                    <div>
                                        <canvas id="myChartRevenueVsExpenses"></canvas>
                                    </div>
                                </div>
                            </div>
                            <!--          <div class="card">-->
                            <!--<div class="card-header">-->
                            <!--    <div class="row">-->
                            <!--        <div class="col col-sm-9">Sales Data</div>-->
                            <!--        <div class="col col-sm-3">-->
                            <!--            <input type="text" id="daterange_textbox" class="form-control" readonly />-->
                            <!--        </div>-->
                            <!--    </div>-->
                            <!--</div>-->
                            <!--<div class="card-body">-->
                            <!--    <div class="table-responsive">-->
                            <!--        <div class="chart-container pie-chart">-->
                            <!--            <canvas id="bar_chart" height="40"> </canvas>-->
                            <!--        </div>-->
                            <!--    </div>-->
                            <!--</div>-->
                            <!--</div>-->
                        </div>
                        <div class="col-md-4 col-xxl-4">
                            <div class="card h-100">
                                <div class="card-body">
                                    <div class="card-title-group">
                                        <div class="card-title">
                                            <h5 class="title">EXPENSES CATEGORY</h5>
                                        </div>
                                        <div class="card-tools">
                                            <em class="icon-hint icon ni ni-help-fill" data-bs-toggle="tooltip"
                                                data-bs-placement="left" title="EXPENSES CATEGORY"></em>
                                        </div>
                                    </div>
                                    <div class="nk-chart-analytics-session-device mt-4">
                                        <div class="chart-container"
                                             style="position: relative; height:100%; width:100%">
                                            <canvas id="expensesCategoryChart"></canvas>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-4 col-xxl-4">
                            <div class="card h-100">
                                <div style="padding:0px !important" class="card-body">
                                    <div class="card-title-group">
                                        <div class="card-title">
                                            <h5 class="title">Last User Activity</h5>
                                        </div>
                                    </div>
                                    @php

                                        $user = DB::table('loggedInUsers')->orderBy("id","desc")->get();

                                    @endphp
                                    <div class="nk-timeline nk-timeline-center mt-4">
                                        <div style="overflow-y: auto; height:500px; " class="nk-timeline-group">
                                            <div class="nk-timeline-heading">
                                            </div>
                                            <ul class="nk-timeline-list">
                                                @foreach($user as $rowUser)
                                                    @php

                                                        $userDetail = DB::table('users')->where('id','=',$rowUser->user_id)->first();

                                                    @endphp
                                                    <li class="nk-timeline-item">
                                                        <div class="nk-timeline-item-inner">
                                                            <div class="nk-timeline-symbol">
                                                                <div
                                                                    class="media media-md media-middle media-circle text-bg-info">
                                                                    <em class="icon ni ni-user"></em>
                                                                </div>
                                                            </div>
                                                            <div class="nk-timeline-content">
                                                                <p class="small">
                                                                    <strong>{{$userDetail->name}}</strong> viewed
                                                                    <strong>{{$rowUser->detail}}</strong>
                                                                    <br/>
                                                                    {{$rowUser->last_login}}
                                                                </p>
                                                            </div>
                                                        </div>
                                                    </li>
                                                @endforeach


                                            </ul>
                                        </div>

                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-8 col-xxl-8">
                            <div class="card h-100">
                                <div class="card-body">
                                    <div class="card-title-group">
                                        <div class="card-title">
                                            <h5 class="title">CASH FLOW</h5>
                                        </div>
                                    </div>

                                    <div class="chart-legend-group justify-content-around pt-4 flex-wrap gap g-2">
                                        <div class="chart-container"
                                             style="position: relative; height:100%; width:100%">
                                            <canvas id="myChart"></canvas>


                                        </div>

                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="col-md-8 col-xxl-8">
                            <div class="card h-100">
                                <div class="card-body">
                                    <div class="card-title-group">
                                        <div class="card-title">
                                            <h5 class="title">UNPAID SALES INVOICE</h5>
                                        </div>
                                    </div>

                                    <div class="chart-legend-group justify-content-around pt-4 flex-wrap gap g-2">
                                        <div class="chart-container"
                                             style="position: relative; height:100%; width:100%">
                                            <canvas id="unPaidAmountChart"></canvas>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="col-md-4 col-xxl-4">
                            <div class="card h-100">
                                <div class="card-body">
                                    <div class="card-title-group">
                                        <div class="card-title">
                                            <h5 class="title">ACTIVE USERS</h5>
                                        </div>
                                    </div>
                                    <div class="chart-legend-group justify-content-left pt-4 flex-wrap gap g-2">
                                        <table>
                                            @php
                                                $activUsers = DB::table('loggedInUsers')->groupBy('user_id')->select('user_id')->get();
                                            @endphp
                                            @foreach($activUsers as $row)
                                                @php
                                                    $userLastLoginDetail = DB::table('loggedInUsers')->where('user_id','=',$row->user_id)->first();
                                                    $userDetail = DB::table('users')->where('id','=',$row->user_id)->first();
                                                @endphp
                                                <tr>
                                                    <td>

                                                        <div
                                                            class="media media-md media-middle media-circle text-bg-info">
                                                            <em class="icon ni ni-user"></em>
                                                        </div>

                                                    </td>
                                                    <td style="font-size:12px;">{{$userDetail->name}}
                                                        <br/> {{$userLastLoginDetail->last_login}}</td>
                                                </tr>

                                            @endforeach

                                        </table>
                                    </div>
                                </div>
                            </div>
                        </div>


                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="https://code.jquery.com/jquery-3.7.1.min.js"
            integrity="sha256-/JqT3SQfawRcv/BIHPThkBvs0OEvtFFmqPF/lYI/Cxo=" crossorigin="anonymous"></script>
    <script src="{{asset('library/moment.min.js')}}"></script>
    <script src="{{asset('library/daterangepicker.min.js')}}"></script>
    <script src="{{asset('library/Chart.bundle.min.js')}}"></script>
    <script src="{{asset('library/jquery.dataTables.min.js')}}"></script>
    <script src="{{asset('library/dataTables.bootstrap5.min.js')}}"></script>
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <!--<script>-->
    <!--$(document).ready(function() {-->

    <!--    fetch_data();-->

    <!--    var sale_chart;-->

    <!--    function fetch_data(start_date = '', end_date = '') {-->
    <!--        var dataTable = $('#order_table').DataTable({-->
    <!--            "processing": true,-->
    <!--            "serverSide": true,-->
    <!--            "order": [],-->
    <!--            "ajax": {-->
    <!--                url: "",-->
    <!--                type: "POST",-->
    <!--                data: {-->
    <!--                    action: 'fetch',-->
    <!--                    start_date: start_date,-->
    <!--                    end_date: end_date-->
    <!--                }-->
    <!--            },-->
    <!--            "drawCallback": function(settings) {-->
    <!--                var sales_date = [];-->
    <!--                var sale = [];-->

    <!--                for (var count = 0; count < settings.aoData.length; count++) {-->
    <!--                    sales_date.push(settings.aoData[count]._aData[2]);-->
    <!--                    sale.push(parseFloat(settings.aoData[count]._aData[1]));-->
    <!--                }-->

    <!--                var chart_data = {-->
    <!--                    labels: sales_date,-->
    <!--                    datasets: [{-->
    <!--                            label: 'Sales',-->
    <!--                            color: 'rgb(255,192,203)',-->
    <!--                            backgroundColor: 'transparent',-->
    <!--                            data: sale-->
    <!--                        },-->
    <!--                        {-->
    <!--                            label: 'Sales',-->
    <!--                            backgroundColor: 'transparent',-->
    <!--                            color: 'rgb(0, 0, 255)',-->
    <!--                            data: sale-->
    <!--                        }-->
    <!--                    ]-->

    <!--                };-->

    <!--                var group_chart3 = $('#bar_chart');-->

    <!--                if (sale_chart) {-->
    <!--                    sale_chart.destroy();-->
    <!--                }-->

    <!--                sale_chart = new Chart(group_chart3, {-->
    <!--                    type: 'line',-->
    <!--                    data: chart_data,-->
    <!--                });-->
    <!--            },-->
    <!--        });-->
    <!--    }-->

    <!--    $('#daterange_textbox').daterangepicker({-->
    <!--        ranges: {-->
    <!--            'Today': [moment(), moment()],-->
    <!--            'Yesterday': [moment().subtract(1, 'days'), moment().subtract(1, 'days')],-->
    <!--            'Last 7 Days': [moment().subtract(6, 'days'), moment()],-->
    <!--            'Last 30 Days': [moment().subtract(29, 'days'), moment()],-->
    <!--            'This Month': [moment().startOf('month'), moment().endOf('month')],-->
    <!--            'Last Month': [moment().subtract(1, 'month').startOf('month'), moment().subtract(1, 'month')-->
    <!--                .endOf('month')-->
    <!--            ]-->
    <!--        },-->
    <!--        format: 'YYYY-MM-DD'-->
    <!--    }, function(start, end) {-->

    <!--        $('#order_table').DataTable().destroy();-->

    <!--        fetch_data(start.format('YYYY-MM-DD'), end.format('YYYY-MM-DD'));-->
    <!--        console.log(start.format('YYYY-MM-DD'), "   space     ", end.format('YYYY-MM-DD'))-->
    <!--    });-->

    <!--});-->
    <!--</script>-->






    <script>


        const ctxExpensesCategoryChart = document.getElementById('expensesCategoryChart');
        new Chart(ctxExpensesCategoryChart, {
            type: 'doughnut',
            data: {
                labels: ['Tutor Payments', 'Expenditures'],
                datasets: [
                    {
                        data: [{{$totalTutorPaidTime}}, {{$expenses}}],
                        borderWidth: 1
                    }]
            },
            options: {
                scales: {
                    y: {
                        beginAtZero: true
                    }
                }
            }
        });


        const ctxUnPaidAmountChart = document.getElementById('unPaidAmountChart');
        const unpaidData = @json($dataArray);
        new Chart(ctxUnPaidAmountChart, {
            type: 'bar',
            data: {
                labels: ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'],
                datasets: [{
                    label: 'UnPaid Amount',
                    data: unpaidData,
                    borderWidth: 1
                }]
            },
            options: {
                scales: {
                    y: {
                        beginAtZero: true
                    }
                }
            }
        });


        const ctx = document.getElementById('myChart');

        new Chart(ctx, {
            type: 'bar',
            data: {
                labels: ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'],
                datasets: [
                    {
                        label: 'Money In',
                        data: [1, 2, 3, 4, 5, 6, 12, 19, 3, 5, 2, 3],
                        borderWidth: 1
                    },
                    {
                        label: 'Money Out',
                        data: [4, 5, 6, 7, 8, 7, 12, 19, 3, 5, 2, 3],
                        borderWidth: 1
                    }
                ]
            },
            options: {
                scales: {
                    y: {
                        beginAtZero: true
                    }
                }
            }
        });

        const ctxMyChartRevenueVsExpenses = document.getElementById('myChartRevenueVsExpenses');

        new Chart(ctxMyChartRevenueVsExpenses, {
            type: 'line',
            data: {
                labels: ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'],

                datasets: [
                    {
                        label: 'Revenue',
                        data: [0, 0, 0, 0, 0, 0, 0, {{ $revenue }}, 0, 0, 0, 0],
                        borderWidth: 1
                    },
                    {
                        label: 'Expense',
                        data: [0, 0, 0, 0, 0, 0, 0, {{$expenses}}, 0, 0, 0, 0],
                        borderWidth: 1
                    }
                ]
            },
            options: {}
        });

    </script>
    <script>
        $(document).ready(function () {

            fetch_data();

            var sale_chart;

            function fetch_data(start_date = '', end_date = '') {
                var dataTable = $('#order_table').DataTable({
                    "processing": true,
                    "serverSide": true,
                    "order": [],
                    "ajax": {
                        url: "action.php",
                        type: "POST",
                        data: {
                            action: 'fetch',
                            start_date: start_date,
                            end_date: end_date
                        }
                    },
                    "drawCallback": function (settings) {
                        var sales_date = [];
                        var sale = [];

                        for (var count = 0; count < settings.aoData.length; count++) {
                            sales_date.push(settings.aoData[count]._aData[2]);
                            sale.push(parseFloat(settings.aoData[count]._aData[1]));
                        }

                        var chart_data = {
                            labels: sales_date,
                            datasets: [{
                                label: 'Sales',
                                color: 'rgb(255,192,203)',
                                backgroundColor: 'transparent',
                                data: sale
                            },
                                {
                                    label: 'Sales',
                                    backgroundColor: 'transparent',
                                    color: 'rgb(0, 0, 255)',
                                    data: sale
                                }
                            ]

                        };

                        var group_chart3 = $('#bar_chart');

                        if (sale_chart) {
                            sale_chart.destroy();
                        }

                        sale_chart = new Chart(group_chart3, {
                            type: 'line',
                            data: chart_data,
                        });
                    },
                });
            }

            $('#daterange_textbox').daterangepicker({
                ranges: {
                    'Today': [moment(), moment()],
                    'Yesterday': [moment().subtract(1, 'days'), moment().subtract(1, 'days')],
                    'Last 7 Days': [moment().subtract(6, 'days'), moment()],
                    'Last 30 Days': [moment().subtract(29, 'days'), moment()],
                    'This Month': [moment().startOf('month'), moment().endOf('month')],
                    'Last Month': [moment().subtract(1, 'month').startOf('month'), moment().subtract(1, 'month')
                        .endOf('month')
                    ]
                },
                format: 'YYYY-MM-DD'
            }, function (start, end) {

                $('#order_table').DataTable().destroy();

                fetch_data(start.format('YYYY-MM-DD'), end.format('YYYY-MM-DD'));
                console.log(start.format('YYYY-MM-DD'), "   space     ", end.format('YYYY-MM-DD'))
            });

        });
    </script>
@endsection
