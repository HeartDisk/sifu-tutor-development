<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Http;

class PaymentController extends Controller
{
    public function success(Request $req)
    {
        dd($req->all());;
    }
    
    public function cancel(Request $req)
    {
        dd($req->all());
    }
}
