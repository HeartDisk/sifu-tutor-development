<!DOCTYPE html>
<html>
<head>
    <title>Class Reminder</title>
</head>
<body>
    <p>{{ $messageContent }}</p>
</body>
</html>
